# Security Specification for Argon Coaching CBT Platform

## 1. Data Invariants
- **Authentication**: Users must be authenticated to create, update, or submit exam records.
- **Admin/Faculty Privilege**: Only faculty / admin users (verified via email or role document) can create, update, lock, schedule, or delete `tests` and `testSeries`, and review `verificationRequests`.
- **Student Exam Submissions**: A student can only write/create an attempt for their own `studentId == request.auth.uid`. Attempts cannot be mutated once submitted.
- **Student Profile**: Students can only edit their own user profile document (`request.auth.uid == userId`) and cannot elevate their own role to `faculty`.
- **Payment Verifications**: Students can only submit requests with `studentId == request.auth.uid` and initial status `'pending'`. Only faculty can update the status to `'accepted'` or `'rejected'`.
- **Public Visibility**: Published `testSeries` and active `tests` are readable by authenticated users so students can view available tests and take exams.

## 2. The Dirty Dozen Payloads (Designed to Fail)
1. **Unauthenticated Test Create**: Write to `/tests/test-1` without auth token. Expected: `PERMISSION_DENIED`.
2. **Student Role Elevation**: Student sets `role: 'faculty'` on `/users/{studentId}`. Expected: `PERMISSION_DENIED`.
3. **Student Paper Lock**: Student updates `isLockedByFaculty: true` on `/tests/test-1`. Expected: `PERMISSION_DENIED`.
4. **Student Schedule Override**: Student alters `scheduledStartTime` on `/tests/test-1`. Expected: `PERMISSION_DENIED`.
5. **Impersonated Exam Attempt**: Student submits `/attempts/attempt-1` with `studentId: 'other-student'`. Expected: `PERMISSION_DENIED`.
6. **Attempt Tampering**: Student updates an already submitted attempt score. Expected: `PERMISSION_DENIED`.
7. **Ghost Field Injection**: Attempt contains unexpected shadow fields like `isAdmin: true`. Expected: `PERMISSION_DENIED`.
8. **Malicious ID Injection**: Document created with 2KB junk characters string ID. Expected: `PERMISSION_DENIED`.
9. **Self-Approval of Payment**: Student updates `/verificationRequests/req-1` status from `pending` to `accepted`. Expected: `PERMISSION_DENIED`.
10. **Test Series Deletion by Student**: Student issues delete on `/testSeries/series-1`. Expected: `PERMISSION_DENIED`.
11. **Negative Score Injection**: Negative score in total marks or non-numeric marks. Expected: `PERMISSION_DENIED`.
12. **PII Leaks**: Non-owner attempts to read another student's private payment verification data without faculty role. Expected: `PERMISSION_DENIED`.
