import express from 'express';
import { createServer as createViteServer } from 'vite';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import {
  INITIAL_TEST_SERIES,
  INITIAL_TESTS,
  DEMO_STUDENT_USERS,
  INITIAL_STUDENT_ATTEMPTS,
  INITIAL_VERIFICATION_REQUESTS,
  INSTITUTION_UPI_QR,
  INITIAL_FACULTY_PROFILES,
  INITIAL_NOTICES,
  INITIAL_MATERIALS,
} from './src/data/seedData.ts';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const PORT = 3000;
const DATA_DIR = path.join(__dirname, 'data');
const STATE_FILE = path.join(DATA_DIR, 'app_state.json');

// Ensure data folder exists
if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
}

export interface ActiveFacultyDevice {
  deviceId: string;
  deviceName: string;
  browser: string;
  ip: string;
  loggedInAt: string;
  lastActiveAt: string;
}

export interface SharedAppState {
  testSeries: any[];
  tests: any[];
  students: any[];
  attempts: any[];
  verificationRequests: any[];
  notices: any[];
  materials: any[];
  facultyProfiles: any[];
  instituteUpi: {
    upiId: string;
    merchantName: string;
    qrUrl: string;
    note: string;
  };
  activeFacultyDevices: ActiveFacultyDevice[];
  lastModifiedAt: string;
}

// Initial state fallback
const DEFAULT_STATE: SharedAppState = {
  testSeries: INITIAL_TEST_SERIES,
  tests: INITIAL_TESTS,
  students: DEMO_STUDENT_USERS,
  attempts: INITIAL_STUDENT_ATTEMPTS,
  verificationRequests: INITIAL_VERIFICATION_REQUESTS,
  notices: INITIAL_NOTICES,
  materials: INITIAL_MATERIALS,
  facultyProfiles: INITIAL_FACULTY_PROFILES,
  instituteUpi: {
    upiId: 'argoncoaching@icici',
    merchantName: 'ARGON COACHING ACADEMY ASSAM',
    qrUrl: INSTITUTION_UPI_QR,
    note: 'Scan via any UPI App (GPay / PhonePe / Paytm / BHIM) to unlock test series',
  },
  activeFacultyDevices: [],
  lastModifiedAt: new Date().toISOString(),
};

// Load state from file or initialize
function loadState(): SharedAppState {
  try {
    if (fs.existsSync(STATE_FILE)) {
      const data = fs.readFileSync(STATE_FILE, 'utf-8');
      const parsed = JSON.parse(data);
      return {
        ...DEFAULT_STATE,
        ...parsed,
        tests: (parsed.tests && parsed.tests.length > 0) ? parsed.tests : DEFAULT_STATE.tests,
        testSeries: (parsed.testSeries && parsed.testSeries.length > 0) ? parsed.testSeries : DEFAULT_STATE.testSeries,
        facultyProfiles: (parsed.facultyProfiles && parsed.facultyProfiles.length > 0) ? parsed.facultyProfiles : DEFAULT_STATE.facultyProfiles,
        notices: (parsed.notices && parsed.notices.length > 0) ? parsed.notices : DEFAULT_STATE.notices,
        materials: (parsed.materials && parsed.materials.length > 0) ? parsed.materials : DEFAULT_STATE.materials,
        instituteUpi: (parsed.instituteUpi && parsed.instituteUpi.upiId) ? parsed.instituteUpi : DEFAULT_STATE.instituteUpi,
        activeFacultyDevices: parsed.activeFacultyDevices || [],
      };
    }
  } catch (err) {
    console.error('Error reading app_state.json:', err);
  }
  saveState(DEFAULT_STATE);
  return DEFAULT_STATE;
}

function saveState(state: SharedAppState) {
  try {
    state.lastModifiedAt = new Date().toISOString();
    fs.writeFileSync(STATE_FILE, JSON.stringify(state, null, 2), 'utf-8');
  } catch (err) {
    console.error('Error writing app_state.json:', err);
  }
}

let appState: SharedAppState = loadState();

// Active student & faculty Real-Time SSE client connections
const realtimeClients = new Set<express.Response>();

function broadcastRealtimeEvent(payload: Record<string, any>) {
  const data = `data: ${JSON.stringify(payload)}\n\n`;
  for (const client of realtimeClients) {
    try {
      client.write(data);
    } catch {
      realtimeClients.delete(client);
    }
  }
}

async function startServer() {
  const app = express();
  app.use(express.json({ limit: '50mb' }));

  // Real-Time Event Stream (SSE) for all connected student devices
  app.get('/api/realtime/stream', (req, res) => {
    res.setHeader('Content-Type', 'text/event-stream');
    res.setHeader('Cache-Control', 'no-cache, no-transform');
    res.setHeader('Connection', 'keep-alive');
    res.setHeader('X-Accel-Buffering', 'no');
    res.flushHeaders?.();

    // Send initial handshake with current state timestamp
    res.write(`data: ${JSON.stringify({ type: 'CONNECTED', timestamp: Date.now(), lastModifiedAt: appState.lastModifiedAt })}\n\n`);

    realtimeClients.add(res);

    // Keep-alive heartbeat every 15 seconds
    const heartbeat = setInterval(() => {
      try {
        res.write(`: heartbeat\n\n`);
      } catch {
        clearInterval(heartbeat);
        realtimeClients.delete(res);
      }
    }, 15000);

    req.on('close', () => {
      clearInterval(heartbeat);
      realtimeClients.delete(res);
    });
  });

  // API 1: Get latest shared state (accessible to faculty and all students across all devices)
  app.get('/api/state', (req, res) => {
    res.json({
      success: true,
      data: appState,
    });
  });

  // API 2: Sync state updates (tests added/removed, series updated, verifications, students)
  app.post('/api/sync', (req, res) => {
    try {
      const updates = req.body;
      if (updates.testSeries) appState.testSeries = updates.testSeries;
      if (updates.tests) appState.tests = updates.tests;
      if (updates.students) appState.students = updates.students;
      if (updates.attempts) appState.attempts = updates.attempts;
      if (updates.verificationRequests)
        appState.verificationRequests = updates.verificationRequests;
      if (updates.notices) appState.notices = updates.notices;
      if (updates.materials) appState.materials = updates.materials;
      if (updates.facultyProfiles) appState.facultyProfiles = updates.facultyProfiles;
      if (updates.instituteUpi) appState.instituteUpi = updates.instituteUpi;

      saveState(appState);

      // Immediately push real-time broadcast to all connected student devices
      broadcastRealtimeEvent({
        type: 'STATE_UPDATED',
        timestamp: appState.lastModifiedAt,
        data: {
          testSeries: appState.testSeries,
          tests: appState.tests,
          students: appState.students,
          attempts: appState.attempts,
          verificationRequests: appState.verificationRequests,
          notices: appState.notices,
          materials: appState.materials,
          facultyProfiles: appState.facultyProfiles,
          instituteUpi: appState.instituteUpi,
        },
      });

      res.json({ success: true, message: 'State synced and pushed to all active devices' });
    } catch (err: any) {
      res.status(500).json({ success: false, error: err.message });
    }
  });

  // API 3: Faculty Login with Max 2 Devices Enforced
  app.post('/api/faculty/login', (req, res) => {
    const { password, deviceId, deviceName, browser } = req.body;

    if (password !== 'ADMIN123@') {
      return res.status(401).json({
        success: false,
        message: 'Incorrect administrator password. Please check your credentials.',
      });
    }

    if (!deviceId) {
      return res.status(400).json({
        success: false,
        message: 'Device identifier required.',
      });
    }

    const clientIp =
      (req.headers['x-forwarded-for'] as string)?.split(',')[0] ||
      req.socket.remoteAddress ||
      '127.0.0.1';

    // Prune stale sessions older than 24 hours
    const now = Date.now();
    appState.activeFacultyDevices = appState.activeFacultyDevices.filter((dev) => {
      const lastActive = new Date(dev.lastActiveAt).getTime();
      return now - lastActive < 24 * 60 * 60 * 1000;
    });

    const existingIndex = appState.activeFacultyDevices.findIndex(
      (d) => d.deviceId === deviceId
    );

    if (existingIndex >= 0) {
      // Device already has an active slot, refresh timestamp
      appState.activeFacultyDevices[existingIndex].lastActiveAt = new Date().toISOString();
      saveState(appState);
      return res.json({
        success: true,
        message: 'Faculty authenticated successfully.',
        activeDevices: appState.activeFacultyDevices,
      });
    }

    // Check device limit: Maximum 2 devices allowed!
    if (appState.activeFacultyDevices.length >= 2) {
      return res.status(403).json({
        success: false,
        code: 'DEVICE_LIMIT_REACHED',
        message:
          'Maximum 2 active faculty devices limit reached. The Faculty Portal cannot be accessed on more than 2 devices simultaneously. Please log out or revoke an existing session.',
        activeDevices: appState.activeFacultyDevices,
      });
    }

    // Add new device
    const newDevice: ActiveFacultyDevice = {
      deviceId,
      deviceName: deviceName || `Faculty Device ${appState.activeFacultyDevices.length + 1}`,
      browser: browser || 'Standard Web Browser',
      ip: clientIp,
      loggedInAt: new Date().toISOString(),
      lastActiveAt: new Date().toISOString(),
    };

    appState.activeFacultyDevices.push(newDevice);
    saveState(appState);

    res.json({
      success: true,
      message: 'Faculty authenticated successfully (Device enrolled).',
      activeDevices: appState.activeFacultyDevices,
    });
  });

  // API 4: Faculty Logout (releases device slot)
  app.post('/api/faculty/logout', (req, res) => {
    const { deviceId } = req.body;
    if (deviceId) {
      appState.activeFacultyDevices = appState.activeFacultyDevices.filter(
        (d) => d.deviceId !== deviceId
      );
      saveState(appState);
    }
    res.json({
      success: true,
      message: 'Device logged out and session slot released.',
      activeDevices: appState.activeFacultyDevices,
    });
  });

  // API 5: Revoke Device session (allows admin to free up a slot)
  app.post('/api/faculty/revoke-device', (req, res) => {
    const { targetDeviceId } = req.body;
    appState.activeFacultyDevices = appState.activeFacultyDevices.filter(
      (d) => d.deviceId !== targetDeviceId
    );
    saveState(appState);
    res.json({
      success: true,
      message: 'Device session revoked successfully.',
      activeDevices: appState.activeFacultyDevices,
    });
  });

  // API 6: Register Student & Auto-Generate Roll Number
  app.post('/api/register-student', (req, res) => {
    try {
      const { name, email, phone, targetExam } = req.body;
      if (!name || !phone) {
        return res.status(400).json({ success: false, message: 'Name and phone required' });
      }

      const examCode =
        targetExam === 'NEET' ? 'NEET' : targetExam === 'JEE Advanced' ? 'ADV' : 'MAIN';
      const autoRoll = `ARG-${examCode}-2026-${Math.floor(1000 + Math.random() * 9000)}`;

      const newStudent = {
        id: `student-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
        name: name.trim(),
        email: email?.trim() || `${name.trim().toLowerCase().replace(/\s+/g, '.')}@argon.edu`,
        phone: phone.trim(),
        role: 'student',
        targetExam: targetExam || 'JEE Main',
        rollNo: autoRoll,
        enrolledSeriesIds: ['series-jee-main-free'],
        avatar: `https://api.dicebear.com/7.x/initials/svg?seed=${encodeURIComponent(name)}`,
        registeredAt: new Date().toISOString(),
      };

      appState.students = [newStudent, ...appState.students];
      saveState(appState);

      res.json({
        success: true,
        student: newStudent,
        message: `Registered student ${name} with Roll Number ${autoRoll}`,
      });
    } catch (err: any) {
      res.status(500).json({ success: false, error: err.message });
    }
  });

  // Setup Vite dev server middleware in dev, or serve static dist in production
  if (process.env.NODE_ENV === 'production' && fs.existsSync(path.join(__dirname, 'dist'))) {
    app.use(express.static(path.join(__dirname, 'dist')));
    app.get('*', (req, res) => {
      res.sendFile(path.join(__dirname, 'dist', 'index.html'));
    });
  } else {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Argon Test Platform Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
