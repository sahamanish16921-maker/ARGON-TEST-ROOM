/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { AppProvider, useApp } from './context/AppContext.tsx';
import { Navbar } from './components/Navbar.tsx';
import { LandingPage } from './components/LandingPage.tsx';
import { FacultyDashboard } from './components/FacultyDashboard.tsx';
import { StudentDashboard } from './components/StudentDashboard.tsx';
import { NtaExamInterface } from './components/NtaExamInterface.tsx';
import { ResultAnalysisView } from './components/ResultAnalysisView.tsx';
import { AuthModal } from './components/AuthModal.tsx';
import { CoursesPage } from './components/website/CoursesPage.tsx';
import { PublicTestSeriesPage } from './components/website/PublicTestSeriesPage.tsx';
import { FacultyMentorsPage } from './components/website/FacultyMentorsPage.tsx';
import { ResultsHallOfFame } from './components/website/ResultsHallOfFame.tsx';
import { AdmissionsContactPage } from './components/website/AdmissionsContactPage.tsx';
import { FreeResourcesPage } from './components/website/FreeResourcesPage.tsx';
import { WebsiteFooter } from './components/website/WebsiteFooter.tsx';

function MainApp() {
  const { currentView } = useApp();
  const [isAuthOpen, setIsAuthOpen] = useState(false);
  const [authDefaultTab, setAuthDefaultTab] = useState<'faculty' | 'student'>('student');

  const handleOpenAuth = (defaultTab: 'faculty' | 'student' = 'student') => {
    setAuthDefaultTab(defaultTab);
    setIsAuthOpen(true);
  };

  // Full-screen authentic NTA CBT Test mode (no standard navbar to simulate real locked exam)
  if (currentView === 'nta-exam') {
    return <NtaExamInterface />;
  }

  // Scorecard and analysis mode
  if (currentView === 'result-view') {
    return <ResultAnalysisView />;
  }

  const isPublicWebsiteView = [
    'home',
    'courses',
    'test-series',
    'faculty-mentors',
    'results',
    'admissions',
    'free-resources',
  ].includes(currentView);

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans selection:bg-amber-500 selection:text-slate-950">
      <Navbar onOpenAuth={handleOpenAuth} />

      <main className="flex-1">
        {currentView === 'faculty-dashboard' && <FacultyDashboard />}
        {currentView === 'student-dashboard' && <StudentDashboard />}
        {currentView === 'home' && <LandingPage onOpenAuth={handleOpenAuth} />}
        {currentView === 'courses' && <CoursesPage onOpenAuth={handleOpenAuth} />}
        {currentView === 'test-series' && <PublicTestSeriesPage onOpenAuth={handleOpenAuth} />}
        {currentView === 'faculty-mentors' && <FacultyMentorsPage onOpenAuth={handleOpenAuth} />}
        {currentView === 'results' && <ResultsHallOfFame />}
        {currentView === 'admissions' && <AdmissionsContactPage />}
        {currentView === 'free-resources' && <FreeResourcesPage />}
      </main>

      {isPublicWebsiteView && <WebsiteFooter onOpenAuth={handleOpenAuth} />}

      <AuthModal
        isOpen={isAuthOpen}
        onClose={() => setIsAuthOpen(false)}
        initialTab={authDefaultTab}
      />
    </div>
  );
}

export default function App() {
  return (
    <AppProvider>
      <MainApp />
    </AppProvider>
  );
}
