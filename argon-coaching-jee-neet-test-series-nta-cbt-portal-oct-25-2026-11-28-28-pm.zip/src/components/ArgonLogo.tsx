import React from 'react';

interface ArgonLogoProps {
  className?: string;
  theme?: 'dark' | 'light';
  showText?: boolean;
  size?: 'sm' | 'md' | 'lg' | 'xl';
}

export const ArgonLogo: React.FC<ArgonLogoProps> = ({
  className = '',
  theme = 'dark',
  showText = true,
  size = 'md',
}) => {
  // Height presets
  const sizeClasses = {
    sm: 'h-7',
    md: 'h-9',
    lg: 'h-11',
    xl: 'h-14',
  }[size];

  const textColor = theme === 'dark' ? '#F8FAFC' : '#1E2029';
  const aColor = theme === 'dark' ? '#F8FAFC' : '#1E2029';
  const cColor = '#E11D48'; // Argon signature crimson red
  const dotColor = '#10B981'; // Argon signature vibrant green

  return (
    <div className={`inline-flex items-center gap-2 select-none ${className}`}>
      <svg
        viewBox={showText ? '0 0 460 84' : '0 0 120 84'}
        className={`${sizeClasses} w-auto transition-transform`}
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        aria-label="Argon Coaching Logo"
      >
        <g id="argon-mark">
          {/* Lowercase 'a' */}
          <path
            d="M 45 37 C 45 28.5 38.5 22 28.5 22 C 18.5 22 12 28.5 12 37 C 12 45.5 18.5 52 28.5 52 C 32 52 35 50.8 37.5 48.8 L 37.5 51.5 C 37.5 51.8 37.7 52 38 52 L 44.5 52 C 44.8 52 45 51.8 45 51.5 L 45 37 Z M 28.5 44 C 23.5 44 20 40.5 20 37 C 20 33.5 23.5 30 28.5 30 C 33.5 30 37 33.5 37 37 C 37 40.5 33.5 44 28.5 44 Z"
            fill={aColor}
          />
          {/* Stem of 'a' */}
          <rect x="37" y="22" width="7.8" height="30" rx="1" fill={aColor} />

          {/* Letter 'C' with swooping upward arrow */}
          <path
            d="M 80 27 C 76 23.5 70.5 21 63 21 C 48 21 39 31 39 44 C 39 57 48 66 61 66 C 71 66 79 61 85 54.5"
            stroke={cColor}
            strokeWidth="7.8"
            strokeLinecap="round"
            strokeLinejoin="round"
          />

          {/* Arrow extending from bottom loop of 'C' */}
          <path
            d="M 78 59 L 94 47"
            stroke={cColor}
            strokeWidth="7"
            strokeLinecap="round"
          />
          {/* Arrowhead */}
          <path
            d="M 83 45 L 97 45.5 L 94.5 58.5 Z"
            fill={cColor}
          />

          {/* Green focal dot floating in front of arrow */}
          <circle cx="106" cy="46" r="5" fill={dotColor} />
        </g>

        {showText && (
          <g id="argon-typography">
            <text
              x="124"
              y="53"
              fill={textColor}
              fontFamily="system-ui, -apple-system, BlinkMacSystemFont, 'Inter', 'Segoe UI', Roboto, sans-serif"
              fontSize="37"
              fontWeight="700"
              letterSpacing="-0.6px"
            >
              Argon Coaching
            </text>
          </g>
        )}
      </svg>
    </div>
  );
};
