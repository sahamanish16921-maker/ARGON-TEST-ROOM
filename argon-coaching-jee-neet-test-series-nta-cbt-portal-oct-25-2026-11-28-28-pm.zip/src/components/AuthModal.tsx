import React, { useState, useEffect } from 'react';
import { useApp } from '../context/AppContext.tsx';
import type { ExamType } from '../types/index.ts';
import {
  ShieldCheck,
  GraduationCap,
  X,
  Lock,
  User as UserIcon,
  Sparkles,
  KeyRound,
  CheckCircle2,
  AlertCircle,
  ArrowRight,
  Phone,
  Hash,
  Search,
  Check,
  Smartphone,
  Laptop,
} from 'lucide-react';
import { ArgonLogo } from './ArgonLogo.tsx';

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialTab?: 'faculty' | 'student';
}

export const AuthModal: React.FC<AuthModalProps> = ({
  isOpen,
  onClose,
  initialTab = 'student',
}) => {
  const {
    loginAsFaculty,
    loginAsFacultyAsync,
    revokeFacultyDevice,
    activeFacultyDevices,
    currentDeviceId,
    loginAsDemoStudent,
    loginStudentByNameAndRoll,
    registerOrLoginStudent,
    students,
    signInWithGoogle,
  } = useApp();

  const [activeTab, setActiveTab] = useState<'faculty' | 'student'>(initialTab);

  useEffect(() => {
    if (isOpen) {
      setActiveTab(initialTab);
      setFacultyError('');
      setLoginRollError('');
      setFacultyDeviceConflict(null);
    }
  }, [isOpen, initialTab]);

  const [facultyPassword, setFacultyPassword] = useState('');
  const [facultyError, setFacultyError] = useState('');
  const [isSubmittingFaculty, setIsSubmittingFaculty] = useState(false);
  const [facultyDeviceConflict, setFacultyDeviceConflict] = useState<any[] | null>(null);

  // Student Login with Roll & Name
  const [studentAuthMode, setStudentAuthMode] = useState<'login-roll' | 'register'>('login-roll');
  const [loginStudentName, setLoginStudentName] = useState('');
  const [loginStudentRoll, setLoginStudentRoll] = useState('');
  const [loginRollError, setLoginRollError] = useState('');

  // Student Registration Form State
  const [studentName, setStudentName] = useState('');
  const [studentPhone, setStudentPhone] = useState('');
  const [studentEmail, setStudentEmail] = useState('');
  const [studentExam, setStudentExam] = useState<ExamType>('JEE Main');
  const [studentRoll, setStudentRoll] = useState('');
  const [studentError, setStudentError] = useState('');
  const [registeredRollNotice, setRegisteredRollNotice] = useState<{
    name: string;
    rollNo: string;
    exam: string;
  } | null>(null);

  if (!isOpen) return null;

  const handleFacultySubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setFacultyError('');
    setFacultyDeviceConflict(null);
    setIsSubmittingFaculty(true);

    try {
      const res = await loginAsFacultyAsync(facultyPassword.trim());
      setIsSubmittingFaculty(false);
      if (res.success) {
        onClose();
      } else {
        if (res.code === 'DEVICE_LIMIT_REACHED' && res.activeDevices) {
          setFacultyDeviceConflict(res.activeDevices);
        }
        setFacultyError(
          res.message || 'Incorrect administrator password. Please check your credentials.'
        );
      }
    } catch {
      setIsSubmittingFaculty(false);
      const ok = loginAsFaculty(facultyPassword.trim());
      if (ok) {
        onClose();
      } else {
        setFacultyError('Incorrect administrator password. Please check credentials.');
      }
    }
  };

  const handleRevokeAndRetry = async (targetDeviceId: string) => {
    await revokeFacultyDevice(targetDeviceId);
    setFacultyDeviceConflict(null);
    setFacultyError('');
    // Automatically retry login
    const res = await loginAsFacultyAsync(facultyPassword.trim());
    if (res.success) {
      onClose();
    } else {
      setFacultyError(res.message || 'Could not authenticate. Please try again.');
    }
  };

  const handleStudentRollLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setLoginRollError('');

    if (!loginStudentName.trim()) {
      setLoginRollError('Please enter your Registered Full Name');
      return;
    }

    if (!loginStudentRoll.trim()) {
      setLoginRollError('Please enter your Registered Roll Number');
      return;
    }

    const res = loginStudentByNameAndRoll(loginStudentName.trim(), loginStudentRoll.trim());
    if (res.success) {
      onClose();
    } else {
      setLoginRollError(res.message || 'Student not found with this Roll Number and Name');
    }
  };

  const handleStudentRegisterSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setStudentError('');

    if (!studentName.trim()) {
      setStudentError('Please enter your full name');
      return;
    }
    if (!studentPhone.trim()) {
      setStudentError('Please enter your contact phone number');
      return;
    }
    if (!studentEmail.trim() || !studentEmail.includes('@')) {
      setStudentError('Please enter a valid email address');
      return;
    }

    // Automatically generate unique roll number
    const examPrefix =
      studentExam === 'NEET'
        ? 'NEET'
        : studentExam === 'JEE Advanced'
        ? 'ADV'
        : 'MAIN';
    const autoRollNo = `ARG-${examPrefix}-2026-${Math.floor(1000 + Math.random() * 9000)}`;

    registerOrLoginStudent({
      name: studentName.trim(),
      email: studentEmail.trim(),
      phone: studentPhone.trim(),
      targetExam: studentExam,
      rollNo: autoRollNo,
    });

    setRegisteredRollNotice({
      name: studentName.trim(),
      rollNo: autoRollNo,
      exam: studentExam,
    });
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-sm animate-fadeIn">
      <div className="relative w-full max-w-md bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl overflow-hidden text-white">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-slate-400 hover:text-white p-1 rounded-lg hover:bg-slate-800 transition-colors z-10"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Header Tabs */}
        <div className="flex border-b border-slate-800 bg-slate-950/50">
          <button
            onClick={() => setActiveTab('student')}
            className={`flex-1 py-4 text-sm font-bold flex items-center justify-center gap-2 border-b-2 transition-all ${
              activeTab === 'student'
                ? 'border-indigo-500 text-indigo-400 bg-indigo-950/20'
                : 'border-transparent text-slate-400 hover:text-slate-200 hover:bg-slate-800/40'
            }`}
          >
            <GraduationCap className="w-4 h-4" />
            Student Portal
          </button>
          <button
            onClick={() => setActiveTab('faculty')}
            className={`flex-1 py-4 text-sm font-bold flex items-center justify-center gap-2 border-b-2 transition-all ${
              activeTab === 'faculty'
                ? 'border-amber-500 text-amber-400 bg-amber-950/20'
                : 'border-transparent text-slate-400 hover:text-slate-200 hover:bg-slate-800/40'
            }`}
          >
            <ShieldCheck className="w-4 h-4" />
            Faculty Portal
          </button>
        </div>

        <div className="p-6">
          {activeTab === 'faculty' ? (
            <div>
              <div className="mb-5 text-center">
                <div className="flex justify-center mb-3">
                  <ArgonLogo size="sm" theme="dark" />
                </div>
                <h3 className="text-xl font-extrabold text-white">Faculty Access</h3>
                <p className="text-xs text-slate-400 mt-1">
                  Enter password to access Test Scheduling, Subject Sequence & Question Creator
                </p>
              </div>

              {/* Security notice */}
              <div className="bg-slate-800/80 border border-slate-700/80 rounded-xl p-3 mb-4 flex items-start gap-2.5">
                <ShieldCheck className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                <div className="text-xs">
                  <p className="font-semibold text-slate-200">Authorized Faculty & Admin Only</p>
                  <p className="text-slate-400 mt-0.5">
                    Please provide your confidential faculty credentials to access the administrative portal.
                  </p>
                </div>
              </div>

              {facultyError && (
                <div className="mb-4 p-3 rounded-xl bg-rose-500/15 border border-rose-500/30 text-rose-300 text-xs">
                  <div className="flex items-start gap-2">
                    <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
                    <span>{facultyError}</span>
                  </div>

                  {facultyDeviceConflict && facultyDeviceConflict.length > 0 && (
                    <div className="mt-3 pt-3 border-t border-rose-500/20 space-y-2">
                      <p className="text-[11px] font-bold text-white uppercase tracking-wider">
                        Active Sessions (Max 2 Allowed):
                      </p>
                      {facultyDeviceConflict.map((dev, idx) => (
                        <div
                          key={dev.deviceId || idx}
                          className="bg-slate-950/70 border border-slate-800 rounded-lg p-2.5 flex items-center justify-between gap-2"
                        >
                          <div className="flex items-center gap-2 text-[11px] text-slate-300">
                            <Laptop className="w-4 h-4 text-amber-400 shrink-0" />
                            <div>
                              <p className="font-semibold text-white">{dev.deviceName || `Device ${idx + 1}`}</p>
                              <p className="text-[10px] text-slate-400">
                                IP: {dev.ip} • Logged in: {new Date(dev.loggedInAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                              </p>
                            </div>
                          </div>
                          <button
                            type="button"
                            onClick={() => handleRevokeAndRetry(dev.deviceId)}
                            className="px-2.5 py-1 text-[11px] font-bold bg-rose-600 hover:bg-rose-500 text-white rounded-md transition-colors shrink-0 shadow-sm"
                          >
                            Revoke & Login
                          </button>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              )}

              {/* Google Sign-in Option for Faculty */}
              <button
                type="button"
                onClick={async () => {
                  try {
                    await signInWithGoogle();
                    onClose();
                  } catch (e: any) {
                    setFacultyError(e?.message || 'Google Sign-In failed');
                  }
                }}
                className="w-full mb-3 py-2.5 px-4 bg-white hover:bg-slate-100 text-slate-900 font-bold text-xs rounded-xl shadow transition-all flex items-center justify-center gap-2.5"
              >
                <svg className="w-4 h-4" viewBox="0 0 24 24">
                  <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" />
                  <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" />
                  <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z" />
                  <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z" />
                </svg>
                <span>Continue with Google (Supabase Auth)</span>
              </button>

              <div className="flex items-center my-3 text-[11px] text-slate-500">
                <div className="flex-1 border-t border-slate-800"></div>
                <span className="px-2">or password login</span>
                <div className="flex-1 border-t border-slate-800"></div>
              </div>

              <form onSubmit={handleFacultySubmit} className="space-y-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                    Faculty Administrator Password
                  </label>
                  <div className="relative">
                    <Lock className="w-4 h-4 text-slate-500 absolute left-3 top-3" />
                    <input
                      type="password"
                      value={facultyPassword}
                      onChange={(e) => setFacultyPassword(e.target.value)}
                      className="w-full pl-9 pr-3 py-2 bg-slate-800 border border-slate-700 rounded-lg text-sm text-white focus:outline-none focus:border-amber-500 transition-colors font-mono"
                      placeholder="Enter administrator password"
                      required
                    />
                  </div>
                </div>

                <button
                  type="submit"
                  disabled={isSubmittingFaculty}
                  className="w-full py-2.5 px-4 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 disabled:opacity-50 text-slate-950 font-bold text-sm rounded-lg shadow-md shadow-amber-500/20 transition-all flex items-center justify-center gap-2"
                >
                  <ShieldCheck className="w-4 h-4" />
                  {isSubmittingFaculty ? 'Authenticating...' : 'Sign In to Faculty Portal'}
                </button>

                {/* Maximum 2 devices restriction notice */}
                <div className="pt-2 text-center">
                  <span className="inline-flex items-center gap-1.5 text-[11px] text-amber-300/80 font-medium">
                    <ShieldCheck className="w-3.5 h-3.5 text-amber-400" />
                    Maximum 2 active devices allowed simultaneously
                  </span>
                </div>
              </form>
            </div>
          ) : (
            <div>
              <div className="mb-4 text-center">
                <div className="flex justify-center mb-3">
                  <ArgonLogo size="sm" theme="dark" />
                </div>
                <h3 className="text-xl font-extrabold text-white">Student CBT Portal</h3>
                <p className="text-xs text-slate-400">
                  Login with your Admin-Registered Name & Roll Number
                </p>
              </div>

              {/* Google Sign-in Option for Students */}
              <button
                type="button"
                onClick={async () => {
                  try {
                    await signInWithGoogle();
                    onClose();
                  } catch (e: any) {
                    setLoginRollError(e?.message || 'Google Sign-In failed');
                  }
                }}
                className="w-full mb-3 py-2.5 px-4 bg-white hover:bg-slate-100 text-slate-900 font-bold text-xs rounded-xl shadow transition-all flex items-center justify-center gap-2.5"
              >
                <svg className="w-4 h-4" viewBox="0 0 24 24">
                  <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" />
                  <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" />
                  <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z" />
                  <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z" />
                </svg>
                <span>Sign in with Google (Supabase Auth)</span>
              </button>

              <div className="flex items-center my-3 text-[11px] text-slate-500">
                <div className="flex-1 border-t border-slate-800"></div>
                <span className="px-2">or roll number login</span>
                <div className="flex-1 border-t border-slate-800"></div>
              </div>

              {/* Toggle Sub-tabs: Login with Roll vs Self Register */}
              <div className="flex bg-slate-950 p-1 rounded-xl border border-slate-800 mb-4 text-xs font-semibold">
                <button
                  type="button"
                  onClick={() => setStudentAuthMode('login-roll')}
                  className={`flex-1 py-1.5 rounded-lg transition-all ${
                    studentAuthMode === 'login-roll'
                      ? 'bg-indigo-600 text-white'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  Roll Number Login
                </button>
                <button
                  type="button"
                  onClick={() => setStudentAuthMode('register')}
                  className={`flex-1 py-1.5 rounded-lg transition-all ${
                    studentAuthMode === 'register'
                      ? 'bg-indigo-600 text-white'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  Register New Student
                </button>
              </div>

              {registeredRollNotice ? (
                <div className="text-center py-4 space-y-4">
                  <div className="w-14 h-14 rounded-2xl bg-emerald-500/20 border border-emerald-500/40 text-emerald-400 flex items-center justify-center mx-auto">
                    <CheckCircle2 className="w-8 h-8" />
                  </div>
                  <div>
                    <h4 className="text-lg font-black text-white">Registration Successful!</h4>
                    <p className="text-xs text-slate-300 mt-1">
                      Welcome, <strong>{registeredRollNotice.name}</strong> ({registeredRollNotice.exam})!
                    </p>
                  </div>

                  <div className="p-4 bg-slate-950 border border-amber-500/40 rounded-xl">
                    <p className="text-[11px] text-slate-400 uppercase font-semibold">Your Official Roll Number</p>
                    <p className="text-2xl font-black font-mono text-amber-300 mt-1">
                      {registeredRollNotice.rollNo}
                    </p>
                    <p className="text-[10px] text-emerald-400 font-semibold mt-1.5 flex items-center justify-center gap-1">
                      <Check className="w-3.5 h-3.5" />
                      Saved automatically to Faculty App Console
                    </p>
                  </div>

                  <p className="text-xs text-slate-400">
                    Please remember this Roll Number to login for all upcoming CBT mock tests.
                  </p>

                  <button
                    type="button"
                    onClick={() => {
                      setRegisteredRollNotice(null);
                      onClose();
                    }}
                    className="w-full py-2.5 px-4 bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-sm rounded-xl transition-colors shadow-md shadow-indigo-600/20"
                  >
                    Enter Student CBT Portal →
                  </button>
                </div>
              ) : studentAuthMode === 'login-roll' ? (
                <div>
                  {/* Clean info note - NO other students shown */}
                  <div className="mb-4 bg-slate-800/60 border border-slate-700/60 rounded-xl p-3.5">
                    <div className="flex items-start gap-2.5">
                      <GraduationCap className="w-4 h-4 text-indigo-400 shrink-0 mt-0.5" />
                      <div className="text-xs">
                        <p className="font-bold text-white">Student CBT Authentication</p>
                        <p className="text-slate-400 mt-0.5 leading-relaxed">
                          Please enter your registered Full Name and Roll Number. If you are a new candidate, select <strong>Register New Student</strong> to generate your Roll Number automatically.
                        </p>
                      </div>
                    </div>
                  </div>

                  {loginRollError && (
                    <div className="mb-3 p-2.5 rounded-lg bg-rose-500/15 border border-rose-500/30 text-rose-300 text-xs flex items-center gap-2">
                      <AlertCircle className="w-4 h-4 shrink-0" />
                      <span>{loginRollError}</span>
                    </div>
                  )}

                  <form onSubmit={handleStudentRollLogin} className="space-y-3">
                    <div>
                      <label className="block text-xs font-semibold text-slate-300 mb-1">
                        Student Full Name
                      </label>
                      <div className="relative">
                        <UserIcon className="w-4 h-4 text-slate-500 absolute left-3 top-3" />
                        <input
                          type="text"
                          value={loginStudentName}
                          onChange={(e) => setLoginStudentName(e.target.value)}
                          className="w-full pl-9 pr-3 py-2 bg-slate-800 border border-slate-700 rounded-lg text-sm text-white focus:outline-none focus:border-indigo-500"
                          placeholder="Enter your registered name"
                          required
                        />
                      </div>
                    </div>

                    <div>
                      <label className="block text-xs font-semibold text-slate-300 mb-1">
                        Roll Number (Assigned by Faculty or Generated upon Registration)
                      </label>
                      <div className="relative">
                        <Hash className="w-4 h-4 text-slate-500 absolute left-3 top-3" />
                        <input
                          type="text"
                          value={loginStudentRoll}
                          onChange={(e) => setLoginStudentRoll(e.target.value)}
                          className="w-full pl-9 pr-3 py-2 bg-slate-800 border border-slate-700 rounded-lg text-sm text-white font-mono focus:outline-none focus:border-indigo-500"
                          placeholder="e.g. ARG-JEE-2026-042"
                          required
                        />
                      </div>
                    </div>

                    <button
                      type="submit"
                      className="w-full py-2.5 px-4 bg-gradient-to-r from-indigo-600 to-indigo-700 hover:from-indigo-500 hover:to-indigo-600 text-white font-bold text-sm rounded-lg shadow-md shadow-indigo-600/20 transition-all flex items-center justify-center gap-2 mt-4"
                    >
                      <span>Enter CBT Portal with Roll Number</span>
                      <ArrowRight className="w-4 h-4" />
                    </button>
                  </form>
                </div>
              ) : (
                <div>
                  {studentError && (
                    <div className="my-2 p-2.5 rounded-lg bg-rose-500/15 border border-rose-500/30 text-rose-300 text-xs flex items-center gap-2">
                      <AlertCircle className="w-4 h-4 shrink-0" />
                      <span>{studentError}</span>
                    </div>
                  )}

                  <form onSubmit={handleStudentRegisterSubmit} className="space-y-3">
                    <div>
                      <label className="block text-xs font-semibold text-slate-300 mb-1">
                        Student Full Name
                      </label>
                      <input
                        type="text"
                        value={studentName}
                        onChange={(e) => setStudentName(e.target.value)}
                        className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded-lg text-sm text-white focus:outline-none focus:border-indigo-500"
                        placeholder="e.g. Rohit Kumar"
                        required
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-semibold text-slate-300 mb-1">
                        Phone Number (for Faculty Contact)
                      </label>
                      <div className="relative">
                        <Phone className="w-3.5 h-3.5 text-slate-500 absolute left-3 top-3" />
                        <input
                          type="tel"
                          value={studentPhone}
                          onChange={(e) => setStudentPhone(e.target.value)}
                          className="w-full pl-8 pr-2 py-2 bg-slate-800 border border-slate-700 rounded-lg text-xs text-white focus:outline-none focus:border-indigo-500"
                          placeholder="+91 98765 43210"
                          required
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-2">
                      <div>
                        <label className="block text-xs font-semibold text-slate-300 mb-1">
                          Email Address
                        </label>
                        <input
                          type="email"
                          value={studentEmail}
                          onChange={(e) => setStudentEmail(e.target.value)}
                          className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded-lg text-xs text-white focus:outline-none focus:border-indigo-500"
                          placeholder="rohit@example.com"
                          required
                        />
                      </div>

                      <div>
                        <label className="block text-xs font-semibold text-slate-300 mb-1">
                          Target Exam
                        </label>
                        <select
                          value={studentExam}
                          onChange={(e) => setStudentExam(e.target.value as ExamType)}
                          className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded-lg text-xs text-white focus:outline-none focus:border-indigo-500"
                        >
                          <option value="JEE Main">JEE Main</option>
                          <option value="JEE Advanced">JEE Advanced</option>
                          <option value="NEET">NEET-UG</option>
                        </select>
                      </div>
                    </div>

                    {/* Automatic Roll Number Notice */}
                    <div className="p-3 rounded-xl bg-indigo-950/40 border border-indigo-500/30 text-xs flex items-center gap-2.5 text-indigo-200">
                      <Sparkles className="w-4 h-4 text-amber-400 shrink-0" />
                      <span>
                        Your unique <strong>Official Roll Number</strong> will be generated automatically and saved to the Faculty Admin console upon registration.
                      </span>
                    </div>

                    <button
                      type="submit"
                      className="w-full py-2.5 px-4 bg-gradient-to-r from-indigo-600 to-indigo-700 hover:from-indigo-500 hover:to-indigo-600 text-white font-bold text-sm rounded-lg shadow-md shadow-indigo-600/20 transition-all flex items-center justify-center gap-2 mt-4"
                    >
                      <span>Complete Registration & Generate Roll Number</span>
                      <ArrowRight className="w-4 h-4" />
                    </button>
                  </form>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
