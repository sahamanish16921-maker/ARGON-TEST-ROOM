import React, { useState } from 'react';
import { useApp } from '../context/AppContext.tsx';
import type {
  TestSeries,
  Test,
  Question,
  ExamType,
  SubjectSection,
  OptionKey,
  QuestionType,
  StudentTestAttempt,
  FacultyProfile,
} from '../types/index.ts';
import {
  parseBatchCsv,
  parseBatchJson,
  getSampleCsvTemplate,
  getSampleJsonTemplate,
} from '../utils/examEngine.ts';
import {
  DIAGRAM_OPTICS,
  DIAGRAM_CIRCUIT,
  DIAGRAM_GENETICS,
  INSTITUTION_UPI_QR,
} from '../data/seedData.ts';
import {
  ShieldCheck,
  Plus,
  Trash2,
  Edit,
  UploadCloud,
  FileSpreadsheet,
  Download,
  KeyRound,
  CheckCircle2,
  XCircle,
  Eye,
  QrCode,
  IndianRupee,
  BookOpen,
  Layers,
  Settings,
  BarChart2,
  Clock,
  Sparkles,
  HelpCircle,
  Image as ImageIcon,
  Check,
  X,
  FileText,
  Phone,
  UserPlus,
  Users,
  MessageCircle,
  Search,
  Hash,
  ExternalLink,
  Laptop,
  Smartphone,
  Wifi,
  Lock,
  Unlock,
  Calendar,
  ArrowUp,
  ArrowDown,
  Zap,
  Play,
  AlertCircle,
} from 'lucide-react';
import { ArgonLogo } from './ArgonLogo.tsx';
import { SerialImagePaperBuilder } from './SerialImagePaperBuilder.tsx';
import { FacultyVerificationRequests } from './FacultyVerificationRequests.tsx';

export const FacultyDashboard: React.FC = () => {
  const {
    testSeries,
    tests,
    attempts,
    students,
    verificationRequests,
    registerStudentByAdmin,
    updateStudentByAdmin,
    deleteStudentByAdmin,
    instituteUpi,
    createTestSeries,
    updateTestSeries,
    deleteTestSeries,
    createTest,
    updateTest,
    deleteTest,
    toggleTestLock,
    updateTestSubjectOrder,
    updateTestSchedule,
    addQuestion,
    updateQuestion,
    deleteQuestion,
    batchAddQuestions,
    updateQuickAnswerKey,
    updateInstituteUpi,
    setCurrentView,
    activeFacultyDevices,
    revokeFacultyDevice,
    currentDeviceId,
    notices,
    materials,
    createNotice,
    deleteNotice,
    createMaterial,
    deleteMaterial,
    facultyProfiles,
    createFacultyProfile,
    updateFacultyProfile,
    deleteFacultyProfile,
    saveTestToCloud,
    lastSyncTime,
    isSupabaseConnected,
  } = useApp();

  const [isDeviceModalOpen, setIsDeviceModalOpen] = useState(false);

  // Dedicated Toast for Permanent Cloud Supabase saving
  const [saveCloudToast, setSaveCloudToast] = useState<{ show: boolean; message: string; isError: boolean }>({
    show: false,
    message: '',
    isError: false,
  });
  const [savingTestId, setSavingTestId] = useState<string | null>(null);

  // Quick Schedule Modal State
  const [scheduleModalTest, setScheduleModalTest] = useState<Test | null>(null);
  const [schedStartInput, setSchedStartInput] = useState('');
  const [schedEndInput, setSchedEndInput] = useState('');
  const [schedIsActive, setSchedIsActive] = useState(false);

  // Quick Subject Order Modal State
  const [orderModalTest, setOrderModalTest] = useState<Test | null>(null);
  const [orderSubjects, setOrderSubjects] = useState<SubjectSection[]>([]);

  // Navigation tab
  const [activeTab, setActiveTab] = useState<
    | 'series'
    | 'tests'
    | 'serial-images'
    | 'creator'
    | 'quick-key'
    | 'register-student'
    | 'enrolled-students'
    | 'verifications'
    | 'results'
    | 'upi'
    | 'notices'
    | 'materials'
    | 'faculty-bios'
  >('series');

  // Faculty Bios Modal & Form State
  const [isFacultyModalOpen, setIsFacultyModalOpen] = useState(false);
  const [editingFaculty, setEditingFaculty] = useState<FacultyProfile | null>(null);
  const [facultyForm, setFacultyForm] = useState({
    name: '',
    role: '',
    department: 'Physics',
    qualification: '',
    avatar: '',
    bio: '',
    subjects: '',
    trackRecord: '',
    quote: '',
    email: '',
    phone: '',
    availableTimings: '',
  });
  const [facultySuccessMsg, setFacultySuccessMsg] = useState('');

  // Form states for Notices & Materials
  const [noticeTitle, setNoticeTitle] = useState('');
  const [noticeContent, setNoticeContent] = useState('');
  const [noticeTargetExam, setNoticeTargetExam] = useState<ExamType | 'All'>('All');
  const [noticePriority, setNoticePriority] = useState<'normal' | 'urgent'>('normal');
  const [noticeAuthor, setNoticeAuthor] = useState('Dr. H. P. Deshmukh (Academic Director)');
  const [noticeSuccessMsg, setNoticeSuccessMsg] = useState('');

  const [matTitle, setMatTitle] = useState('');
  const [matCategory, setMatCategory] = useState<'JEE' | 'NEET' | 'FORMULAS' | 'ALL'>('JEE');
  const [matType, setMatType] = useState('PDF Formula Sheet');
  const [matDescription, setMatDescription] = useState('');
  const [matSize, setMatSize] = useState('4.2 MB');
  const [matIsHot, setMatIsHot] = useState(false);
  const [matSuccessMsg, setMatSuccessMsg] = useState('');

  // Selected test for question editing or quick key
  const [selectedTestId, setSelectedTestId] = useState<string>(
    tests[0]?.id || ''
  );

  const pendingRequestsCount = (verificationRequests || []).filter(
    (r) => r.status === 'pending'
  ).length;

  // Student registration by admin form state
  const [newStudentName, setNewStudentName] = useState('');
  const [newStudentRoll, setNewStudentRoll] = useState('ARG-JEE-2026-150');
  const [newStudentPhone, setNewStudentPhone] = useState('+91 98765 43210');
  const [newStudentExam, setNewStudentExam] = useState<ExamType>('JEE Advanced');
  const [newStudentEmail, setNewStudentEmail] = useState('');
  const [newStudentSeriesIds, setNewStudentSeriesIds] = useState<string[]>([
    testSeries[0]?.id || 'series-jee-adv-2026',
  ]);
  const [studentRegSuccessMsg, setStudentRegSuccessMsg] = useState('');
  const [lastRegisteredStudent, setLastRegisteredStudent] = useState<{
    name: string;
    rollNo: string;
    phone: string;
    exam: string;
  } | null>(null);

  // Enrolled student lookup and dossier state
  const [searchStudentName, setSearchStudentName] = useState('Aryan Sharma');
  const [searchStudentRoll, setSearchStudentRoll] = useState('ARG-JEE-2026-042');
  const [selectedStudentRoll, setSelectedStudentRoll] = useState<string>(
    students[0]?.rollNo || 'ARG-JEE-2026-042'
  );

  // Modal states
  const [isSeriesModalOpen, setIsSeriesModalOpen] = useState(false);
  const [editingSeries, setEditingSeries] = useState<TestSeries | null>(null);

  const [isTestModalOpen, setIsTestModalOpen] = useState(false);
  const [editingTest, setEditingTest] = useState<Test | null>(null);

  const [isBatchModalOpen, setIsBatchModalOpen] = useState(false);
  const [batchFormat, setBatchFormat] = useState<'csv' | 'json'>('csv');
  const [batchRawText, setBatchRawText] = useState('');
  const [batchParsedResult, setBatchParsedResult] = useState<{
    questions: Question[];
    errors: string[];
  } | null>(null);

  // Single Question Form State
  const [qSection, setQSection] = useState<SubjectSection>('Physics');
  const [qType, setQType] = useState<QuestionType>('mcq');
  const [qText, setQText] = useState('');
  const [qImageUrl, setQImageUrl] = useState('');
  const [qOptA, setQOptA] = useState('');
  const [qOptB, setQOptB] = useState('');
  const [qOptC, setQOptC] = useState('');
  const [qOptD, setQOptD] = useState('');
  const [qCorrect, setQCorrect] = useState('A');
  const [qPosMarks, setQPosMarks] = useState(4);
  const [qNegMarks, setQNegMarks] = useState(1);
  const [qExplanation, setQExplanation] = useState('');
  const [qExplanationImageUrl, setQExplanationImageUrl] = useState('');
  const [editingQuestionId, setEditingQuestionId] = useState<string | null>(null);

  // Student Attempt inspect modal
  const [inspectAttempt, setInspectAttempt] = useState<StudentTestAttempt | null>(
    null
  );

  // Form states for Series
  const [seriesForm, setSeriesForm] = useState({
    title: '',
    category: 'JEE Advanced Mock',
    targetExam: 'JEE Advanced' as ExamType,
    price: 499,
    originalPrice: 1499,
    description: '',
    badge: 'Trending',
  });

  // Form states for Test
  const [testForm, setTestForm] = useState<{
    title: string;
    seriesId: string;
    examType: ExamType;
    durationMinutes: number;
    description: string;
    sections: SubjectSection[];
    isLockedByFaculty: boolean;
    subjectOrder: SubjectSection[];
    isScheduled: boolean;
    scheduledStartTime: string;
    scheduledEndTime: string;
  }>({
    title: '',
    seriesId: testSeries[0]?.id || '',
    examType: 'JEE Advanced' as ExamType,
    durationMinutes: 60,
    description: '',
    sections: ['Physics', 'Chemistry', 'Mathematics'] as SubjectSection[],
    isLockedByFaculty: false,
    subjectOrder: ['Physics', 'Chemistry', 'Mathematics'] as SubjectSection[],
    isScheduled: false,
    scheduledStartTime: '',
    scheduledEndTime: '',
  });

  // UPI Form state
  const [upiSettingsForm, setUpiSettingsForm] = useState({
    upiId: instituteUpi.upiId,
    merchantName: instituteUpi.merchantName,
    qrUrl: instituteUpi.qrUrl,
    note: instituteUpi.note,
  });
  const [upiSavedSuccess, setUpiSavedSuccess] = useState(false);

  const currentSelectedTest = tests.find((t) => t.id === selectedTestId);

  // Open Edit Series
  const handleOpenEditSeries = (series: TestSeries) => {
    setEditingSeries(series);
    setSeriesForm({
      title: series.title,
      category: series.category,
      targetExam: series.targetExam,
      price: series.price,
      originalPrice: series.originalPrice || 0,
      description: series.description,
      badge: series.badge || '',
    });
    setIsSeriesModalOpen(true);
  };

  const handleSaveSeries = (e: React.FormEvent) => {
    e.preventDefault();
    if (editingSeries) {
      updateTestSeries(editingSeries.id, {
        title: seriesForm.title,
        category: seriesForm.category,
        targetExam: seriesForm.targetExam,
        price: Number(seriesForm.price),
        originalPrice: Number(seriesForm.originalPrice),
        description: seriesForm.description,
        badge: seriesForm.badge,
      });
    } else {
      createTestSeries({
        title: seriesForm.title,
        category: seriesForm.category,
        targetExam: seriesForm.targetExam,
        price: Number(seriesForm.price),
        originalPrice: Number(seriesForm.originalPrice),
        description: seriesForm.description,
        badge: seriesForm.badge,
        features: [
          'Authentic NTA CBT interface',
          'Detailed Step-by-Step Solutions',
          'Instant Percentile Predictor',
        ],
        upiId: instituteUpi.upiId,
        upiQrUrl: instituteUpi.qrUrl,
        paymentNote: 'Scan institute UPI QR code to unlock test series.',
      });
    }
    setIsSeriesModalOpen(false);
    setEditingSeries(null);
  };

  // Open Edit Test
  const handleOpenEditTest = (test: Test) => {
    setEditingTest(test);
    const rawSections = test.sections.length > 0 ? test.sections : (['Physics', 'Chemistry', 'Mathematics'] as SubjectSection[]);
    const initialOrder =
      test.subjectOrder && test.subjectOrder.length > 0
        ? test.subjectOrder
        : rawSections;

    setTestForm({
      title: test.title,
      seriesId: test.seriesId,
      examType: test.examType,
      durationMinutes: test.durationMinutes,
      description: test.description,
      sections: test.sections,
      isLockedByFaculty: !!test.isLockedByFaculty,
      subjectOrder: initialOrder,
      isScheduled: !!test.isScheduled,
      scheduledStartTime: test.scheduledStartTime || '',
      scheduledEndTime: test.scheduledEndTime || '',
    });
    setIsTestModalOpen(true);
  };

  const handleSaveTest = async (e: React.FormEvent) => {
    e.preventDefault();
    if (editingTest) {
      await updateTest(editingTest.id, {
        title: testForm.title,
        seriesId: testForm.seriesId,
        examType: testForm.examType,
        durationMinutes: Number(testForm.durationMinutes),
        description: testForm.description,
        sections: testForm.sections,
        isLockedByFaculty: testForm.isLockedByFaculty,
        subjectOrder: testForm.subjectOrder,
        isScheduled: testForm.isScheduled,
        scheduledStartTime: testForm.scheduledStartTime || undefined,
        scheduledEndTime: testForm.scheduledEndTime || undefined,
      });
    } else {
      const newId = await createTest({
        title: testForm.title,
        seriesId: testForm.seriesId,
        examType: testForm.examType,
        durationMinutes: Number(testForm.durationMinutes),
        totalMarks: 0,
        description: testForm.description,
        sections: testForm.sections,
        questions: [],
        isPublished: true,
        isLockedByFaculty: testForm.isLockedByFaculty,
        subjectOrder: testForm.subjectOrder,
        isScheduled: testForm.isScheduled,
        scheduledStartTime: testForm.scheduledStartTime || undefined,
        scheduledEndTime: testForm.scheduledEndTime || undefined,
      });
      setSelectedTestId(newId);
    }
    setIsTestModalOpen(false);
    setEditingTest(null);
  };

  // Reset Single Question Form
  const resetQuestionForm = () => {
    setEditingQuestionId(null);
    setQText('');
    setQImageUrl('');
    setQOptA('');
    setQOptB('');
    setQOptC('');
    setQOptD('');
    setQCorrect('A');
    setQPosMarks(4);
    setQNegMarks(1);
    setQExplanation('');
    setQExplanationImageUrl('');
  };

  const handleEditQuestion = (q: Question) => {
    setEditingQuestionId(q.id);
    setQSection(q.section);
    setQType(q.type);
    setQText(q.text);
    setQImageUrl(q.imageUrl || '');
    setQOptA(q.options.find((o) => o.key === 'A')?.text || '');
    setQOptB(q.options.find((o) => o.key === 'B')?.text || '');
    setQOptC(q.options.find((o) => o.key === 'C')?.text || '');
    setQOptD(q.options.find((o) => o.key === 'D')?.text || '');
    setQCorrect(String(q.correctAnswer));
    setQPosMarks(q.positiveMarks);
    setQNegMarks(q.negativeMarks);
    setQExplanation(q.explanation || '');
    setQExplanationImageUrl(q.explanationImageUrl || '');
    setActiveTab('creator');
  };

  const handleSaveQuestion = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedTestId) return;

    const options =
      qType === 'mcq'
        ? [
            { key: 'A' as OptionKey, text: qOptA || 'Option A' },
            { key: 'B' as OptionKey, text: qOptB || 'Option B' },
            { key: 'C' as OptionKey, text: qOptC || 'Option C' },
            { key: 'D' as OptionKey, text: qOptD || 'Option D' },
          ]
        : [];

    if (editingQuestionId) {
      updateQuestion(selectedTestId, editingQuestionId, {
        section: qSection,
        type: qType,
        text: qText,
        imageUrl: qImageUrl.trim() || undefined,
        options,
        correctAnswer: qCorrect,
        positiveMarks: Number(qPosMarks),
        negativeMarks: Number(qNegMarks),
        explanation: qExplanation,
        explanationImageUrl: qExplanationImageUrl.trim() || undefined,
      });
    } else {
      addQuestion(selectedTestId, {
        section: qSection,
        type: qType,
        text: qText,
        imageUrl: qImageUrl.trim() || undefined,
        options,
        correctAnswer: qCorrect,
        positiveMarks: Number(qPosMarks),
        negativeMarks: Number(qNegMarks),
        explanation: qExplanation,
        explanationImageUrl: qExplanationImageUrl.trim() || undefined,
      });
    }
    resetQuestionForm();
  };

  // Image Upload helper for Question Diagram
  const handleImageFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setQImageUrl(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  // Image Upload helper for Solution Step Derivation
  const handleSolutionImageFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setQExplanationImageUrl(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  // Dedicated Save Test & Answer Key to Supabase Cloud
  const handleSaveTestToCloud = async (testId: string) => {
    setSavingTestId(testId);
    try {
      const res = await saveTestToCloud(testId);
      setSaveCloudToast({ show: true, message: res.message, isError: !res.success });
    } catch {
      setSaveCloudToast({ show: true, message: 'Failed to sync test to Supabase Cloud', isError: true });
    } finally {
      setSavingTestId(null);
      setTimeout(() => {
        setSaveCloudToast((prev) => ({ ...prev, show: false }));
      }, 4000);
    }
  };

  // Faculty Profile Management Handlers
  const handleOpenAddFaculty = () => {
    setEditingFaculty(null);
    setFacultyForm({
      name: '',
      role: 'Senior Faculty',
      department: 'Physics',
      qualification: 'B.Tech / M.Sc.',
      avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=400&q=80',
      bio: '',
      subjects: 'Mechanics, Rotational Dynamics',
      trackRecord: 'Mentored top rankers in JEE & NEET',
      quote: '"Conceptual clarity is the foundation of competitive rank."',
      email: 'faculty@argoncoaching.com',
      phone: '+91 60007 30250',
      availableTimings: 'Mon-Sat: 4:00 PM - 7:00 PM (Doubt Room)',
    });
    setIsFacultyModalOpen(true);
  };

  const handleOpenEditFaculty = (fac: FacultyProfile) => {
    setEditingFaculty(fac);
    setFacultyForm({
      name: fac.name,
      role: fac.role,
      department: fac.department || 'Physics',
      qualification: fac.qualification,
      avatar: fac.avatar,
      bio: fac.bio,
      subjects: (fac.subjects || []).join(', '),
      trackRecord: fac.trackRecord,
      quote: fac.quote,
      email: fac.email || '',
      phone: fac.phone || '',
      availableTimings: fac.availableTimings || '',
    });
    setIsFacultyModalOpen(true);
  };

  const handleSaveFaculty = async (e: React.FormEvent) => {
    e.preventDefault();
    const subjectsArray = facultyForm.subjects
      .split(',')
      .map((s) => s.trim())
      .filter(Boolean);

    if (editingFaculty) {
      await updateFacultyProfile(editingFaculty.id, {
        name: facultyForm.name,
        role: facultyForm.role,
        department: facultyForm.department,
        qualification: facultyForm.qualification,
        avatar: facultyForm.avatar,
        bio: facultyForm.bio,
        subjects: subjectsArray,
        trackRecord: facultyForm.trackRecord,
        quote: facultyForm.quote,
        email: facultyForm.email,
        phone: facultyForm.phone,
        availableTimings: facultyForm.availableTimings,
      });
      setFacultySuccessMsg('Faculty bio & credentials updated and live synced to student devices!');
    } else {
      await createFacultyProfile({
        name: facultyForm.name,
        role: facultyForm.role,
        department: facultyForm.department,
        qualification: facultyForm.qualification,
        avatar: facultyForm.avatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=400&q=80',
        bio: facultyForm.bio,
        subjects: subjectsArray,
        trackRecord: facultyForm.trackRecord,
        quote: facultyForm.quote,
        email: facultyForm.email,
        phone: facultyForm.phone,
        availableTimings: facultyForm.availableTimings,
      });
      setFacultySuccessMsg('New faculty mentor added and live synced to student devices!');
    }

    setIsFacultyModalOpen(false);
    setTimeout(() => setFacultySuccessMsg(''), 4000);
  };

  const handleFacultyAvatarFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setFacultyForm((prev) => ({ ...prev, avatar: reader.result as string }));
      };
      reader.readAsDataURL(file);
    }
  };

  // Batch Parser Trigger
  const handleValidateBatch = () => {
    if (!batchRawText.trim()) {
      setBatchParsedResult({ questions: [], errors: ['Please paste or upload content first.'] });
      return;
    }

    if (batchFormat === 'csv') {
      const res = parseBatchCsv(batchRawText);
      setBatchParsedResult(res);
    } else {
      const res = parseBatchJson(batchRawText);
      setBatchParsedResult(res);
    }
  };

  const handleImportBatchQuestions = () => {
    if (!selectedTestId || !batchParsedResult || batchParsedResult.questions.length === 0) return;
    batchAddQuestions(selectedTestId, batchParsedResult.questions);
    setIsBatchModalOpen(false);
    setBatchRawText('');
    setBatchParsedResult(null);
  };

  // Sample template downloader
  const downloadTemplate = (format: 'csv' | 'json') => {
    const content = format === 'csv' ? getSampleCsvTemplate() : getSampleJsonTemplate();
    const mime = format === 'csv' ? 'text/csv' : 'application/json';
    const blob = new Blob([content], { type: mime });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `argon_questions_template.${format}`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const generateStudentRoll = (exam: ExamType) => {
    const prefix = exam === 'NEET' ? 'ARG-NEET' : exam === 'JEE Advanced' ? 'ARG-JEE' : 'ARG-JM';
    return `${prefix}-2026-${Math.floor(100 + Math.random() * 900)}`;
  };

  const handleAdminRegisterStudent = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newStudentName.trim() || !newStudentRoll.trim() || !newStudentPhone.trim()) return;

    registerStudentByAdmin({
      name: newStudentName.trim(),
      rollNo: newStudentRoll.trim(),
      phone: newStudentPhone.trim(),
      targetExam: newStudentExam,
      email: newStudentEmail.trim() || undefined,
      enrolledSeriesIds: newStudentSeriesIds,
    });

    setLastRegisteredStudent({
      name: newStudentName.trim(),
      rollNo: newStudentRoll.trim(),
      phone: newStudentPhone.trim(),
      exam: newStudentExam,
    });

    setSelectedStudentRoll(newStudentRoll.trim());
    setSearchStudentRoll(newStudentRoll.trim());
    setSearchStudentName(newStudentName.trim());

    setStudentRegSuccessMsg(
      `Student "${newStudentName.trim()}" successfully registered! The candidate will log in using Name "${newStudentName.trim()}" and Roll Number "${newStudentRoll.trim()}".`
    );

    setNewStudentName('');
    setNewStudentRoll(generateStudentRoll(newStudentExam));
    setNewStudentEmail('');
    setTimeout(() => setStudentRegSuccessMsg(''), 10000);
  };

  const handleSaveUpi = (e: React.FormEvent) => {
    e.preventDefault();
    updateInstituteUpi(upiSettingsForm);
    setUpiSavedSuccess(true);
    setTimeout(() => setUpiSavedSuccess(false), 3000);
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 pb-16 relative">
      {/* Floating Cloud Save Toast */}
      {saveCloudToast.show && (
        <div className="fixed top-5 right-5 z-50 animate-bounce">
          <div
            className={`px-4 py-3 rounded-2xl shadow-2xl flex items-center gap-3 border text-xs font-bold ${
              saveCloudToast.isError
                ? 'bg-rose-950/90 text-rose-200 border-rose-500/50 shadow-rose-950/50'
                : 'bg-emerald-950/90 text-emerald-200 border-emerald-500/50 shadow-emerald-950/50'
            }`}
          >
            {saveCloudToast.isError ? (
              <AlertCircle className="w-5 h-5 text-rose-400 shrink-0" />
            ) : (
              <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />
            )}
            <div>
              <p className="font-extrabold">{saveCloudToast.isError ? 'Sync Notice' : 'Permanent Cloud Save Confirmed'}</p>
              <p className="text-[11px] font-normal opacity-90">{saveCloudToast.message}</p>
            </div>
            <button
              onClick={() => setSaveCloudToast((prev) => ({ ...prev, show: false }))}
              className="ml-2 text-slate-400 hover:text-white"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}

      {/* Top Banner / Breadcrumb */}
      <div className="bg-slate-900 border-b border-slate-800 py-6 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div className="flex flex-col sm:flex-row sm:items-center gap-3">
            <ArgonLogo size="md" theme="dark" />
            <div className="hidden sm:block h-6 w-px bg-slate-700" />
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-lg font-bold text-white tracking-tight">
                  Faculty Examination Portal
                </h1>
                <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-amber-500/20 text-amber-300 border border-amber-500/30">
                  Admin Control
                </span>
              </div>
              <p className="text-[11px] text-slate-400">
                Automated Test Scheduling, Subject Sequencing & Paper Lock Controls
              </p>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <button
              onClick={() => setIsDeviceModalOpen(true)}
              className="px-3 py-2 text-xs font-bold bg-slate-800/90 hover:bg-slate-750 border border-slate-700 text-slate-200 rounded-xl transition-all shadow-sm flex items-center gap-2"
              title="Faculty Device Security: Max 2 Devices Allowed"
            >
              <Laptop className="w-3.5 h-3.5 text-amber-400" />
              <span>
                Devices: <strong className="text-amber-300 font-mono">{activeFacultyDevices?.length || 1}/2</strong> Active
              </span>
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" title="Cross-Student Live Sync Active"></span>
            </button>

            <button
              onClick={() => {
                setEditingSeries(null);
                setSeriesForm({
                  title: '',
                  category: 'JEE Advanced Mock',
                  targetExam: 'JEE Advanced',
                  price: 499,
                  originalPrice: 1499,
                  description: '',
                  badge: 'New',
                });
                setIsSeriesModalOpen(true);
              }}
              className="px-3.5 py-2 text-xs font-bold bg-amber-500 hover:bg-amber-400 text-slate-950 rounded-xl transition-all shadow-md shadow-amber-500/20 flex items-center gap-1.5"
            >
              <Plus className="w-4 h-4" />
              New Test Series
            </button>
            <button
              onClick={() => {
                setEditingTest(null);
                setTestForm({
                  title: '',
                  seriesId: testSeries[0]?.id || '',
                  examType: 'JEE Advanced',
                  durationMinutes: 60,
                  description: '',
                  sections: ['Physics', 'Chemistry', 'Mathematics'],
                  isLockedByFaculty: false,
                  subjectOrder: ['Physics', 'Chemistry', 'Mathematics'],
                  isScheduled: false,
                  scheduledStartTime: '',
                  scheduledEndTime: '',
                });
                setIsTestModalOpen(true);
              }}
              className="px-3.5 py-2 text-xs font-bold bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl transition-all shadow-md shadow-indigo-600/20 flex items-center gap-1.5"
            >
              <Plus className="w-4 h-4" />
              New Test Paper
            </button>
          </div>

          {/* Pending Verification Notice Banner */}
          {pendingRequestsCount > 0 && (
            <div className="mt-4 bg-gradient-to-r from-amber-500/15 via-amber-500/10 to-transparent border border-amber-500/30 rounded-2xl p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-amber-500/20 border border-amber-500/40 flex items-center justify-center text-amber-400 shrink-0">
                  <Clock className="w-5 h-5 animate-pulse" />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-sm font-bold text-white">
                      {pendingRequestsCount} Pending Payment Verification Request{pendingRequestsCount > 1 ? 's' : ''}
                    </span>
                    <span className="px-2 py-0.5 rounded-full bg-amber-500 text-slate-950 text-[10px] font-black uppercase tracking-wider">
                      Action Required
                    </span>
                  </div>
                  <p className="text-xs text-slate-300 mt-0.5">
                    Students submitted UPI payments. Test access is locked until verified and accepted by Admin.
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setActiveTab('verifications')}
                className="px-4 py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs rounded-xl shadow-md transition-all shrink-0"
              >
                Review & Accept Requests →
              </button>
            </div>
          )}
        </div>

        {/* Dashboard Navigation Tabs */}
        <div className="max-w-7xl mx-auto mt-6 flex flex-wrap gap-2 border-b border-slate-800 pb-1">
          <button
            onClick={() => setActiveTab('series')}
            className={`px-3.5 py-2 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 ${
              activeTab === 'series'
                ? 'bg-amber-500 text-slate-950 shadow-sm'
                : 'text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
          >
            <Layers className="w-4 h-4" />
            1. Test Series ({testSeries.length})
          </button>

          <button
            onClick={() => setActiveTab('tests')}
            className={`px-3.5 py-2 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 ${
              activeTab === 'tests'
                ? 'bg-amber-500 text-slate-950 shadow-sm'
                : 'text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
          >
            <BookOpen className="w-4 h-4" />
            2. Test Papers ({tests.length})
          </button>

          <button
            onClick={() => setActiveTab('serial-images')}
            className={`px-3.5 py-2 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 ${
              activeTab === 'serial-images'
                ? 'bg-amber-500 text-slate-950 shadow-sm'
                : 'text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
            title="Add questions serially with image in each number one by one for Physics, Chemistry, Biology, Maths"
          >
            <ImageIcon className="w-4 h-4 text-indigo-400" />
            3. Serial Image Paper Builder
          </button>

          <button
            onClick={() => setActiveTab('creator')}
            className={`px-3.5 py-2 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 ${
              activeTab === 'creator'
                ? 'bg-amber-500 text-slate-950 shadow-sm'
                : 'text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
          >
            <Edit className="w-4 h-4" />
            4. Standard Creator
          </button>

          <button
            onClick={() => setActiveTab('quick-key')}
            className={`px-3.5 py-2 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 ${
              activeTab === 'quick-key'
                ? 'bg-amber-500 text-slate-950 shadow-sm'
                : 'text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
          >
            <KeyRound className="w-4 h-4" />
            5. Quick Answer Key Matrix
          </button>

          <button
            onClick={() => setActiveTab('register-student')}
            className={`px-3.5 py-2 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 ${
              activeTab === 'register-student'
                ? 'bg-amber-500 text-slate-950 shadow-sm'
                : 'text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
          >
            <UserPlus className="w-4 h-4" />
            6. New Register Student
          </button>

          <button
            onClick={() => setActiveTab('enrolled-students')}
            className={`px-3.5 py-2 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 ${
              activeTab === 'enrolled-students'
                ? 'bg-amber-500 text-slate-950 shadow-sm'
                : 'text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
          >
            <Users className="w-4 h-4" />
            7. Enrolled Students ({students.length})
          </button>

          <button
            onClick={() => setActiveTab('verifications')}
            className={`px-3.5 py-2 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 relative ${
              activeTab === 'verifications'
                ? 'bg-amber-500 text-slate-950 shadow-sm'
                : 'text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
          >
            <ShieldCheck className="w-4 h-4" />
            8. Verification Requests ({verificationRequests?.length || 0})
            {pendingRequestsCount > 0 && (
              <span
                className={`px-1.5 py-0.2 rounded-full text-[10px] font-black ${
                  activeTab === 'verifications'
                    ? 'bg-slate-950 text-amber-300'
                    : 'bg-amber-500 text-slate-950 animate-pulse'
                }`}
              >
                {pendingRequestsCount} Pending
              </span>
            )}
          </button>

          <button
            onClick={() => setActiveTab('results')}
            className={`px-3.5 py-2 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 ${
              activeTab === 'results'
                ? 'bg-amber-500 text-slate-950 shadow-sm'
                : 'text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
          >
            <BarChart2 className="w-4 h-4" />
            9. All Submissions ({attempts.length})
          </button>

          <button
            onClick={() => setActiveTab('upi')}
            className={`px-3.5 py-2 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 ${
              activeTab === 'upi'
                ? 'bg-amber-500 text-slate-950 shadow-sm'
                : 'text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
          >
            <QrCode className="w-4 h-4" />
            10. UPI Settings
          </button>

          <button
            onClick={() => setActiveTab('notices')}
            className={`px-3.5 py-2 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 ${
              activeTab === 'notices'
                ? 'bg-amber-500 text-slate-950 shadow-sm'
                : 'text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
          >
            <MessageCircle className="w-4 h-4" />
            11. Notices ({notices.length})
          </button>
          <button
            onClick={() => setActiveTab('materials')}
            className={`px-3.5 py-2 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 ${
              activeTab === 'materials'
                ? 'bg-amber-500 text-slate-950 shadow-sm'
                : 'text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
          >
            <FileText className="w-4 h-4" />
            12. Study Materials ({materials.length})
          </button>

          <button
            onClick={() => setActiveTab('faculty-bios')}
            className={`px-3.5 py-2 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 ${
              activeTab === 'faculty-bios'
                ? 'bg-amber-500 text-slate-950 shadow-sm'
                : 'text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
          >
            <Users className="w-4 h-4 text-emerald-400" />
            13. Faculty Bios & Mentors ({facultyProfiles?.length || 0})
          </button>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mt-8">
        {/* ================= TAB 1: TEST SERIES ================= */}
        {activeTab === 'series' && (
          <div className="space-y-6">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-xl font-bold text-white">Test Series Categories & Packages</h2>
                <p className="text-xs text-slate-400">
                  Organize tests into specialized batches with custom pricing and attached UPI payment QR
                </p>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {testSeries.map((series) => (
                <div
                  key={series.id}
                  className="bg-slate-900 border border-slate-800 rounded-2xl p-5 hover:border-slate-700 transition-all flex flex-col justify-between"
                >
                  <div>
                    <div className="flex items-center justify-between mb-3">
                      <span className="text-[10px] font-bold px-2.5 py-0.5 rounded-full uppercase bg-slate-800 text-amber-400 border border-slate-700">
                        {series.category}
                      </span>
                      <span className="text-xs font-bold text-slate-300">
                        {series.targetExam}
                      </span>
                    </div>

                    <h3 className="font-extrabold text-lg text-white mb-2">{series.title}</h3>
                    <p className="text-xs text-slate-400 line-clamp-3 mb-4">{series.description}</p>

                    <div className="bg-slate-950/60 rounded-xl p-3 border border-slate-800/80 mb-4 space-y-2">
                      <div className="flex items-center justify-between text-xs">
                        <span className="text-slate-400">Series Fee / Pricing:</span>
                        <span className="font-bold text-white">
                          {series.price === 0 ? 'FREE' : `₹ ${series.price}`}
                        </span>
                      </div>
                      <div className="flex items-center justify-between text-xs">
                        <span className="text-slate-400">Attached UPI ID:</span>
                        <span className="font-mono text-amber-300 text-[11px] truncate max-w-[150px]">
                          {series.upiId || instituteUpi.upiId}
                        </span>
                      </div>
                      <div className="flex items-center justify-between text-xs">
                        <span className="text-slate-400">Tests Contained:</span>
                        <span className="font-semibold text-slate-200">
                          {tests.filter((t) => t.seriesId === series.id).length} Tests
                        </span>
                      </div>
                      <div className="flex items-center justify-between text-xs">
                        <span className="text-slate-400">Enrolled Students:</span>
                        <span className="font-semibold text-emerald-400">
                          {series.enrolledCount || 0} Aspirants
                        </span>
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-800">
                    <button
                      onClick={() => handleOpenEditSeries(series)}
                      className="p-2 text-xs font-semibold text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-700 rounded-lg transition-colors flex items-center gap-1.5"
                    >
                      <Edit className="w-3.5 h-3.5" />
                      Edit Series
                    </button>
                    <button
                      onClick={() => {
                        if (confirm(`Delete series "${series.title}" and its tests?`)) {
                          deleteTestSeries(series.id);
                        }
                      }}
                      className="p-2 text-xs font-semibold text-rose-400 hover:text-rose-300 bg-rose-950/30 hover:bg-rose-950/50 rounded-lg transition-colors"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* ================= TAB 2: TEST PAPERS ================= */}
        {activeTab === 'tests' && (
          <div className="space-y-6">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-xl font-bold text-white">Created Test Papers</h2>
                <p className="text-xs text-slate-400">
                  Individual NTA examination papers with timings, section syllabus, and marks
                </p>
              </div>
            </div>

            <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead className="bg-slate-950 text-slate-400 uppercase tracking-wider font-semibold border-b border-slate-800">
                    <tr>
                      <th className="py-3 px-4">Test Title & Series</th>
                      <th className="py-3 px-4">Exam & Duration</th>
                      <th className="py-3 px-4">1st Subject (Order)</th>
                      <th className="py-3 px-4">Automated Schedule</th>
                      <th className="py-3 px-4 text-center">Faculty Lock Status</th>
                      <th className="py-3 px-4 text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800 text-slate-300">
                    {tests.map((test) => {
                      const parentSeries = testSeries.find((s) => s.id === test.seriesId);
                      const isLocked = !!test.isLockedByFaculty;
                      const hasSchedule = !!test.isScheduled && !!test.scheduledStartTime;
                      const isUpcoming =
                        hasSchedule &&
                        new Date().getTime() < new Date(test.scheduledStartTime!).getTime();
                      const isEnded =
                        test.scheduledEndTime &&
                        new Date().getTime() > new Date(test.scheduledEndTime).getTime();

                      const currentOrder =
                        test.subjectOrder && test.subjectOrder.length > 0
                          ? test.subjectOrder
                          : test.sections.length > 0
                          ? test.sections
                          : (['Physics'] as SubjectSection[]);
                      const firstSubject = currentOrder[0];

                      return (
                        <tr key={test.id} className="hover:bg-slate-800/40 transition-colors">
                          <td className="py-3 px-4 max-w-xs">
                            <p className="font-bold text-white truncate">{test.title}</p>
                            <p className="text-[11px] text-slate-400 truncate">
                              {parentSeries?.title || 'Standalone Series'} • {test.questions.length} Qs ({test.totalMarks} M)
                            </p>
                          </td>

                          <td className="py-3 px-4">
                            <div className="flex items-center gap-1.5 flex-wrap">
                              <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-slate-800 text-amber-300 border border-slate-700">
                                {test.examType}
                              </span>
                              <span className="text-xs text-slate-300 font-mono flex items-center gap-1">
                                <Clock className="w-3 h-3 text-amber-400" />
                                {test.durationMinutes}m CBT Timer
                              </span>
                            </div>
                          </td>

                          {/* Subject Order Column */}
                          <td className="py-3 px-4">
                            <div className="flex items-center gap-2">
                              <div className="flex items-center gap-1">
                                <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-amber-500/20 text-amber-300 border border-amber-500/40">
                                  ★ 1st: {firstSubject}
                                </span>
                                {currentOrder.length > 1 && (
                                  <span className="text-[10px] text-slate-400">
                                    ➔ {currentOrder[1]} {currentOrder.length > 2 && '...'}
                                  </span>
                                )}
                              </div>
                              <button
                                type="button"
                                onClick={() => {
                                  setOrderModalTest(test);
                                  setOrderSubjects(currentOrder);
                                }}
                                className="px-2 py-0.5 text-[10px] font-semibold bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 rounded transition-colors"
                                title="Reorder which subject appears first"
                              >
                                Reorder
                              </button>
                            </div>
                          </td>

                          {/* Automated Schedule Column */}
                          <td className="py-3 px-4">
                            <div className="flex items-center gap-2">
                              {hasSchedule ? (
                                <div>
                                  <div className="flex items-center gap-1">
                                    <span
                                      className={`w-2 h-2 rounded-full ${
                                        isUpcoming
                                          ? 'bg-indigo-400 animate-pulse'
                                          : isEnded
                                          ? 'bg-slate-500'
                                          : 'bg-emerald-400 animate-ping'
                                      }`}
                                    />
                                    <span className="text-[10px] font-bold text-white">
                                      {isUpcoming
                                        ? 'Upcoming'
                                        : isEnded
                                        ? 'Window Closed'
                                        : 'Auto-Triggered'}
                                    </span>
                                  </div>
                                  <p className="text-[10px] text-slate-400 mt-0.5">
                                    {new Date(test.scheduledStartTime!).toLocaleTimeString([], {
                                      hour: '2-digit',
                                      minute: '2-digit',
                                      day: 'numeric',
                                      month: 'short',
                                    })}
                                  </p>
                                </div>
                              ) : (
                                <span className="text-[11px] text-slate-400 font-medium">
                                  ⚡ Always Live
                                </span>
                              )}
                              <button
                                type="button"
                                onClick={() => {
                                  setScheduleModalTest(test);
                                  setSchedStartInput(test.scheduledStartTime || '');
                                  setSchedEndInput(test.scheduledEndTime || '');
                                  setSchedIsActive(!!test.isScheduled);
                                }}
                                className="px-2 py-0.5 text-[10px] font-semibold bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 rounded transition-colors flex items-center gap-1"
                              >
                                <Calendar className="w-3 h-3 text-indigo-400" />
                                {hasSchedule ? 'Edit Schedule' : 'Schedule'}
                              </button>
                            </div>
                          </td>

                          {/* 1-Click Faculty Lock Toggle Column */}
                          <td className="py-3 px-4 text-center">
                            <button
                              type="button"
                              onClick={() => toggleTestLock(test.id)}
                              className={`px-3 py-1.5 text-xs font-bold rounded-xl border transition-all inline-flex items-center gap-1.5 shadow-sm ${
                                isLocked
                                  ? 'bg-rose-500/20 text-rose-300 border-rose-500/50 hover:bg-rose-500/30'
                                  : 'bg-emerald-500/20 text-emerald-300 border-emerald-500/50 hover:bg-emerald-500/30'
                              }`}
                              title={
                                isLocked
                                  ? 'Click to Unlock: Students will be granted access'
                                  : 'Click to Lock: Students will be prevented from accessing'
                              }
                            >
                              {isLocked ? (
                                <>
                                  <Lock className="w-3.5 h-3.5 text-rose-400" />
                                  <span>🔒 Locked</span>
                                </>
                              ) : (
                                <>
                                  <Unlock className="w-3.5 h-3.5 text-emerald-400" />
                                  <span>🔓 Unlocked</span>
                                </>
                              )}
                            </button>
                          </td>

                          {/* Actions */}
                          <td className="py-3 px-4 text-right space-x-1.5">
                            <button
                              type="button"
                              disabled={savingTestId === test.id}
                              onClick={() => handleSaveTestToCloud(test.id)}
                              className="px-2 py-1 text-xs font-semibold bg-emerald-950 text-emerald-300 hover:bg-emerald-900 border border-emerald-700/50 rounded-lg transition-colors inline-flex items-center gap-1 disabled:opacity-50"
                              title="Persist this test and its answer keys permanently to Supabase Cloud"
                            >
                              <UploadCloud className={`w-3 h-3 text-emerald-400 ${savingTestId === test.id ? 'animate-bounce' : ''}`} />
                              <span>{savingTestId === test.id ? 'Saving...' : 'Save Cloud'}</span>
                            </button>
                            <button
                              onClick={() => {
                                setSelectedTestId(test.id);
                                setActiveTab('creator');
                              }}
                              className="px-2 py-1 text-xs font-semibold bg-indigo-950 text-indigo-300 hover:bg-indigo-900 border border-indigo-700/50 rounded-lg transition-colors"
                            >
                              Questions
                            </button>
                            <button
                              onClick={() => {
                                setSelectedTestId(test.id);
                                setActiveTab('quick-key');
                              }}
                              className="px-2 py-1 text-xs font-semibold bg-amber-950 text-amber-300 hover:bg-amber-900 border border-amber-700/50 rounded-lg transition-colors"
                            >
                              Keys
                            </button>
                            <button
                              onClick={() => handleOpenEditTest(test)}
                              className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors inline-block align-middle"
                              title="Edit Test Settings"
                            >
                              <Edit className="w-3.5 h-3.5" />
                            </button>
                            <button
                              onClick={() => {
                                if (confirm(`Delete test "${test.title}"?`)) {
                                  deleteTest(test.id);
                                }
                              }}
                              className="p-1.5 text-rose-400 hover:text-rose-300 rounded-lg hover:bg-rose-950/40 transition-colors inline-block align-middle"
                              title="Delete Test"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* ================= TAB 3: SERIAL IMAGE PAPER BUILDER ================= */}
        {activeTab === 'serial-images' && (
          <SerialImagePaperBuilder
            selectedTestId={selectedTestId}
            onSelectTestId={(id) => setSelectedTestId(id)}
          />
        )}

        {/* ================= TAB 4: QUESTION PAPER CREATOR (STANDARD / FLEXIBLE) ================= */}
        {activeTab === 'creator' && (
          <div className="space-y-6">
            {/* Quick Switcher to Serial Image Builder */}
            <div className="bg-gradient-to-r from-indigo-950/40 via-slate-900 to-indigo-950/20 border border-indigo-500/30 rounded-2xl p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-indigo-500/20 border border-indigo-500/30 flex items-center justify-center text-indigo-400 shrink-0">
                  <ImageIcon className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="text-xs font-bold text-white">Need to add questions serially by image?</h4>
                  <p className="text-[11px] text-slate-400">
                    Use the Serial Image Paper Builder to upload questions one by one with sections (Physics, Chemistry, Biology, Mathematics).
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setActiveTab('serial-images')}
                className="px-3.5 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs rounded-xl shadow transition-colors flex items-center gap-1.5 shrink-0"
              >
                Open Serial Image Builder ➔
              </button>
            </div>

            {/* Top Selector & Batch Trigger */}
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
              <div className="flex-1 w-full">
                <label className="block text-xs font-semibold text-slate-400 mb-1.5">
                  Select Active Test Paper to Edit Questions:
                </label>
                <select
                  value={selectedTestId}
                  onChange={(e) => setSelectedTestId(e.target.value)}
                  className="w-full md:max-w-md px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-sm font-semibold text-white focus:outline-none focus:border-amber-500"
                >
                  {tests.map((t) => (
                    <option key={t.id} value={t.id}>
                      {t.title} ({t.questions.length} Questions)
                    </option>
                  ))}
                </select>
              </div>

              <div className="flex flex-wrap items-center gap-2">
                <button
                  type="button"
                  disabled={!currentSelectedTest || savingTestId === currentSelectedTest.id}
                  onClick={() => currentSelectedTest && handleSaveTestToCloud(currentSelectedTest.id)}
                  className="px-4 py-2.5 text-xs font-bold bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 rounded-xl shadow-md shadow-amber-500/20 transition-all flex items-center gap-2 disabled:opacity-50"
                  title="Commit test questions and answer keys directly to Supabase Cloud"
                >
                  <UploadCloud className={`w-4 h-4 ${savingTestId === currentSelectedTest?.id ? 'animate-bounce' : ''}`} />
                  <span>{savingTestId === currentSelectedTest?.id ? 'Saving to Cloud...' : 'Save Test & Keys to Cloud'}</span>
                </button>
                <button
                  onClick={() => setIsBatchModalOpen(true)}
                  className="px-4 py-2.5 text-xs font-bold bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white rounded-xl shadow-md shadow-emerald-600/20 transition-all flex items-center gap-2"
                >
                  <UploadCloud className="w-4 h-4" />
                  Batch Upload (CSV / JSON)
                </button>
              </div>
            </div>

            {currentSelectedTest ? (
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
                {/* Single Question Editor Form (5 cols) */}
                <div className="lg:col-span-5 bg-slate-900 border border-slate-800 rounded-2xl p-5">
                  <div className="flex items-center justify-between pb-3 border-b border-slate-800 mb-4">
                    <h3 className="text-base font-bold text-white flex items-center gap-2">
                      <Edit className="w-4 h-4 text-amber-400" />
                      {editingQuestionId ? 'Edit Question' : 'Add Single Question'}
                    </h3>
                    {editingQuestionId && (
                      <button
                        onClick={resetQuestionForm}
                        className="text-xs text-rose-400 hover:text-rose-300"
                      >
                        Cancel Edit
                      </button>
                    )}
                  </div>

                  <form onSubmit={handleSaveQuestion} className="space-y-4 text-xs">
                    <div className="grid grid-cols-2 gap-3">
                      <div>
                        <label className="block font-semibold text-slate-300 mb-1">Section</label>
                        <select
                          value={qSection}
                          onChange={(e) => setQSection(e.target.value as SubjectSection)}
                          className="w-full px-2.5 py-1.5 bg-slate-950 border border-slate-700 rounded-lg text-white"
                        >
                          <option value="Physics">Physics</option>
                          <option value="Chemistry">Chemistry</option>
                          <option value="Mathematics">Mathematics</option>
                          <option value="Biology">Biology</option>
                        </select>
                      </div>

                      <div>
                        <label className="block font-semibold text-slate-300 mb-1">
                          Question Type
                        </label>
                        <select
                          value={qType}
                          onChange={(e) => setQType(e.target.value as QuestionType)}
                          className="w-full px-2.5 py-1.5 bg-slate-950 border border-slate-700 rounded-lg text-white"
                        >
                          <option value="mcq">Single Correct (MCQ)</option>
                          <option value="numerical">Numerical Value</option>
                        </select>
                      </div>
                    </div>

                    <div>
                      <label className="block font-semibold text-slate-300 mb-1">
                        Question Text & Equations
                      </label>
                      <textarea
                        value={qText}
                        onChange={(e) => setQText(e.target.value)}
                        rows={3}
                        className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-lg text-white focus:border-amber-500"
                        placeholder="State question clearly with symbols or parameters..."
                        required
                      />
                    </div>

                    {/* Question Diagram / Image Upload */}
                    <div>
                      <div className="flex items-center justify-between mb-1">
                        <label className="font-semibold text-slate-300 flex items-center gap-1.5">
                          <ImageIcon className="w-3.5 h-3.5 text-indigo-400" />
                          Question Diagram / Image (Optional)
                        </label>
                        {/* Sample diagram shortcuts */}
                        <div className="flex items-center gap-1">
                          <button
                            type="button"
                            onClick={() => setQImageUrl(DIAGRAM_OPTICS)}
                            className="text-[10px] text-amber-400 hover:underline"
                          >
                            +Optics
                          </button>
                          <span className="text-slate-600">|</span>
                          <button
                            type="button"
                            onClick={() => setQImageUrl(DIAGRAM_CIRCUIT)}
                            className="text-[10px] text-amber-400 hover:underline"
                          >
                            +Circuit
                          </button>
                          <span className="text-slate-600">|</span>
                          <button
                            type="button"
                            onClick={() => setQImageUrl(DIAGRAM_GENETICS)}
                            className="text-[10px] text-amber-400 hover:underline"
                          >
                            +Pedigree
                          </button>
                        </div>
                      </div>

                      <div className="space-y-2">
                        <input
                          type="text"
                          value={qImageUrl}
                          onChange={(e) => setQImageUrl(e.target.value)}
                          placeholder="Paste image URL or choose file below..."
                          className="w-full px-2.5 py-1.5 bg-slate-950 border border-slate-700 rounded-lg text-white"
                        />
                        <div className="flex items-center gap-2">
                          <label className="px-3 py-1 bg-slate-800 hover:bg-slate-700 border border-slate-700 rounded-lg cursor-pointer text-[11px] text-slate-300 font-medium">
                            Upload Local Image
                            <input
                              type="file"
                              accept="image/*"
                              onChange={handleImageFileChange}
                              className="hidden"
                            />
                          </label>
                          {qImageUrl && (
                            <button
                              type="button"
                              onClick={() => setQImageUrl('')}
                              className="text-[11px] text-rose-400 hover:underline"
                            >
                              Remove Image
                            </button>
                          )}
                        </div>
                        {qImageUrl && (
                          <div className="p-2 bg-slate-950 border border-slate-800 rounded-lg max-h-36 overflow-hidden flex items-center justify-center">
                            <img
                              src={qImageUrl}
                              alt="Question preview"
                              className="max-h-32 object-contain"
                            />
                          </div>
                        )}
                      </div>
                    </div>

                    {/* Options if MCQ */}
                    {qType === 'mcq' && (
                      <div className="space-y-2 pt-2 border-t border-slate-800">
                        <p className="font-semibold text-slate-300">Answer Options (A, B, C, D)</p>
                        <div className="grid grid-cols-1 gap-2">
                          <div className="flex items-center gap-2">
                            <span className="w-5 text-center font-bold text-amber-400">A</span>
                            <input
                              type="text"
                              value={qOptA}
                              onChange={(e) => setQOptA(e.target.value)}
                              placeholder="Option A text"
                              className="flex-1 px-2.5 py-1.5 bg-slate-950 border border-slate-700 rounded-lg text-white"
                              required
                            />
                          </div>
                          <div className="flex items-center gap-2">
                            <span className="w-5 text-center font-bold text-amber-400">B</span>
                            <input
                              type="text"
                              value={qOptB}
                              onChange={(e) => setQOptB(e.target.value)}
                              placeholder="Option B text"
                              className="flex-1 px-2.5 py-1.5 bg-slate-950 border border-slate-700 rounded-lg text-white"
                              required
                            />
                          </div>
                          <div className="flex items-center gap-2">
                            <span className="w-5 text-center font-bold text-amber-400">C</span>
                            <input
                              type="text"
                              value={qOptC}
                              onChange={(e) => setQOptC(e.target.value)}
                              placeholder="Option C text"
                              className="flex-1 px-2.5 py-1.5 bg-slate-950 border border-slate-700 rounded-lg text-white"
                              required
                            />
                          </div>
                          <div className="flex items-center gap-2">
                            <span className="w-5 text-center font-bold text-amber-400">D</span>
                            <input
                              type="text"
                              value={qOptD}
                              onChange={(e) => setQOptD(e.target.value)}
                              placeholder="Option D text"
                              className="flex-1 px-2.5 py-1.5 bg-slate-950 border border-slate-700 rounded-lg text-white"
                              required
                            />
                          </div>
                        </div>
                      </div>
                    )}

                    {/* Correct Answer & Marks */}
                    <div className="grid grid-cols-3 gap-2 pt-2 border-t border-slate-800">
                      <div>
                        <label className="block font-semibold text-emerald-400 mb-1">
                          Correct Key
                        </label>
                        {qType === 'mcq' ? (
                          <select
                            value={qCorrect}
                            onChange={(e) => setQCorrect(e.target.value)}
                            className="w-full px-2.5 py-1.5 bg-slate-950 border border-emerald-500/50 rounded-lg font-bold text-emerald-300"
                          >
                            <option value="A">Option A</option>
                            <option value="B">Option B</option>
                            <option value="C">Option C</option>
                            <option value="D">Option D</option>
                          </select>
                        ) : (
                          <input
                            type="text"
                            value={qCorrect}
                            onChange={(e) => setQCorrect(e.target.value)}
                            placeholder="e.g. 12"
                            className="w-full px-2.5 py-1.5 bg-slate-950 border border-emerald-500/50 rounded-lg font-bold text-emerald-300"
                            required
                          />
                        )}
                      </div>

                      <div>
                        <label className="block font-semibold text-slate-300 mb-1">
                          + Marks
                        </label>
                        <input
                          type="number"
                          value={qPosMarks}
                          onChange={(e) => setQPosMarks(Number(e.target.value))}
                          className="w-full px-2.5 py-1.5 bg-slate-950 border border-slate-700 rounded-lg text-white"
                        />
                      </div>

                      <div>
                        <label className="block font-semibold text-slate-300 mb-1">
                          - Marks
                        </label>
                        <input
                          type="number"
                          value={qNegMarks}
                          onChange={(e) => setQNegMarks(Number(e.target.value))}
                          className="w-full px-2.5 py-1.5 bg-slate-950 border border-slate-700 rounded-lg text-white"
                        />
                      </div>
                    </div>

                    <div>
                      <label className="block font-semibold text-slate-300 mb-1">
                        Detailed Solution Explanation (Text)
                      </label>
                      <textarea
                        value={qExplanation}
                        onChange={(e) => setQExplanation(e.target.value)}
                        rows={2}
                        className="w-full px-3 py-1.5 bg-slate-950 border border-slate-700 rounded-lg text-white"
                        placeholder="Provide formula, steps, and concept derivation for students..."
                      />
                    </div>

                    {/* Solution Derivation / Handwritten Image Form */}
                    <div>
                      <div className="flex items-center justify-between mb-1">
                        <label className="font-semibold text-slate-300 flex items-center gap-1.5">
                          <ImageIcon className="w-3.5 h-3.5 text-emerald-400" />
                          Solution Step Derivation Image (Optional)
                        </label>
                        {qExplanationImageUrl && (
                          <button
                            type="button"
                            onClick={() => setQExplanationImageUrl('')}
                            className="text-[10px] text-rose-400 hover:underline"
                          >
                            Remove Solution Image
                          </button>
                        )}
                      </div>

                      <div className="space-y-2">
                        <input
                          type="text"
                          value={qExplanationImageUrl}
                          onChange={(e) => setQExplanationImageUrl(e.target.value)}
                          placeholder="Paste solution image URL or choose derivation scan below..."
                          className="w-full px-2.5 py-1.5 bg-slate-950 border border-slate-700 rounded-lg text-white"
                        />
                        <div className="flex items-center gap-2">
                          <label className="px-3 py-1 bg-slate-800 hover:bg-slate-700 border border-slate-700 rounded-lg cursor-pointer text-[11px] text-slate-300 font-medium">
                            Upload Solution Image / Derivation Scan
                            <input
                              type="file"
                              accept="image/*"
                              onChange={handleSolutionImageFileChange}
                              className="hidden"
                            />
                          </label>
                        </div>
                        {qExplanationImageUrl && (
                          <div className="p-2 bg-slate-950 border border-slate-800 rounded-lg max-h-36 overflow-hidden flex items-center justify-center">
                            <img
                              src={qExplanationImageUrl}
                              alt="Solution derivation preview"
                              className="max-h-32 object-contain rounded"
                            />
                          </div>
                        )}
                      </div>
                    </div>

                    <button
                      type="submit"
                      className="w-full py-2.5 px-4 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold rounded-xl shadow-md shadow-amber-500/20 transition-all flex items-center justify-center gap-2"
                    >
                      <Check className="w-4 h-4" />
                      {editingQuestionId ? 'Update Question' : 'Add Question To Test'}
                    </button>
                  </form>
                </div>

                {/* Question List for Selected Test (7 cols) */}
                <div className="lg:col-span-7 bg-slate-900 border border-slate-800 rounded-2xl p-5 flex flex-col justify-between">
                  <div>
                    <div className="flex items-center justify-between pb-3 border-b border-slate-800 mb-4">
                      <div>
                        <h3 className="text-base font-bold text-white">
                          Test Questions ({currentSelectedTest.questions.length})
                        </h3>
                        <p className="text-[11px] text-slate-400">
                          Total Marks: {currentSelectedTest.totalMarks} | Duration:{' '}
                          {currentSelectedTest.durationMinutes} mins
                        </p>
                      </div>
                      <span className="text-xs font-semibold px-2.5 py-1 rounded bg-slate-800 text-amber-400">
                        {currentSelectedTest.examType}
                      </span>
                    </div>

                    <div className="space-y-3 max-h-[640px] overflow-y-auto pr-1">
                      {currentSelectedTest.questions.length === 0 ? (
                        <div className="py-12 text-center text-slate-500 text-xs">
                          <HelpCircle className="w-8 h-8 mx-auto mb-2 opacity-40" />
                          No questions added yet. Use the editor on the left or batch upload CSV/JSON.
                        </div>
                      ) : (
                        currentSelectedTest.questions.map((q, idx) => (
                          <div
                            key={q.id}
                            className="p-3.5 bg-slate-950 rounded-xl border border-slate-800 hover:border-slate-700 transition-all"
                          >
                            <div className="flex items-start justify-between gap-2 mb-2">
                              <div className="flex items-center gap-2">
                                <span className="w-6 h-6 rounded-md bg-amber-500/20 text-amber-400 font-bold text-xs flex items-center justify-center">
                                  {idx + 1}
                                </span>
                                <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-slate-800 text-slate-300">
                                  {q.section}
                                </span>
                                <span className="text-[10px] text-slate-400 font-mono">
                                  +{q.positiveMarks} / -{q.negativeMarks}
                                </span>
                              </div>

                              <div className="flex items-center gap-1.5">
                                <button
                                  onClick={() => handleEditQuestion(q)}
                                  className="p-1 text-slate-400 hover:text-white"
                                  title="Edit"
                                >
                                  <Edit className="w-3.5 h-3.5" />
                                </button>
                                <button
                                  onClick={() => deleteQuestion(currentSelectedTest.id, q.id)}
                                  className="p-1 text-rose-400 hover:text-rose-300"
                                  title="Delete"
                                >
                                  <Trash2 className="w-3.5 h-3.5" />
                                </button>
                              </div>
                            </div>

                            <p className="text-xs font-medium text-slate-200 line-clamp-2 mb-2">
                              {q.text}
                            </p>

                            {q.imageUrl && (
                              <div className="mb-2 max-h-24 overflow-hidden rounded border border-slate-800 bg-slate-900 inline-block">
                                <img
                                  src={q.imageUrl}
                                  alt="diagram"
                                  className="max-h-24 object-contain"
                                />
                              </div>
                            )}

                            <div className="flex items-center justify-between text-[11px] pt-2 border-t border-slate-800/80">
                              <span className="text-slate-400">
                                Correct Answer:{' '}
                                <strong className="text-emerald-400 font-mono text-xs">
                                  {q.correctAnswer}
                                </strong>
                              </span>
                              <span className="text-[10px] text-slate-500 italic truncate max-w-xs">
                                Sol: {q.explanation}
                              </span>
                            </div>
                          </div>
                        ))
                      )}
                    </div>
                  </div>
                </div>
              </div>
            ) : (
              <p className="text-sm text-slate-400">Please create or select a test paper first.</p>
            )}
          </div>
        )}

        {/* ================= TAB 4: QUICK ANSWER KEY MATRIX ================= */}
        {activeTab === 'quick-key' && (
          <div className="space-y-6">
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5">
              <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-6">
                <div>
                  <h2 className="text-xl font-bold text-white flex items-center gap-2">
                    <KeyRound className="w-5 h-5 text-amber-400" />
                    Quick Answer Key Configuration Matrix
                  </h2>
                  <p className="text-xs text-slate-400 mt-1">
                    Directly click to modify the faculty answer key for any question in real time.
                  </p>
                </div>

                <div className="flex flex-wrap items-center gap-3">
                  <button
                    type="button"
                    disabled={!currentSelectedTest || savingTestId === currentSelectedTest.id}
                    onClick={() => currentSelectedTest && handleSaveTestToCloud(currentSelectedTest.id)}
                    className="px-3 py-1.5 text-xs font-bold bg-amber-500 hover:bg-amber-400 text-slate-950 rounded-lg shadow-sm transition-all flex items-center gap-1.5 disabled:opacity-50"
                    title="Persist this answer key permanently to Supabase Cloud"
                  >
                    <UploadCloud className={`w-3.5 h-3.5 ${savingTestId === currentSelectedTest?.id ? 'animate-bounce' : ''}`} />
                    <span>{savingTestId === currentSelectedTest?.id ? 'Saving Keys...' : 'Save Keys to Cloud'}</span>
                  </button>
                  <div className="flex items-center gap-2">
                    <label className="text-xs font-semibold text-slate-400">Test Paper:</label>
                    <select
                      value={selectedTestId}
                      onChange={(e) => setSelectedTestId(e.target.value)}
                      className="px-3 py-1.5 bg-slate-950 border border-slate-700 rounded-lg text-xs font-semibold text-white"
                    >
                      {tests.map((t) => (
                        <option key={t.id} value={t.id}>
                          {t.title}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>
              </div>

              {currentSelectedTest ? (
                <div className="space-y-6">
                  {['Physics', 'Chemistry', 'Mathematics', 'Biology'].map((sectionName) => {
                    const sectionQuestions = currentSelectedTest.questions.filter(
                      (q) => q.section === sectionName
                    );
                    if (sectionQuestions.length === 0) return null;

                    return (
                      <div
                        key={sectionName}
                        className="p-4 bg-slate-950 rounded-xl border border-slate-800"
                      >
                        <div className="flex items-center justify-between mb-3 pb-2 border-b border-slate-800">
                          <span className="font-bold text-sm text-amber-400">{sectionName}</span>
                          <span className="text-xs text-slate-400">
                            {sectionQuestions.length} Questions
                          </span>
                        </div>

                        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3">
                          {sectionQuestions.map((q) => {
                            const qIdx =
                              currentSelectedTest.questions.findIndex((x) => x.id === q.id) + 1;
                            return (
                              <div
                                key={q.id}
                                className="p-3 rounded-lg bg-slate-900 border border-slate-800 hover:border-slate-700 transition-all flex flex-col justify-between"
                              >
                                <div className="flex items-center justify-between mb-2">
                                  <span className="text-xs font-bold text-slate-200">
                                    Q{qIdx}
                                  </span>
                                  <span className="text-[10px] text-slate-500 uppercase">
                                    {q.type}
                                  </span>
                                </div>

                                {q.type === 'mcq' ? (
                                  <div className="flex items-center justify-between gap-1 mt-1">
                                    {(['A', 'B', 'C', 'D'] as OptionKey[]).map((opt) => {
                                      const isSelected = String(q.correctAnswer) === opt;
                                      return (
                                        <button
                                          key={opt}
                                          type="button"
                                          onClick={() =>
                                            updateQuickAnswerKey(currentSelectedTest.id, q.id, opt)
                                          }
                                          className={`w-8 h-8 rounded-lg font-bold text-xs transition-all ${
                                            isSelected
                                              ? 'bg-emerald-500 text-slate-950 shadow-md shadow-emerald-500/30 ring-2 ring-emerald-400'
                                              : 'bg-slate-800 text-slate-400 hover:text-white hover:bg-slate-700'
                                          }`}
                                        >
                                          {opt}
                                        </button>
                                      );
                                    })}
                                  </div>
                                ) : (
                                  <div className="mt-1 flex items-center gap-2">
                                    <input
                                      type="text"
                                      value={String(q.correctAnswer)}
                                      onChange={(e) =>
                                        updateQuickAnswerKey(
                                          currentSelectedTest.id,
                                          q.id,
                                          e.target.value
                                        )
                                      }
                                      className="w-full px-2 py-1 bg-slate-950 border border-emerald-500/50 rounded font-bold text-xs text-emerald-400 text-center"
                                      placeholder="Numeric"
                                    />
                                  </div>
                                )}
                              </div>
                            );
                          })}
                        </div>
                      </div>
                    );
                  })}
                </div>
              ) : (
                <p className="text-xs text-slate-400">No test paper selected.</p>
              )}
            </div>
          </div>
        )}

        {/* ================= TAB 5: NEW REGISTER STUDENT (ADMIN ITSELF) ================= */}
        {activeTab === 'register-student' && (
          <div className="space-y-8">
            <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
              <div>
                <h2 className="text-xl font-bold text-white flex items-center gap-2">
                  <UserPlus className="w-5 h-5 text-emerald-400" />
                  New Register Student (Admin Console)
                </h2>
                <p className="text-xs text-slate-400 mt-1">
                  The Admin registers student <strong className="text-white">NAME</strong> and <strong className="text-amber-400">ROLL NUMBER</strong> here. 
                  The candidate will use the exact same Name and Roll Number to log in to the Student CBT Portal.
                </p>
              </div>

              <div className="flex items-center gap-2 text-xs">
                <span className="px-3 py-1.5 rounded-lg bg-slate-900 border border-slate-800 text-slate-300">
                  Total Registered Students: <strong className="text-amber-400">{students.length}</strong>
                </span>
                <button
                  type="button"
                  onClick={() => setActiveTab('enrolled-students')}
                  className="px-3 py-1.5 rounded-lg bg-indigo-950 border border-indigo-700/50 text-indigo-300 hover:bg-indigo-900 font-bold transition-colors flex items-center gap-1.5"
                >
                  <Users className="w-3.5 h-3.5 text-indigo-400" />
                  View Enrolled Students
                </button>
              </div>
            </div>

            {/* Success notification if student registered */}
            {studentRegSuccessMsg && (
              <div className="p-4 rounded-xl bg-emerald-500/15 border border-emerald-500/30 text-emerald-300 text-xs flex items-center justify-between shadow-lg">
                <div className="flex items-center gap-2.5">
                  <CheckCircle2 className="w-5 h-5 shrink-0 text-emerald-400" />
                  <span className="font-semibold">{studentRegSuccessMsg}</span>
                </div>
                <button
                  onClick={() => {
                    setActiveTab('enrolled-students');
                    window.scrollTo({ top: 100, behavior: 'smooth' });
                  }}
                  className="px-3 py-1 bg-emerald-600 hover:bg-emerald-500 text-slate-950 font-bold rounded-lg text-xs transition-colors shrink-0"
                >
                  Inspect in Enrolled Students →
                </button>
              </div>
            )}

            {/* Last Registered Student Credentials Card (if available) */}
            {lastRegisteredStudent && (
              <div className="bg-gradient-to-r from-amber-500/10 via-slate-900 to-indigo-500/10 border border-amber-500/30 rounded-2xl p-5 shadow-xl">
                <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
                  <div>
                    <span className="text-[10px] font-bold uppercase tracking-wider text-amber-400 bg-amber-500/20 px-2.5 py-0.5 rounded-full border border-amber-500/30">
                      Latest Registered Credentials
                    </span>
                    <h3 className="text-base font-bold text-white mt-2 flex items-center gap-2">
                      <span>{lastRegisteredStudent.name}</span>
                      <span className="text-xs font-mono font-bold text-amber-300 bg-slate-950 px-2 py-0.5 rounded border border-slate-800">
                        Roll: {lastRegisteredStudent.rollNo}
                      </span>
                    </h3>
                    <p className="text-xs text-slate-300 mt-1">
                      Phone Number: <strong className="text-emerald-400 font-mono">{lastRegisteredStudent.phone}</strong> • Track: <strong className="text-indigo-300">{lastRegisteredStudent.exam}</strong>
                    </p>
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => {
                        navigator.clipboard.writeText(
                          `ARGON COACHING LOGIN CREDENTIALS:\nName: ${lastRegisteredStudent.name}\nRoll Number: ${lastRegisteredStudent.rollNo}\nPortal: Student CBT Portal`
                        );
                        alert('Student login credentials copied to clipboard!');
                      }}
                      className="px-3 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-xl text-xs font-bold transition-all border border-slate-700 flex items-center gap-1.5"
                    >
                      <Download className="w-3.5 h-3.5 text-amber-400" />
                      Copy Login Info
                    </button>
                    <button
                      onClick={() => {
                        setSelectedStudentRoll(lastRegisteredStudent.rollNo);
                        setSearchStudentRoll(lastRegisteredStudent.rollNo);
                        setSearchStudentName(lastRegisteredStudent.name);
                        setActiveTab('enrolled-students');
                      }}
                      className="px-3.5 py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 rounded-xl text-xs font-bold transition-all shadow-md shadow-amber-500/20 flex items-center gap-1.5"
                    >
                      <Users className="w-3.5 h-3.5" />
                      View in Enrolled Students
                    </button>
                  </div>
                </div>
              </div>
            )}

            {/* Registration Grid */}
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
              {/* Main Registration Form (7 cols) */}
              <div className="lg:col-span-7 bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl">
                <div className="flex items-center justify-between pb-4 border-b border-slate-800 mb-5">
                  <div>
                    <h3 className="text-base font-bold text-white flex items-center gap-2">
                      <UserPlus className="w-5 h-5 text-emerald-400" />
                      Admin Student Registration Form
                    </h3>
                    <p className="text-xs text-slate-400 mt-0.5">
                      Enter Name & Roll Number that student will use to log in
                    </p>
                  </div>
                  <span className="text-[10px] font-semibold px-2.5 py-1 rounded bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                    Official Admin Entry
                  </span>
                </div>

                <form onSubmit={handleAdminRegisterStudent} className="space-y-4 text-xs">
                  <div>
                    <label className="block font-semibold text-slate-300 mb-1.5">
                      Student Full Name <span className="text-rose-400">*</span>
                    </label>
                    <input
                      type="text"
                      value={newStudentName}
                      onChange={(e) => setNewStudentName(e.target.value)}
                      placeholder="e.g. Rohit Kumar"
                      className="w-full px-3.5 py-2.5 bg-slate-950 border border-slate-700 rounded-xl text-white focus:outline-none focus:border-amber-500 text-sm"
                      required
                    />
                    <p className="text-[11px] text-slate-400 mt-1">
                      Student will type this exact Name (or Roll Number) to access their tests.
                    </p>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <div className="flex items-center justify-between mb-1.5">
                        <label className="font-semibold text-slate-300">
                          Roll Number <span className="text-rose-400">*</span>
                        </label>
                        <button
                          type="button"
                          onClick={() => setNewStudentRoll(generateStudentRoll(newStudentExam))}
                          className="text-[11px] text-amber-400 hover:underline font-semibold"
                        >
                          Auto-Generate
                        </button>
                      </div>
                      <input
                        type="text"
                        value={newStudentRoll}
                        onChange={(e) => setNewStudentRoll(e.target.value)}
                        placeholder="e.g. ARG-JEE-2026-150"
                        className="w-full px-3.5 py-2.5 bg-slate-950 border border-slate-700 rounded-xl text-white font-mono text-xs focus:outline-none focus:border-amber-500"
                        required
                      />
                    </div>

                    <div>
                      <label className="block font-semibold text-slate-300 mb-1.5">
                        Target Exam Curriculum <span className="text-rose-400">*</span>
                      </label>
                      <select
                        value={newStudentExam}
                        onChange={(e) => {
                          const exam = e.target.value as ExamType;
                          setNewStudentExam(exam);
                          setNewStudentRoll(generateStudentRoll(exam));
                        }}
                        className="w-full px-3.5 py-2.5 bg-slate-950 border border-slate-700 rounded-xl text-white text-xs focus:outline-none focus:border-amber-500"
                      >
                        <option value="JEE Advanced">JEE Advanced</option>
                        <option value="JEE Main">JEE Main</option>
                        <option value="NEET">NEET-UG</option>
                      </select>
                    </div>
                  </div>

                  <div>
                    <label className="block font-semibold text-slate-300 mb-1.5">
                      Student Phone Number (for Faculty Contact) <span className="text-rose-400">*</span>
                    </label>
                    <div className="relative">
                      <Phone className="w-4 h-4 text-slate-500 absolute left-3.5 top-3" />
                      <input
                        type="tel"
                        value={newStudentPhone}
                        onChange={(e) => setNewStudentPhone(e.target.value)}
                        placeholder="+91 98765 43210"
                        className="w-full pl-10 pr-3.5 py-2.5 bg-slate-950 border border-slate-700 rounded-xl text-white font-mono text-xs focus:outline-none focus:border-amber-500"
                        required
                      />
                    </div>
                    <p className="text-[11px] text-slate-400 mt-1">
                      This phone number is displayed in the <strong className="text-emerald-400">Enrolled Students</strong> section so the admin can contact the student directly via Direct Call or WhatsApp.
                    </p>
                  </div>

                  <div>
                    <label className="block font-semibold text-slate-300 mb-1.5">
                      Student Email Address (Optional)
                    </label>
                    <input
                      type="email"
                      value={newStudentEmail}
                      onChange={(e) => setNewStudentEmail(e.target.value)}
                      placeholder="student@argon.edu"
                      className="w-full px-3.5 py-2.5 bg-slate-950 border border-slate-700 rounded-xl text-white text-xs focus:outline-none focus:border-amber-500"
                    />
                  </div>

                  <div>
                    <label className="block font-semibold text-slate-300 mb-1.5">
                      Initial Enrolled Test Series:
                    </label>
                    <div className="space-y-2 max-h-36 overflow-y-auto bg-slate-950 p-3 rounded-xl border border-slate-800">
                      {testSeries.map((s) => (
                        <label
                          key={s.id}
                          className="flex items-center gap-2 text-xs text-slate-300 cursor-pointer hover:text-white"
                        >
                          <input
                            type="checkbox"
                            checked={newStudentSeriesIds.includes(s.id)}
                            onChange={(e) => {
                              if (e.target.checked) {
                                setNewStudentSeriesIds([...newStudentSeriesIds, s.id]);
                              } else {
                                setNewStudentSeriesIds(
                                  newStudentSeriesIds.filter((id) => id !== s.id)
                                );
                              }
                            }}
                            className="rounded border-slate-700 text-amber-500 focus:ring-amber-400"
                          />
                          <span className="truncate">{s.title}</span>
                          <span className="text-[10px] text-amber-400 ml-auto font-semibold">
                            {s.price === 0 ? 'FREE' : `₹${s.price}`}
                          </span>
                        </label>
                      ))}
                    </div>
                  </div>

                  <button
                    type="submit"
                    className="w-full py-3 px-4 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-bold rounded-xl shadow-md shadow-emerald-600/25 transition-all flex items-center justify-center gap-2 mt-2"
                  >
                    <UserPlus className="w-4 h-4" />
                    Register Student & Generate Credentials
                  </button>
                </form>
              </div>

              {/* Guide & Rules Column (5 cols) */}
              <div className="lg:col-span-5 space-y-6">
                <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl space-y-4">
                  <h3 className="text-sm font-bold text-white flex items-center gap-2">
                    <Sparkles className="w-4 h-4 text-amber-400" />
                    How Student Registration & Login Works
                  </h3>

                  <div className="space-y-3 text-xs text-slate-300">
                    <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 flex items-start gap-2.5">
                      <span className="w-5 h-5 rounded-full bg-amber-500/20 text-amber-400 font-bold text-[11px] flex items-center justify-center shrink-0 mt-0.5">
                        1
                      </span>
                      <div>
                        <strong className="text-white">Admin Registers Candidate:</strong>
                        <p className="text-slate-400 mt-0.5">
                          Admin enters the candidate's Full Name, Roll Number, and Phone Number in this portal.
                        </p>
                      </div>
                    </div>

                    <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 flex items-start gap-2.5">
                      <span className="w-5 h-5 rounded-full bg-indigo-500/20 text-indigo-400 font-bold text-[11px] flex items-center justify-center shrink-0 mt-0.5">
                        2
                      </span>
                      <div>
                        <strong className="text-white">Student Uses Same Name & Roll:</strong>
                        <p className="text-slate-400 mt-0.5">
                          Student opens the <span className="text-indigo-300 font-semibold">Student CBT Portal</span> and logs in using the exact same Name and Roll Number assigned by the admin.
                        </p>
                      </div>
                    </div>

                    <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 flex items-start gap-2.5">
                      <span className="w-5 h-5 rounded-full bg-emerald-500/20 text-emerald-400 font-bold text-[11px] flex items-center justify-center shrink-0 mt-0.5">
                        3
                      </span>
                      <div>
                        <strong className="text-white">Phone Number Displayed for Faculty:</strong>
                        <p className="text-slate-400 mt-0.5">
                          The candidate's Phone Number is displayed in the <span className="text-emerald-300 font-semibold">Enrolled Students</span> section so the admin can call or message them on WhatsApp anytime.
                        </p>
                      </div>
                    </div>

                    <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 flex items-start gap-2.5">
                      <span className="w-5 h-5 rounded-full bg-rose-500/20 text-rose-400 font-bold text-[11px] flex items-center justify-center shrink-0 mt-0.5">
                        4
                      </span>
                      <div>
                        <strong className="text-white">Every Test Data on Screen:</strong>
                        <p className="text-slate-400 mt-0.5">
                          As soon as the student attempts any CBT exam, every test score, percentile, and question response sheet is immediately visible to the admin.
                        </p>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Quick Roster Snippet */}
                <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl">
                  <div className="flex items-center justify-between mb-3">
                    <h4 className="text-xs font-bold text-white uppercase tracking-wider">
                      Recently Registered Students ({students.length})
                    </h4>
                    <button
                      onClick={() => setActiveTab('enrolled-students')}
                      className="text-[11px] text-amber-400 hover:underline font-semibold"
                    >
                      See All →
                    </button>
                  </div>

                  <div className="space-y-2 max-h-48 overflow-y-auto pr-1">
                    {students.slice(0, 5).map((st) => (
                      <div
                        key={st.id}
                        className="p-2.5 bg-slate-950 rounded-xl border border-slate-800/80 flex items-center justify-between text-xs"
                      >
                        <div>
                          <p className="font-bold text-white">{st.name}</p>
                          <p className="text-[10px] text-amber-400 font-mono">Roll: {st.rollNo}</p>
                        </div>
                        <div className="text-right">
                          <p className="text-[11px] text-emerald-400 font-mono">{st.phone || 'No phone'}</p>
                          <button
                            onClick={() => {
                              setSelectedStudentRoll(st.rollNo || '');
                              setSearchStudentRoll(st.rollNo || '');
                              setSearchStudentName(st.name);
                              setActiveTab('enrolled-students');
                            }}
                            className="text-[10px] text-indigo-400 hover:underline font-semibold"
                          >
                            Inspect Tests →
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* ================= TAB 6: ENROLLED STUDENTS (PUT NAME & ROLL -> EVERY TEST DATA ON SCREEN) ================= */}
        {activeTab === 'enrolled-students' && (
          <div className="space-y-8">
            <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
              <div>
                <h2 className="text-xl font-bold text-white flex items-center gap-2">
                  <Users className="w-5 h-5 text-amber-400" />
                  Enrolled Students & Comprehensive Test Dossier
                </h2>
                <p className="text-xs text-slate-400 mt-1">
                  Put Student <strong className="text-white">NAME</strong> and <strong className="text-amber-400">ROLL NUMBER</strong> to display every test data and contact phone number on the screen.
                </p>
              </div>

              <div className="flex items-center gap-2 text-xs">
                <span className="px-3 py-1.5 rounded-lg bg-slate-900 border border-slate-800 text-slate-300">
                  Total Students: <strong className="text-amber-400">{students.length}</strong>
                </span>
                <span className="px-3 py-1.5 rounded-lg bg-slate-900 border border-slate-800 text-slate-300">
                  Total Submissions: <strong className="text-emerald-400">{attempts.length}</strong>
                </span>
              </div>
            </div>

            {/* Input Box: "Where the admin will put Name and Rollnumber" */}
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl space-y-4">
              <div className="flex items-center justify-between">
                <label className="text-sm font-bold text-white flex items-center gap-2">
                  <Search className="w-4 h-4 text-amber-400" />
                  Put Student Name and Roll Number:
                </label>
                <span className="text-[10px] text-slate-400">
                  Displays instant candidate phone number, performance graph & every test answer sheet
                </span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-12 gap-3">
                <div className="sm:col-span-5">
                  <label className="block text-[11px] font-semibold text-slate-300 mb-1">
                    Student Name
                  </label>
                  <div className="relative">
                    <UserPlus className="w-4 h-4 text-slate-500 absolute left-3 top-3" />
                    <input
                      type="text"
                      value={searchStudentName}
                      onChange={(e) => {
                        const val = e.target.value;
                        setSearchStudentName(val);
                        const match = students.find((s) => s.name.toLowerCase().includes(val.trim().toLowerCase()));
                        if (match) {
                          setSelectedStudentRoll(match.rollNo || '');
                        }
                      }}
                      placeholder="e.g. Aryan Sharma"
                      className="w-full pl-9 pr-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-xs text-white focus:outline-none focus:border-amber-500"
                    />
                  </div>
                </div>

                <div className="sm:col-span-5">
                  <label className="block text-[11px] font-semibold text-slate-300 mb-1">
                    Roll Number
                  </label>
                  <div className="relative">
                    <Hash className="w-4 h-4 text-slate-500 absolute left-3 top-3" />
                    <input
                      type="text"
                      value={searchStudentRoll}
                      onChange={(e) => {
                        const val = e.target.value;
                        setSearchStudentRoll(val);
                        const match = students.find((s) => s.rollNo?.toUpperCase().includes(val.trim().toUpperCase()));
                        if (match) {
                          setSelectedStudentRoll(match.rollNo || '');
                        }
                      }}
                      placeholder="e.g. ARG-JEE-2026-042"
                      className="w-full pl-9 pr-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-xs text-white font-mono focus:outline-none focus:border-amber-500"
                    />
                  </div>
                </div>

                <div className="sm:col-span-2 flex items-end">
                  <button
                    type="button"
                    onClick={() => {
                      const cleanRoll = searchStudentRoll.trim().toUpperCase();
                      const cleanName = searchStudentName.trim().toLowerCase();
                      const found = students.find(
                        (s) =>
                          s.rollNo?.toUpperCase() === cleanRoll ||
                          s.name.toLowerCase() === cleanName ||
                          s.name.toLowerCase().includes(cleanName)
                      );
                      if (found) {
                        setSelectedStudentRoll(found.rollNo || '');
                        setSearchStudentRoll(found.rollNo || '');
                        setSearchStudentName(found.name);
                      } else {
                        alert(`No student found matching Roll: "${searchStudentRoll}" or Name: "${searchStudentName}".`);
                      }
                    }}
                    className="w-full py-2 px-3 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs rounded-xl shadow-md transition-all flex items-center justify-center gap-1.5"
                  >
                    <Search className="w-3.5 h-3.5" />
                    Look Up
                  </button>
                </div>
              </div>

              {/* Quick Select Student Pills */}
              <div className="pt-2 border-t border-slate-800/80">
                <p className="text-[11px] text-slate-400 font-medium mb-2">
                  Quick select enrolled student to load their full test data:
                </p>
                <div className="flex flex-wrap gap-2">
                  {students.map((st) => (
                    <button
                      key={st.id}
                      type="button"
                      onClick={() => {
                        setSelectedStudentRoll(st.rollNo || '');
                        setSearchStudentRoll(st.rollNo || '');
                        setSearchStudentName(st.name);
                      }}
                      className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-all flex items-center gap-2 ${
                        selectedStudentRoll === st.rollNo
                          ? 'bg-amber-500 text-slate-950 font-bold shadow-md shadow-amber-500/20'
                          : 'bg-slate-950 hover:bg-slate-800 text-slate-300 border border-slate-800'
                      }`}
                    >
                      <span>{st.name}</span>
                      <span className="font-mono text-[10px] opacity-80 bg-slate-900/60 px-1 py-0.5 rounded">
                        {st.rollNo}
                      </span>
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {/* Selected Student Full Dossier ("EVERY TEST DATA OF THE STUDENT WILL BE ON THE SCREEN") */}
            {(() => {
              const targetStudent =
                students.find((s) => s.rollNo === selectedStudentRoll) ||
                students.find((s) => s.name.toLowerCase() === searchStudentName.toLowerCase()) ||
                students[0];

              if (!targetStudent) {
                return (
                  <div className="p-8 text-center text-slate-400 text-xs bg-slate-900 rounded-2xl border border-slate-800">
                    No student found. Please enter a valid Name or Roll Number above.
                  </div>
                );
              }

              const studentAttempts = attempts.filter(
                (a) =>
                  a.studentId === targetStudent.id ||
                  a.studentRoll === targetStudent.rollNo ||
                  a.studentName.toLowerCase() === targetStudent.name.toLowerCase()
              );

              const avgAcc =
                studentAttempts.length > 0
                  ? Math.round(
                      studentAttempts.reduce((acc, a) => acc + a.accuracy, 0) /
                        studentAttempts.length
                    )
                  : 0;

              const highestScore =
                studentAttempts.length > 0
                  ? Math.max(...studentAttempts.map((a) => a.score))
                  : 0;

              const cleanPhone = (targetStudent.phone || '').replace(/\D/g, '');

              return (
                <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl space-y-6 animate-fadeIn">
                  {/* Top Bar: Candidate Identity + Phone Number & Faculty Contact Action */}
                  <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-6 pb-6 border-b border-slate-800">
                    <div className="flex items-center gap-4">
                      <div className="w-16 h-16 rounded-2xl bg-gradient-to-tr from-amber-500 to-indigo-600 p-0.5 shadow-md">
                        <div className="w-full h-full bg-slate-900 rounded-[14px] overflow-hidden flex items-center justify-center">
                          {targetStudent.avatar ? (
                            <img
                              src={targetStudent.avatar}
                              alt={targetStudent.name}
                              className="w-full h-full object-cover"
                            />
                          ) : (
                            <span className="font-bold text-amber-400 text-2xl">
                              {targetStudent.name[0]}
                            </span>
                          )}
                        </div>
                      </div>

                      <div>
                        <div className="flex items-center gap-2">
                          <h3 className="text-xl font-black text-white">
                            {targetStudent.name}
                          </h3>
                          <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
                            {targetStudent.targetExam || 'JEE & NEET'}
                          </span>
                        </div>

                        <div className="flex flex-wrap items-center gap-2 text-xs mt-1">
                          <span className="text-slate-400">
                            Roll Number:{' '}
                            <strong className="font-mono text-amber-300 text-sm">
                              {targetStudent.rollNo}
                            </strong>
                          </span>
                          <span className="text-slate-600">•</span>
                          <span className="text-slate-400">
                            Email:{' '}
                            <span className="text-slate-300">{targetStudent.email}</span>
                          </span>
                        </div>
                      </div>
                    </div>

                    {/* PHONE NUMBER SECTION (Visible to Admin to contact the student) */}
                    <div className="bg-slate-950 border border-slate-800 rounded-2xl p-4 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 w-full lg:w-auto shadow-inner">
                      <div>
                        <p className="text-[10px] text-slate-400 uppercase font-semibold flex items-center gap-1.5">
                          <Phone className="w-3.5 h-3.5 text-emerald-400" />
                          Student Contact Phone Number
                        </p>
                        <p className="font-mono font-black text-lg text-emerald-400 mt-0.5">
                          {targetStudent.phone || 'Not Provided'}
                        </p>
                        <p className="text-[10px] text-slate-500">
                          Direct student line for doubt solving & mentoring
                        </p>
                      </div>

                      {targetStudent.phone && (
                        <div className="flex items-center gap-2">
                          <a
                            href={`tel:${targetStudent.phone}`}
                            className="px-3.5 py-2 text-xs font-bold bg-slate-800 hover:bg-slate-700 text-slate-100 rounded-xl border border-slate-700 flex items-center gap-1.5 transition-colors shadow-sm"
                          >
                            <Phone className="w-3.5 h-3.5 text-emerald-400" />
                            Call Student
                          </a>
                          <a
                            href={`https://wa.me/${cleanPhone}`}
                            target="_blank"
                            rel="noreferrer"
                            className="px-3.5 py-2 text-xs font-bold bg-emerald-950/80 hover:bg-emerald-900 text-emerald-300 rounded-xl border border-emerald-700/50 flex items-center gap-1.5 transition-colors shadow-sm"
                          >
                            <MessageCircle className="w-3.5 h-3.5 text-emerald-400" />
                            WhatsApp
                          </a>
                        </div>
                      )}
                    </div>
                  </div>

                  {/* Summary Metric Cards */}
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-center">
                    <div className="bg-slate-950 p-3.5 rounded-xl border border-slate-800">
                      <p className="text-[10px] text-slate-400 uppercase font-semibold">
                        Total Tests Taken
                      </p>
                      <p className="text-2xl font-black text-amber-400 mt-1">
                        {studentAttempts.length}
                      </p>
                    </div>
                    <div className="bg-slate-950 p-3.5 rounded-xl border border-slate-800">
                      <p className="text-[10px] text-slate-400 uppercase font-semibold">
                        Average Accuracy
                      </p>
                      <p className="text-2xl font-black text-emerald-400 mt-1">
                        {avgAcc}%
                      </p>
                    </div>
                    <div className="bg-slate-950 p-3.5 rounded-xl border border-slate-800">
                      <p className="text-[10px] text-slate-400 uppercase font-semibold">
                        Highest Score
                      </p>
                      <p className="text-2xl font-black text-indigo-400 mt-1">
                        {highestScore} Marks
                      </p>
                    </div>
                    <div className="bg-slate-950 p-3.5 rounded-xl border border-slate-800">
                      <p className="text-[10px] text-slate-400 uppercase font-semibold">
                        Target Goal
                      </p>
                      <p className="text-2xl font-black text-rose-400 mt-1">
                        AIR &lt; 500
                      </p>
                    </div>
                  </div>

                  {/* EVERY TEST DATA OF THE STUDENT ON THE SCREEN */}
                  <div>
                    <div className="flex items-center justify-between mb-4">
                      <h4 className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-2">
                        <BarChart2 className="w-4 h-4 text-amber-400" />
                        Every Test Record of {targetStudent.name} ({studentAttempts.length} Submissions)
                      </h4>
                      <span className="text-xs text-slate-400 font-mono">
                        Roll: {targetStudent.rollNo}
                      </span>
                    </div>

                    {studentAttempts.length === 0 ? (
                      <div className="p-8 bg-slate-950 rounded-2xl border border-slate-800 text-center space-y-3">
                        <div className="w-12 h-12 rounded-2xl bg-amber-500/10 text-amber-400 flex items-center justify-center mx-auto">
                          <BookOpen className="w-6 h-6" />
                        </div>
                        <h5 className="font-bold text-white text-sm">No Test Attempts Submitted Yet</h5>
                        <p className="text-xs text-slate-400 max-w-md mx-auto">
                          Candidate <strong className="text-slate-200">{targetStudent.name}</strong> (Roll: <span className="font-mono text-amber-400">{targetStudent.rollNo}</span>) is enrolled. 
                          When the student logs in and completes tests, their full scores, accuracy, and question answers will appear here instantly.
                        </p>
                      </div>
                    ) : (
                      <div className="space-y-4">
                        {studentAttempts.map((att) => (
                          <div
                            key={att.id}
                            className="p-5 bg-slate-950 rounded-2xl border border-slate-800 hover:border-slate-700 transition-all text-xs space-y-4 shadow-md"
                          >
                            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                              <div>
                                <div className="flex items-center gap-2">
                                  <h5 className="font-bold text-white text-base">
                                    {att.testTitle}
                                  </h5>
                                  <span className="text-[10px] px-2 py-0.5 rounded bg-slate-800 text-amber-300 font-semibold border border-slate-700">
                                    Official CBT Record
                                  </span>
                                </div>
                                <p className="text-xs text-slate-400 mt-1">
                                  Submitted on <strong className="text-slate-300">{new Date(att.submittedAt).toLocaleDateString()}</strong> at <strong className="text-slate-300">{new Date(att.submittedAt).toLocaleTimeString()}</strong> • Duration: {Math.round(att.timeSpentSeconds / 60)} mins
                                </p>
                              </div>

                              <div className="flex items-center gap-4">
                                <div className="text-right">
                                  <p className="text-xl font-black text-amber-400">
                                    {att.score} / {att.maxScore}
                                  </p>
                                  <p className="text-[11px] text-emerald-400 font-bold">
                                    {att.accuracy}% Accuracy • {att.percentile}%ile
                                  </p>
                                </div>

                                <button
                                  onClick={() => setInspectAttempt(att)}
                                  className="px-3.5 py-2 bg-indigo-950 text-indigo-300 hover:bg-indigo-900 border border-indigo-700/50 rounded-xl text-xs font-bold transition-colors flex items-center gap-1.5 shadow-sm"
                                >
                                  <Eye className="w-3.5 h-3.5" />
                                  Inspect Answer Sheet
                                </button>
                              </div>
                            </div>

                            {/* Section breakdown */}
                            <div className="pt-3 border-t border-slate-800/80">
                              <p className="text-[10px] text-slate-400 uppercase font-semibold mb-2">
                                Subject-Wise Marks & Question Accuracy:
                              </p>
                              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 text-xs">
                                {Object.entries(att.sectionScores).map(([sec, data]) => {
                                  if (data.maxScore === 0) return null;
                                  return (
                                    <div
                                      key={sec}
                                      className="bg-slate-900 p-2.5 rounded-xl border border-slate-800 flex flex-col justify-between"
                                    >
                                      <div className="flex justify-between items-center mb-1">
                                        <span className="text-slate-400 font-semibold">{sec}</span>
                                        <span className="font-bold text-amber-400">
                                          {data.score} / {data.maxScore}
                                        </span>
                                      </div>
                                      <div className="flex items-center justify-between text-[10px] text-slate-400">
                                        <span className="text-emerald-400 font-semibold">✓ {data.correct}</span>
                                        <span className="text-rose-400 font-semibold">✗ {data.incorrect}</span>
                                        <span className="text-slate-500">○ {data.unattempted}</span>
                                      </div>
                                    </div>
                                  );
                                })}
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                </div>
              );
            })()}

            {/* Complete Registered Students Directory Table */}
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl space-y-4">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-4 border-b border-slate-800">
                <div>
                  <h3 className="text-base font-bold text-white flex items-center gap-2">
                    <Users className="w-4 h-4 text-amber-400" />
                    Complete Registered Students Directory ({students.length})
                  </h3>
                  <p className="text-xs text-slate-400 mt-0.5">
                    Click "View Every Test Data" or telephone link to interact with any candidate
                  </p>
                </div>
              </div>

              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead className="bg-slate-950 text-slate-400 uppercase tracking-wider font-semibold border-b border-slate-800">
                    <tr>
                      <th className="py-3 px-4">Student Name</th>
                      <th className="py-3 px-4">Roll Number</th>
                      <th className="py-3 px-4">Student Phone</th>
                      <th className="py-3 px-4">Target Exam</th>
                      <th className="py-3 px-4">Enrolled Series</th>
                      <th className="py-3 px-4">Tests Taken</th>
                      <th className="py-3 px-4 text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800 text-slate-300">
                    {students.map((st) => {
                      const stAttempts = attempts.filter(
                        (a) =>
                          a.studentId === st.id ||
                          a.studentRoll === st.rollNo ||
                          a.studentName.toLowerCase() === st.name.toLowerCase()
                      );

                      return (
                        <tr
                          key={st.id}
                          className={`hover:bg-slate-800/40 transition-colors ${
                            selectedStudentRoll === st.rollNo ? 'bg-amber-500/10' : ''
                          }`}
                        >
                          <td className="py-3 px-4 font-bold text-white flex items-center gap-2">
                            <span className="w-6 h-6 rounded-full bg-slate-800 text-amber-400 flex items-center justify-center font-bold text-[10px]">
                              {st.name[0]}
                            </span>
                            <span>{st.name}</span>
                          </td>
                          <td className="py-3 px-4 font-mono font-bold text-amber-300">
                            {st.rollNo}
                          </td>
                          <td className="py-3 px-4 font-mono text-emerald-400">
                            <a
                              href={`tel:${st.phone}`}
                              className="hover:underline flex items-center gap-1 font-bold"
                            >
                              <Phone className="w-3 h-3 text-emerald-400 shrink-0" />
                              {st.phone || 'N/A'}
                            </a>
                          </td>
                          <td className="py-3 px-4">
                            <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-slate-800 text-indigo-300 border border-slate-700">
                              {st.targetExam || 'General'}
                            </span>
                          </td>
                          <td className="py-3 px-4 text-slate-300">
                            {st.enrolledSeriesIds?.length || 0} Series
                          </td>
                          <td className="py-3 px-4 font-bold text-white">
                            {stAttempts.length} Tests
                          </td>
                          <td className="py-3 px-4 text-right space-x-2">
                            <button
                              onClick={() => {
                                setSelectedStudentRoll(st.rollNo || '');
                                setSearchStudentRoll(st.rollNo || '');
                                setSearchStudentName(st.name);
                                window.scrollTo({ top: 200, behavior: 'smooth' });
                              }}
                              className="px-2.5 py-1 text-xs font-semibold bg-amber-500/20 text-amber-300 hover:bg-amber-500/30 border border-amber-500/40 rounded-lg transition-colors"
                            >
                              View Every Test Data
                            </button>
                            <button
                              onClick={() => {
                                if (confirm(`Remove student ${st.name} (${st.rollNo})?`)) {
                                  deleteStudentByAdmin(st.id);
                                }
                              }}
                              className="p-1 text-rose-400 hover:text-rose-300"
                              title="Delete Student"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* ================= TAB 8: PAYMENT VERIFICATION REQUESTS ================= */}
        {activeTab === 'verifications' && (
          <FacultyVerificationRequests
            onNavigateToStudent={(roll) => {
              setSelectedStudentRoll(roll);
              setSearchStudentRoll(roll);
              const foundSt = students.find((s) => s.rollNo === roll);
              if (foundSt) setSearchStudentName(foundSt.name);
              setActiveTab('enrolled-students');
              window.scrollTo({ top: 200, behavior: 'smooth' });
            }}
          />
        )}

        {/* ================= TAB 9: STUDENT SUBMISSIONS & ANALYTICS ================= */}
        {activeTab === 'results' && (
          <div className="space-y-6">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-xl font-bold text-white flex items-center gap-2">
                  <BarChart2 className="w-5 h-5 text-indigo-400" />
                  Student Submissions & Auto-Graded Scorecards
                </h2>
                <p className="text-xs text-slate-400 mt-1">
                  Automatic evaluation with instant percentiles, accuracy breakdown, and student response sheets
                </p>
              </div>
            </div>

            {attempts.length === 0 ? (
              <div className="bg-slate-900 border border-slate-800 rounded-2xl p-12 text-center text-slate-400 text-xs">
                No student attempts recorded yet. Students can take tests from the Student CBT portal.
              </div>
            ) : (
              <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden">
                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs">
                    <thead className="bg-slate-950 text-slate-400 uppercase tracking-wider font-semibold border-b border-slate-800">
                      <tr>
                        <th className="py-3 px-4">Student Name</th>
                        <th className="py-3 px-4">Roll Number</th>
                        <th className="py-3 px-4">Test Title</th>
                        <th className="py-3 px-4">Score / Max</th>
                        <th className="py-3 px-4">Accuracy</th>
                        <th className="py-3 px-4">Est. AIR %ile</th>
                        <th className="py-3 px-4">Time Spent</th>
                        <th className="py-3 px-4 text-right">Action</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-800 text-slate-300">
                      {attempts.map((att) => (
                        <tr key={att.id} className="hover:bg-slate-800/40 transition-colors">
                          <td className="py-3 px-4 font-bold text-white">{att.studentName}</td>
                          <td className="py-3 px-4 font-mono text-slate-400">{att.studentRoll}</td>
                          <td className="py-3 px-4 text-slate-200 max-w-xs truncate">
                            {att.testTitle}
                          </td>
                          <td className="py-3 px-4 font-extrabold text-amber-400">
                            {att.score} / {att.maxScore}
                          </td>
                          <td className="py-3 px-4">
                            <span
                              className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                                att.accuracy >= 75
                                  ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                                  : 'bg-amber-500/20 text-amber-400 border border-amber-500/30'
                              }`}
                            >
                              {att.accuracy}%
                            </span>
                          </td>
                          <td className="py-3 px-4 font-semibold text-indigo-300">
                            {att.percentile}%ile
                          </td>
                          <td className="py-3 px-4 text-slate-400">
                            {Math.round(att.timeSpentSeconds / 60)} mins
                          </td>
                          <td className="py-3 px-4 text-right">
                            <button
                              onClick={() => setInspectAttempt(att)}
                              className="px-2.5 py-1 text-xs font-semibold bg-indigo-950 text-indigo-300 hover:bg-indigo-900 border border-indigo-700/50 rounded-lg transition-colors flex items-center gap-1.5 ml-auto"
                            >
                              <Eye className="w-3.5 h-3.5" />
                              Inspect Sheet
                            </button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}
          </div>
        )}

        {/* ================= TAB 6: UPI & PAYMENT SETTINGS ================= */}
        {activeTab === 'upi' && (
          <div className="max-w-2xl bg-slate-900 border border-slate-800 rounded-2xl p-6">
            <div className="flex items-center gap-3 mb-6 pb-4 border-b border-slate-800">
              <div className="w-10 h-10 rounded-xl bg-amber-500/20 text-amber-400 border border-amber-500/30 flex items-center justify-center">
                <QrCode className="w-5 h-5" />
              </div>
              <div>
                <h2 className="text-lg font-bold text-white">Institute UPI Payment Gateway</h2>
                <p className="text-xs text-slate-400">
                  Configure UPI VPA ID and attach custom QR code image for paid test series
                </p>
              </div>
            </div>

            {upiSavedSuccess && (
              <div className="mb-4 p-3 rounded-xl bg-emerald-500/15 border border-emerald-500/30 text-emerald-300 text-xs flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4" />
                <span>UPI payment configurations saved successfully!</span>
              </div>
            )}

            <form onSubmit={handleSaveUpi} className="space-y-4 text-xs">
              <div>
                <label className="block font-semibold text-slate-300 mb-1">
                  Institute UPI Virtual Payment Address (VPA)
                </label>
                <input
                  type="text"
                  value={upiSettingsForm.upiId}
                  onChange={(e) =>
                    setUpiSettingsForm({ ...upiSettingsForm, upiId: e.target.value })
                  }
                  placeholder="e.g. argoncoaching@icici"
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-lg text-white font-mono"
                  required
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-300 mb-1">
                  Merchant / Institute Legal Name
                </label>
                <input
                  type="text"
                  value={upiSettingsForm.merchantName}
                  onChange={(e) =>
                    setUpiSettingsForm({ ...upiSettingsForm, merchantName: e.target.value })
                  }
                  placeholder="ARGON COACHING ACADEMY ASSAM"
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-lg text-white"
                  required
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-300 mb-1">
                  UPI QR Code Image (URL or Data URI)
                </label>
                <input
                  type="text"
                  value={upiSettingsForm.qrUrl}
                  onChange={(e) =>
                    setUpiSettingsForm({ ...upiSettingsForm, qrUrl: e.target.value })
                  }
                  placeholder="Paste QR Code URL or upload file..."
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-lg text-white font-mono"
                />
                <div className="mt-2 flex items-center gap-3">
                  <label className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 border border-slate-700 rounded-lg cursor-pointer text-xs text-slate-300 font-medium">
                    Upload Custom QR Image
                    <input
                      type="file"
                      accept="image/*"
                      onChange={(e) => {
                        const file = e.target.files?.[0];
                        if (file) {
                          const reader = new FileReader();
                          reader.onloadend = () => {
                            setUpiSettingsForm({
                              ...upiSettingsForm,
                              qrUrl: reader.result as string,
                            });
                          };
                          reader.readAsDataURL(file);
                        }
                      }}
                      className="hidden"
                    />
                  </label>
                  <button
                    type="button"
                    onClick={() =>
                      setUpiSettingsForm({
                        ...upiSettingsForm,
                        qrUrl: INSTITUTION_UPI_QR,
                      })
                    }
                    className="text-xs text-amber-400 hover:underline"
                  >
                    Reset to Default Argon QR
                  </button>
                </div>
              </div>

              {/* QR Preview */}
              <div className="p-4 bg-slate-950 rounded-xl border border-slate-800 flex items-center gap-4">
                <div className="w-24 h-24 bg-white p-2 rounded-lg shrink-0 flex items-center justify-center">
                  <img
                    src={upiSettingsForm.qrUrl}
                    alt="UPI QR Preview"
                    className="w-full h-full object-contain"
                  />
                </div>
                <div>
                  <p className="font-bold text-white text-sm">{upiSettingsForm.merchantName}</p>
                  <p className="font-mono text-amber-400 text-xs mt-0.5">{upiSettingsForm.upiId}</p>
                  <p className="text-[11px] text-slate-400 mt-1">
                    This official QR code will be displayed to students when they click "Unlock
                    Series".
                  </p>
                </div>
              </div>

              <div>
                <label className="block font-semibold text-slate-300 mb-1">
                  Payment Instructions Note for Students
                </label>
                <textarea
                  value={upiSettingsForm.note}
                  onChange={(e) =>
                    setUpiSettingsForm({ ...upiSettingsForm, note: e.target.value })
                  }
                  rows={2}
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-lg text-white"
                />
              </div>

              <button
                type="submit"
                className="py-2.5 px-6 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold rounded-xl shadow-md transition-all"
              >
                Save UPI Configuration
              </button>
            </form>
          </div>
        )}

        {/* ================= TAB 11: NOTICES & ANNOUNCEMENTS ================= */}
        {activeTab === 'notices' && (
          <div className="space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <h2 className="text-xl font-bold text-white flex items-center gap-2">
                  <MessageCircle className="w-5 h-5 text-amber-400" />
                  Institute Notices & Announcements
                </h2>
                <p className="text-xs text-slate-400 mt-0.5">
                  Live synchronized with Supabase table <code className="text-amber-300 font-mono">notices</code>. Announcements appear instantly on student devices.
                </p>
              </div>
              <span className="px-3 py-1 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 text-xs font-semibold flex items-center gap-1.5 self-start">
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
                Live Supabase Broadcast
              </span>
            </div>

            {/* Post Notice Form */}
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6">
              <h3 className="font-bold text-sm text-white mb-3 flex items-center gap-2">
                <Plus className="w-4 h-4 text-amber-400" />
                Publish New Notice
              </h3>

              {noticeSuccessMsg && (
                <div className="mb-4 p-3 bg-emerald-500/20 border border-emerald-500/40 rounded-xl text-emerald-300 text-xs font-semibold flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 shrink-0" />
                  <span>{noticeSuccessMsg}</span>
                </div>
              )}

              <form
                onSubmit={async (e) => {
                  e.preventDefault();
                  if (!noticeTitle.trim() || !noticeContent.trim()) return;
                  await createNotice({
                    title: noticeTitle.trim(),
                    content: noticeContent.trim(),
                    targetExam: noticeTargetExam,
                    priority: noticePriority,
                    author: noticeAuthor.trim() || 'Argon Academic Director',
                  });
                  setNoticeSuccessMsg('Notice broadcasted to all students via Supabase!');
                  setNoticeTitle('');
                  setNoticeContent('');
                  setTimeout(() => setNoticeSuccessMsg(''), 4000);
                }}
                className="space-y-4 text-xs"
              >
                <div>
                  <label className="block font-semibold text-slate-300 mb-1">Notice Title</label>
                  <input
                    type="text"
                    value={noticeTitle}
                    onChange={(e) => setNoticeTitle(e.target.value)}
                    placeholder="e.g. JEE Main Shift-1 Mock Exam Center Guidelines"
                    className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-white text-sm"
                    required
                  />
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <div>
                    <label className="block font-semibold text-slate-300 mb-1">Target Audience</label>
                    <select
                      value={noticeTargetExam}
                      onChange={(e) => setNoticeTargetExam(e.target.value as any)}
                      className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-white"
                    >
                      <option value="All">All Students (JEE + NEET)</option>
                      <option value="JEE Main">JEE Main Batches</option>
                      <option value="JEE Advanced">JEE Advanced Apex</option>
                      <option value="NEET">NEET-UG Batches</option>
                    </select>
                  </div>

                  <div>
                    <label className="block font-semibold text-slate-300 mb-1">Priority</label>
                    <select
                      value={noticePriority}
                      onChange={(e) => setNoticePriority(e.target.value as any)}
                      className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-white"
                    >
                      <option value="normal">Normal Announcement</option>
                      <option value="urgent">🚨 Urgent Exam Alert</option>
                    </select>
                  </div>

                  <div>
                    <label className="block font-semibold text-slate-300 mb-1">Issued By</label>
                    <input
                      type="text"
                      value={noticeAuthor}
                      onChange={(e) => setNoticeAuthor(e.target.value)}
                      placeholder="Dr. H. P. Deshmukh"
                      className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-white"
                    />
                  </div>
                </div>

                <div>
                  <label className="block font-semibold text-slate-300 mb-1">Notice Content</label>
                  <textarea
                    value={noticeContent}
                    onChange={(e) => setNoticeContent(e.target.value)}
                    rows={3}
                    placeholder="Provide full instructions, reporting timings, syllabus coverage..."
                    className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-white"
                    required
                  />
                </div>

                <button
                  type="submit"
                  className="px-5 py-2.5 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold rounded-xl shadow-md transition-all flex items-center gap-2"
                >
                  <Zap className="w-4 h-4" />
                  Broadcast Live Notice to Students
                </button>
              </form>
            </div>

            {/* Existing Notices List */}
            <div className="space-y-3">
              <h3 className="font-bold text-sm text-white">Active Institute Notices ({notices.length})</h3>
              {notices.length === 0 ? (
                <div className="p-8 bg-slate-900 border border-slate-800 rounded-2xl text-center text-slate-400 text-xs">
                  No active notices published yet. Use the form above to post announcements.
                </div>
              ) : (
                notices.map((n) => (
                  <div
                    key={n.id}
                    className="p-4 bg-slate-900 border border-slate-800 rounded-2xl hover:border-slate-700 transition-all flex flex-col sm:flex-row sm:items-start justify-between gap-3"
                  >
                    <div className="space-y-1.5 flex-1">
                      <div className="flex flex-wrap items-center gap-2">
                        {n.priority === 'urgent' && (
                          <span className="px-2 py-0.5 rounded bg-rose-500/20 text-rose-300 border border-rose-500/30 text-[10px] font-black uppercase tracking-wider">
                            Urgent
                          </span>
                        )}
                        <span className="px-2 py-0.5 rounded bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 text-[10px] font-bold">
                          {n.targetExam || 'All'}
                        </span>
                        <h4 className="font-bold text-sm text-white">{n.title}</h4>
                      </div>
                      <p className="text-xs text-slate-300 leading-relaxed">{n.content}</p>
                      <div className="flex items-center gap-3 text-[11px] text-slate-500 font-medium">
                        <span>Issued by: {n.author || 'Faculty'}</span>
                        <span>•</span>
                        <span>{new Date(n.createdAt).toLocaleDateString()} at {new Date(n.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                      </div>
                    </div>

                    <button
                      onClick={() => {
                        if (confirm(`Delete notice "${n.title}"?`)) {
                          deleteNotice(n.id);
                        }
                      }}
                      className="p-2 text-slate-400 hover:text-rose-400 hover:bg-rose-500/10 rounded-lg transition-colors self-end sm:self-center"
                      title="Delete Notice"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                ))
              )}
            </div>
          </div>
        )}

        {/* ================= TAB 12: STUDY MATERIALS & HANDBOOKS ================= */}
        {activeTab === 'materials' && (
          <div className="space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <h2 className="text-xl font-bold text-white flex items-center gap-2">
                  <FileText className="w-5 h-5 text-indigo-400" />
                  Study Materials & Handbooks
                </h2>
                <p className="text-xs text-slate-400 mt-0.5">
                  Live synchronized with Supabase table <code className="text-indigo-300 font-mono">materials</code>. Uploads appear instantly on student app and Free Resources library.
                </p>
              </div>
              <span className="px-3 py-1 rounded-full bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 text-xs font-semibold flex items-center gap-1.5 self-start">
                <span className="w-2 h-2 rounded-full bg-indigo-400 animate-pulse"></span>
                Live Supabase Sync
              </span>
            </div>

            {/* Upload Material Form */}
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6">
              <h3 className="font-bold text-sm text-white mb-3 flex items-center gap-2">
                <UploadCloud className="w-4 h-4 text-indigo-400" />
                Upload New Study Material
              </h3>

              {matSuccessMsg && (
                <div className="mb-4 p-3 bg-emerald-500/20 border border-emerald-500/40 rounded-xl text-emerald-300 text-xs font-semibold flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 shrink-0" />
                  <span>{matSuccessMsg}</span>
                </div>
              )}

              <form
                onSubmit={async (e) => {
                  e.preventDefault();
                  if (!matTitle.trim() || !matDescription.trim()) return;
                  await createMaterial({
                    title: matTitle.trim(),
                    category: matCategory,
                    type: matType,
                    description: matDescription.trim(),
                    size: matSize,
                    isHot: matIsHot,
                  });
                  setMatSuccessMsg('Study material published to students via Supabase!');
                  setMatTitle('');
                  setMatDescription('');
                  setTimeout(() => setMatSuccessMsg(''), 4000);
                }}
                className="space-y-4 text-xs"
              >
                <div>
                  <label className="block font-semibold text-slate-300 mb-1">Resource Title</label>
                  <input
                    type="text"
                    value={matTitle}
                    onChange={(e) => setMatTitle(e.target.value)}
                    placeholder="e.g. Complete Organic Chemistry Named Reactions & Mechanisms"
                    className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-white text-sm"
                    required
                  />
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-4 gap-3">
                  <div>
                    <label className="block font-semibold text-slate-300 mb-1">Subject / Stream</label>
                    <select
                      value={matCategory}
                      onChange={(e) => setMatCategory(e.target.value as any)}
                      className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-white"
                    >
                      <option value="JEE">JEE Physics / Maths</option>
                      <option value="NEET">NEET Biology</option>
                      <option value="FORMULAS">Formulas & Chemistry</option>
                      <option value="ALL">All Aspirants</option>
                    </select>
                  </div>

                  <div>
                    <label className="block font-semibold text-slate-300 mb-1">Resource Type</label>
                    <select
                      value={matType}
                      onChange={(e) => setMatType(e.target.value)}
                      className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-white"
                    >
                      <option value="PDF Formula Sheet">PDF Formula Sheet</option>
                      <option value="NCERT Mindmap">NCERT Mindmap</option>
                      <option value="Reaction Roadmap">Reaction Roadmap</option>
                      <option value="Solved Papers">Solved PYQ Papers</option>
                      <option value="Calculus Cheat Sheet">Cheat Sheet</option>
                    </select>
                  </div>

                  <div>
                    <label className="block font-semibold text-slate-300 mb-1">Est. File Size</label>
                    <input
                      type="text"
                      value={matSize}
                      onChange={(e) => setMatSize(e.target.value)}
                      placeholder="e.g. 4.8 MB"
                      className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-white"
                    />
                  </div>

                  <div className="flex items-center gap-2 pt-6">
                    <input
                      type="checkbox"
                      id="matHotCheckbox"
                      checked={matIsHot}
                      onChange={(e) => setMatIsHot(e.target.checked)}
                      className="rounded bg-slate-950 border-slate-700 text-indigo-600 focus:ring-0 w-4 h-4"
                    />
                    <label htmlFor="matHotCheckbox" className="font-semibold text-slate-300 cursor-pointer">
                      Mark as 🔥 High-Yield
                    </label>
                  </div>
                </div>

                <div>
                  <label className="block font-semibold text-slate-300 mb-1">Description & Key Highlights</label>
                  <textarea
                    value={matDescription}
                    onChange={(e) => setMatDescription(e.target.value)}
                    rows={2}
                    placeholder="Summary of topics covered, derivations, shortcut formulas..."
                    className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-white"
                    required
                  />
                </div>

                <button
                  type="submit"
                  className="px-5 py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white font-bold rounded-xl shadow-md transition-all flex items-center gap-2"
                >
                  <UploadCloud className="w-4 h-4" />
                  Publish Material to Student Library
                </button>
              </form>
            </div>

            {/* Existing Materials List */}
            <div className="space-y-3">
              <h3 className="font-bold text-sm text-white">Active Study Materials ({materials.length})</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {materials.map((m) => (
                  <div
                    key={m.id}
                    className="p-4 bg-slate-900 border border-slate-800 rounded-2xl hover:border-slate-700 transition-all flex flex-col justify-between"
                  >
                    <div>
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 uppercase">
                          {m.category} • {m.type}
                        </span>
                        {m.isHot && (
                          <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-amber-500/20 text-amber-300 border border-amber-500/30">
                            🔥 High-Yield
                          </span>
                        )}
                      </div>
                      <h4 className="font-bold text-sm text-white mb-1">{m.title}</h4>
                      <p className="text-xs text-slate-400 line-clamp-2 mb-3">{m.description}</p>
                    </div>

                    <div className="flex items-center justify-between pt-3 border-t border-slate-800 text-[11px] text-slate-400">
                      <span>Size: {m.size || '3.5 MB'}</span>
                      <button
                        onClick={() => {
                          if (confirm(`Delete material "${m.title}"?`)) {
                            deleteMaterial(m.id);
                          }
                        }}
                        className="p-1.5 text-slate-400 hover:text-rose-400 hover:bg-rose-500/10 rounded-lg transition-colors"
                        title="Delete Material"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* ================= TAB 13: FACULTY BIOS & MENTORS ================= */}
        {activeTab === 'faculty-bios' && (
          <div className="space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <h2 className="text-xl font-bold text-white flex items-center gap-2">
                  <Users className="w-5 h-5 text-emerald-400" />
                  Faculty Mentors & Academic Profiles
                </h2>
                <p className="text-xs text-slate-400 mt-0.5">
                  Live synchronized with Supabase table <code className="text-emerald-300 font-mono">faculty_profiles</code>. Any addition or update immediately appears on student apps and the website.
                </p>
              </div>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={handleOpenAddFaculty}
                  className="px-4 py-2.5 text-xs font-bold bg-amber-500 hover:bg-amber-400 text-slate-950 rounded-xl shadow-md shadow-amber-500/20 transition-all flex items-center gap-1.5"
                >
                  <Plus className="w-4 h-4" />
                  Add Faculty Mentor
                </button>
              </div>
            </div>

            {facultySuccessMsg && (
              <div className="p-3 bg-emerald-500/20 border border-emerald-500/40 rounded-xl text-emerald-300 text-xs font-semibold flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 shrink-0" />
                <span>{facultySuccessMsg}</span>
              </div>
            )}

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {facultyProfiles.map((faculty) => (
                <div
                  key={faculty.id}
                  className="bg-slate-900 border border-slate-800 rounded-3xl p-6 hover:border-slate-700 transition-all shadow-xl flex flex-col justify-between"
                >
                  <div>
                    <div className="flex items-start justify-between gap-4 mb-4">
                      <div className="flex items-start gap-4">
                        <img
                          src={faculty.avatar}
                          alt={faculty.name}
                          className="w-16 h-16 rounded-2xl object-cover border-2 border-slate-700 shadow-md shrink-0 bg-slate-800"
                        />
                        <div>
                          <h3 className="text-lg font-bold text-white">{faculty.name}</h3>
                          <p className="text-xs font-bold text-amber-400">{faculty.role}</p>
                          <p className="text-[11px] text-slate-400 font-medium">{faculty.qualification}</p>
                          {faculty.department && (
                            <span className="inline-block mt-1 px-2 py-0.5 rounded text-[10px] font-bold bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
                              {faculty.department} Department
                            </span>
                          )}
                        </div>
                      </div>

                      <div className="flex items-center gap-1.5">
                        <button
                          type="button"
                          onClick={() => handleOpenEditFaculty(faculty)}
                          className="p-1.5 text-xs font-semibold text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-700 rounded-lg transition-colors flex items-center gap-1"
                          title="Edit Bio & Credentials"
                        >
                          <Edit className="w-3.5 h-3.5" />
                          <span className="hidden sm:inline">Edit Bio</span>
                        </button>
                        <button
                          type="button"
                          onClick={() => {
                            if (confirm(`Remove faculty mentor "${faculty.name}"?`)) {
                              deleteFacultyProfile(faculty.id);
                            }
                          }}
                          className="p-1.5 text-xs font-semibold text-rose-400 hover:text-rose-300 bg-rose-950/30 hover:bg-rose-950/50 rounded-lg transition-colors"
                          title="Delete Faculty Profile"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>

                    <p className="text-xs text-slate-300 leading-relaxed mb-4">{faculty.bio}</p>

                    {faculty.quote && (
                      <div className="p-3 rounded-xl bg-slate-950/80 border-l-4 border-amber-500 mb-4 text-xs italic text-slate-300">
                        {faculty.quote}
                      </div>
                    )}

                    <div className="space-y-2 mb-4">
                      {faculty.subjects && faculty.subjects.length > 0 && (
                        <div>
                          <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-1">
                            Key Focus Subjects:
                          </span>
                          <div className="flex flex-wrap gap-1">
                            {faculty.subjects.map((sub, i) => (
                              <span
                                key={i}
                                className="px-2 py-0.5 rounded bg-slate-800 text-[10px] text-indigo-300 border border-slate-700/60"
                              >
                                {sub}
                              </span>
                            ))}
                          </div>
                        </div>
                      )}

                      {faculty.trackRecord && (
                        <div className="p-2.5 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-xs text-emerald-300 flex items-center gap-2">
                          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                          <span>Track Record: <strong>{faculty.trackRecord}</strong></span>
                        </div>
                      )}

                      {faculty.availableTimings && (
                        <div className="p-2.5 rounded-xl bg-amber-500/10 border border-amber-500/20 text-xs text-amber-300 flex items-center gap-2 font-mono">
                          <Clock className="w-4 h-4 text-amber-400 shrink-0" />
                          <span>Doubt Hours: <strong>{faculty.availableTimings}</strong></span>
                        </div>
                      )}
                    </div>
                  </div>

                  <div className="pt-3 border-t border-slate-800 flex items-center justify-between text-xs text-slate-400">
                    <span className="text-[11px] font-mono text-emerald-400">● Live Supabase Profile</span>
                    {faculty.phone && (
                      <span className="flex items-center gap-1 font-mono text-slate-300">
                        <Phone className="w-3.5 h-3.5 text-amber-400" />
                        {faculty.phone}
                      </span>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* ================= MODAL: CREATE / EDIT TEST SERIES ================= */}
      {isSeriesModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm">
          <div className="w-full max-w-lg bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl p-6 text-white">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800 mb-4">
              <h3 className="font-bold text-lg">
                {editingSeries ? 'Edit Test Series' : 'Create New Test Series'}
              </h3>
              <button
                onClick={() => setIsSeriesModalOpen(false)}
                className="text-slate-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveSeries} className="space-y-4 text-xs">
              <div>
                <label className="block font-semibold text-slate-300 mb-1">
                  Test Series Title
                </label>
                <input
                  type="text"
                  value={seriesForm.title}
                  onChange={(e) => setSeriesForm({ ...seriesForm, title: e.target.value })}
                  placeholder="e.g. NEET Physics Weekly Mega Mock"
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-lg text-white text-sm"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-300 mb-1">Category</label>
                  <input
                    type="text"
                    value={seriesForm.category}
                    onChange={(e) => setSeriesForm({ ...seriesForm, category: e.target.value })}
                    placeholder="e.g. NEET Physics Weekly"
                    className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-lg text-white"
                    required
                  />
                </div>

                <div>
                  <label className="block font-semibold text-slate-300 mb-1">Target Exam</label>
                  <select
                    value={seriesForm.targetExam}
                    onChange={(e) =>
                      setSeriesForm({ ...seriesForm, targetExam: e.target.value as ExamType })
                    }
                    className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-lg text-white"
                  >
                    <option value="JEE Main">JEE Main</option>
                    <option value="JEE Advanced">JEE Advanced</option>
                    <option value="NEET">NEET-UG</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="block font-semibold text-slate-300 mb-1">Price (₹)</label>
                  <input
                    type="number"
                    value={seriesForm.price}
                    onChange={(e) =>
                      setSeriesForm({ ...seriesForm, price: Number(e.target.value) })
                    }
                    placeholder="0 for Free"
                    className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-lg text-white"
                    required
                  />
                </div>

                <div>
                  <label className="block font-semibold text-slate-300 mb-1">
                    Original Price (₹)
                  </label>
                  <input
                    type="number"
                    value={seriesForm.originalPrice}
                    onChange={(e) =>
                      setSeriesForm({ ...seriesForm, originalPrice: Number(e.target.value) })
                    }
                    className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-lg text-white"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-slate-300 mb-1">Badge</label>
                  <input
                    type="text"
                    value={seriesForm.badge}
                    onChange={(e) => setSeriesForm({ ...seriesForm, badge: e.target.value })}
                    placeholder="e.g. Assam Topper"
                    className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-lg text-white"
                  />
                </div>
              </div>

              <div>
                <label className="block font-semibold text-slate-300 mb-1">Description</label>
                <textarea
                  value={seriesForm.description}
                  onChange={(e) => setSeriesForm({ ...seriesForm, description: e.target.value })}
                  rows={3}
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-lg text-white"
                  placeholder="Describe curriculum coverage, target students, and rigor..."
                  required
                />
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setIsSeriesModalOpen(false)}
                  className="px-4 py-2 bg-slate-800 text-slate-300 rounded-lg hover:bg-slate-700"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold rounded-lg"
                >
                  Save Series
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ================= MODAL: CREATE / EDIT TEST PAPER ================= */}
      {isTestModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm">
          <div className="w-full max-w-2xl bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl p-6 text-white max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800 mb-4 sticky top-0 bg-slate-900 z-10">
              <div>
                <h3 className="font-bold text-lg text-white">
                  {editingTest ? 'Edit Test Paper Settings' : 'Create New Test Paper'}
                </h3>
                <p className="text-xs text-slate-400">
                  Configure test timings, subject order sequence, automated schedule, and faculty access lock
                </p>
              </div>
              <button
                onClick={() => setIsTestModalOpen(false)}
                className="text-slate-400 hover:text-white p-1 rounded-lg hover:bg-slate-800"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveTest} className="space-y-4 text-xs">
              <div>
                <label className="block font-semibold text-slate-300 mb-1">Test Title</label>
                <input
                  type="text"
                  value={testForm.title}
                  onChange={(e) => setTestForm({ ...testForm, title: e.target.value })}
                  placeholder="e.g. JEE Advanced Full Mock Test 02 (Paper-1)"
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-lg text-white text-sm"
                  required
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-300 mb-1">
                    Assign To Test Series
                  </label>
                  <select
                    value={testForm.seriesId}
                    onChange={(e) => setTestForm({ ...testForm, seriesId: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-lg text-white"
                    required
                  >
                    {testSeries.map((s) => (
                      <option key={s.id} value={s.id}>
                        {s.title}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block font-semibold text-slate-300 mb-1">Exam Type</label>
                  <select
                    value={testForm.examType}
                    onChange={(e) => {
                      const newType = e.target.value as ExamType;
                      const defaultSecs: SubjectSection[] =
                        newType === 'NEET'
                          ? ['Biology', 'Physics', 'Chemistry']
                          : ['Physics', 'Chemistry', 'Mathematics'];
                      setTestForm({
                        ...testForm,
                        examType: newType,
                        sections: defaultSecs,
                        subjectOrder: defaultSecs,
                      });
                    }}
                    className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-lg text-white"
                  >
                    <option value="JEE Main">JEE Main</option>
                    <option value="JEE Advanced">JEE Advanced</option>
                    <option value="NEET">NEET-UG</option>
                  </select>
                </div>
              </div>

              {/* DURATION & CBT TIMER */}
              <div className="bg-slate-950/80 border border-slate-800 rounded-xl p-3.5 space-y-2">
                <div className="flex items-center justify-between">
                  <label className="block font-bold text-white text-xs flex items-center gap-1.5">
                    <Clock className="w-4 h-4 text-amber-400" />
                    CBT Test Duration & Countdown Timer (Minutes)
                  </label>
                  <span className="text-[11px] text-amber-300 font-mono font-bold bg-amber-500/10 border border-amber-500/30 px-2 py-0.5 rounded">
                    = {Math.floor(testForm.durationMinutes / 60)}h {testForm.durationMinutes % 60}m Timer
                  </span>
                </div>
                <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2">
                  <input
                    type="number"
                    min="1"
                    max="600"
                    value={testForm.durationMinutes}
                    onChange={(e) =>
                      setTestForm({ ...testForm, durationMinutes: Math.max(1, Number(e.target.value)) })
                    }
                    className="w-full sm:w-36 px-3 py-2 bg-slate-900 border border-slate-700 rounded-lg text-white font-mono font-bold text-sm"
                    required
                  />
                  <div className="flex items-center gap-1.5 flex-wrap">
                    {[
                      { label: '3 Hours (180m - Standard NTA)', val: 180 },
                      { label: '1 Hour (60m)', val: 60 },
                      { label: '45 Mins', val: 45 },
                      { label: '30 Mins', val: 30 },
                    ].map((btn) => (
                      <button
                        key={btn.val}
                        type="button"
                        onClick={() => setTestForm({ ...testForm, durationMinutes: btn.val })}
                        className={`px-2.5 py-1.5 rounded-lg text-[10px] font-bold transition-colors ${
                          testForm.durationMinutes === btn.val
                            ? 'bg-amber-500 text-slate-950 shadow-sm'
                            : 'bg-slate-800 hover:bg-slate-750 text-slate-300 border border-slate-700'
                        }`}
                      >
                        {btn.label}
                      </button>
                    ))}
                  </div>
                </div>
                <p className="text-[11px] text-slate-400 leading-relaxed">
                  ⚡ <strong>Student CBT Timer:</strong> The countdown timer on the candidate's NTA examination interface will begin at this exact duration and auto-submit when it reaches 00:00:00.
                </p>
              </div>

              {/* SUBJECT ORDER SELECTION */}
              <div className="bg-slate-950/80 border border-slate-800 rounded-xl p-3.5 space-y-2.5">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1">
                  <div>
                    <label className="block font-bold text-white text-xs">
                      Choose Subject Order (Which Subject Appears First in Test)
                    </label>
                    <p className="text-[11px] text-slate-400">
                      The subject at Position #1 will appear FIRST when the student opens the CBT examination screen.
                    </p>
                  </div>
                  <span className="self-start sm:self-auto text-[10px] font-bold px-2 py-0.5 rounded bg-amber-500/20 text-amber-300 border border-amber-500/40">
                    ★ 1st: {testForm.subjectOrder[0]}
                  </span>
                </div>

                {/* Ordered List */}
                <div className="space-y-1.5">
                  {testForm.subjectOrder.map((subj, idx) => (
                    <div
                      key={subj}
                      className={`flex items-center justify-between px-3 py-2 rounded-lg border text-xs transition-colors ${
                        idx === 0
                          ? 'bg-amber-500/10 border-amber-500/40 text-amber-200'
                          : 'bg-slate-900 border-slate-800 text-slate-300'
                      }`}
                    >
                      <div className="flex items-center gap-2">
                        <span
                          className={`w-5 h-5 rounded-full flex items-center justify-center font-mono font-bold text-[10px] ${
                            idx === 0 ? 'bg-amber-500 text-slate-950 font-black' : 'bg-slate-800 text-slate-400'
                          }`}
                        >
                          {idx + 1}
                        </span>
                        <span className="font-bold text-white">{subj}</span>
                        {idx === 0 && (
                          <span className="text-[10px] font-bold text-amber-400 bg-amber-500/20 px-1.5 py-0.5 rounded border border-amber-500/30">
                            ★ Appears First in CBT Test
                          </span>
                        )}
                      </div>

                      <div className="flex items-center gap-1">
                        {idx !== 0 && (
                          <button
                            type="button"
                            onClick={() => {
                              const newOrder = [subj, ...testForm.subjectOrder.filter((s) => s !== subj)];
                              setTestForm({ ...testForm, subjectOrder: newOrder });
                            }}
                            className="px-2 py-0.5 rounded text-[10px] font-bold bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 border border-amber-500/30 transition-colors"
                          >
                            Set as 1st
                          </button>
                        )}
                        <button
                          type="button"
                          disabled={idx === 0}
                          onClick={() => {
                            if (idx === 0) return;
                            const newArr = [...testForm.subjectOrder];
                            const temp = newArr[idx - 1];
                            newArr[idx - 1] = newArr[idx];
                            newArr[idx] = temp;
                            setTestForm({ ...testForm, subjectOrder: newArr });
                          }}
                          className={`p-1 rounded text-slate-400 hover:text-white ${
                            idx === 0 ? 'opacity-30 cursor-not-allowed' : 'hover:bg-slate-800'
                          }`}
                          title="Move Up"
                        >
                          <ArrowUp className="w-3.5 h-3.5" />
                        </button>
                        <button
                          type="button"
                          disabled={idx === testForm.subjectOrder.length - 1}
                          onClick={() => {
                            if (idx === testForm.subjectOrder.length - 1) return;
                            const newArr = [...testForm.subjectOrder];
                            const temp = newArr[idx + 1];
                            newArr[idx + 1] = newArr[idx];
                            newArr[idx] = temp;
                            setTestForm({ ...testForm, subjectOrder: newArr });
                          }}
                          className={`p-1 rounded text-slate-400 hover:text-white ${
                            idx === testForm.subjectOrder.length - 1 ? 'opacity-30 cursor-not-allowed' : 'hover:bg-slate-800'
                          }`}
                          title="Move Down"
                        >
                          <ArrowDown className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* AUTOMATED TEST SCHEDULING (START & END TIMES) */}
              <div className="bg-slate-950/80 border border-slate-800 rounded-xl p-3.5 space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Calendar className="w-4 h-4 text-indigo-400" />
                    <div>
                      <label className="font-bold text-white text-xs cursor-pointer select-none" htmlFor="sched-toggle">
                        Automated Exam Scheduling (Start / End Times)
                      </label>
                      <p className="text-[11px] text-slate-400">
                        Set automated start and end times so the exam triggers automatically for students.
                      </p>
                    </div>
                  </div>
                  <input
                    id="sched-toggle"
                    type="checkbox"
                    checked={testForm.isScheduled}
                    onChange={(e) => setTestForm({ ...testForm, isScheduled: e.target.checked })}
                    className="w-4 h-4 rounded text-indigo-600 bg-slate-900 border-slate-700 focus:ring-indigo-500 cursor-pointer"
                  />
                </div>

                {testForm.isScheduled && (
                  <div className="space-y-3 pt-2 border-t border-slate-800/80">
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      <div>
                        <label className="block text-[11px] font-semibold text-slate-300 mb-1">
                          Automated Start Time:
                        </label>
                        <input
                          type="datetime-local"
                          value={testForm.scheduledStartTime}
                          onChange={(e) => setTestForm({ ...testForm, scheduledStartTime: e.target.value })}
                          className="w-full px-2.5 py-1.5 bg-slate-900 border border-slate-700 rounded-lg text-white text-xs font-mono"
                          required={testForm.isScheduled}
                        />
                      </div>
                      <div>
                        <label className="block text-[11px] font-semibold text-slate-300 mb-1">
                          Automated End Time:
                        </label>
                        <input
                          type="datetime-local"
                          value={testForm.scheduledEndTime}
                          onChange={(e) => setTestForm({ ...testForm, scheduledEndTime: e.target.value })}
                          className="w-full px-2.5 py-1.5 bg-slate-900 border border-slate-700 rounded-lg text-white text-xs font-mono"
                        />
                      </div>
                    </div>

                    {/* Quick Preset Buttons for Schedule */}
                    <div className="flex flex-wrap items-center gap-1.5 pt-1">
                      <span className="text-[10px] text-slate-400 font-semibold mr-1">Quick Presets:</span>
                      <button
                        type="button"
                        onClick={() => {
                          const now = new Date();
                          const start = new Date(now.getTime() + 2 * 60 * 1000);
                          const end = new Date(start.getTime() + testForm.durationMinutes * 60 * 1000);
                          const toLocalISO = (d: Date) => {
                            const off = d.getTimezoneOffset();
                            const adjusted = new Date(d.getTime() - off * 60 * 1000);
                            return adjusted.toISOString().slice(0, 16);
                          };
                          setTestForm({
                            ...testForm,
                            isScheduled: true,
                            scheduledStartTime: toLocalISO(start),
                            scheduledEndTime: toLocalISO(end),
                          });
                        }}
                        className="px-2 py-1 rounded text-[10px] font-semibold bg-indigo-950 text-indigo-300 border border-indigo-700 hover:bg-indigo-900"
                      >
                        Start in 2 mins (Quick Demo)
                      </button>
                      <button
                        type="button"
                        onClick={() => {
                          const now = new Date();
                          const start = new Date(now.getTime() + 15 * 60 * 1000);
                          const end = new Date(start.getTime() + testForm.durationMinutes * 60 * 1000);
                          const toLocalISO = (d: Date) => {
                            const off = d.getTimezoneOffset();
                            const adjusted = new Date(d.getTime() - off * 60 * 1000);
                            return adjusted.toISOString().slice(0, 16);
                          };
                          setTestForm({
                            ...testForm,
                            isScheduled: true,
                            scheduledStartTime: toLocalISO(start),
                            scheduledEndTime: toLocalISO(end),
                          });
                        }}
                        className="px-2 py-1 rounded text-[10px] font-semibold bg-indigo-950 text-indigo-300 border border-indigo-700 hover:bg-indigo-900"
                      >
                        Start in 15 mins
                      </button>
                      <button
                        type="button"
                        onClick={() => {
                          const now = new Date();
                          const start = new Date(now.getTime() + 60 * 60 * 1000);
                          const end = new Date(start.getTime() + testForm.durationMinutes * 60 * 1000);
                          const toLocalISO = (d: Date) => {
                            const off = d.getTimezoneOffset();
                            const adjusted = new Date(d.getTime() - off * 60 * 1000);
                            return adjusted.toISOString().slice(0, 16);
                          };
                          setTestForm({
                            ...testForm,
                            isScheduled: true,
                            scheduledStartTime: toLocalISO(start),
                            scheduledEndTime: toLocalISO(end),
                          });
                        }}
                        className="px-2 py-1 rounded text-[10px] font-semibold bg-indigo-950 text-indigo-300 border border-indigo-700 hover:bg-indigo-900"
                      >
                        Start in 1 hour
                      </button>
                    </div>
                  </div>
                )}
              </div>

              {/* FACULTY LOCK CONTROL */}
              <div
                className={`p-3.5 rounded-xl border transition-colors ${
                  testForm.isLockedByFaculty
                    ? 'bg-rose-500/15 border-rose-500/40 text-rose-200'
                    : 'bg-emerald-500/15 border-emerald-500/40 text-emerald-200'
                }`}
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2.5">
                    {testForm.isLockedByFaculty ? (
                      <div className="w-8 h-8 rounded-lg bg-rose-500/20 border border-rose-500/40 flex items-center justify-center text-rose-400 shrink-0">
                        <Lock className="w-4 h-4" />
                      </div>
                    ) : (
                      <div className="w-8 h-8 rounded-lg bg-emerald-500/20 border border-emerald-500/40 flex items-center justify-center text-emerald-400 shrink-0">
                        <Unlock className="w-4 h-4" />
                      </div>
                    )}
                    <div>
                      <label className="font-bold text-white text-xs cursor-pointer select-none" htmlFor="lock-toggle">
                        Lock Test Paper by Faculty
                      </label>
                      <p className="text-[11px] opacity-80 mt-0.5">
                        {testForm.isLockedByFaculty
                          ? '🔒 Paper will be LOCKED after saving. Students cannot access it until you click "Unlock".'
                          : '🔓 Paper will be UNLOCKED and accessible to students according to enrollment & schedule.'}
                      </p>
                    </div>
                  </div>
                  <input
                    id="lock-toggle"
                    type="checkbox"
                    checked={testForm.isLockedByFaculty}
                    onChange={(e) => setTestForm({ ...testForm, isLockedByFaculty: e.target.checked })}
                    className="w-4 h-4 rounded text-rose-600 bg-slate-900 border-slate-700 focus:ring-rose-500 cursor-pointer"
                  />
                </div>
              </div>

              <div>
                <label className="block font-semibold text-slate-300 mb-1">
                  Description / Instructions
                </label>
                <textarea
                  value={testForm.description}
                  onChange={(e) => setTestForm({ ...testForm, description: e.target.value })}
                  rows={2}
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-lg text-white"
                />
              </div>

              <div className="flex justify-end gap-2 pt-2 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setIsTestModalOpen(false)}
                  className="px-4 py-2 bg-slate-800 text-slate-300 rounded-lg hover:bg-slate-700"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-indigo-600 hover:bg-indigo-500 text-white font-bold rounded-lg shadow-md shadow-indigo-600/20"
                >
                  Save Test Paper
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ================= MODAL: BATCH QUESTION UPLOAD (CSV / JSON) ================= */}
      {isBatchModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-sm">
          <div className="w-full max-w-3xl bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl p-6 text-white max-h-[90vh] flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between pb-3 border-b border-slate-800 mb-4">
                <div>
                  <h3 className="font-bold text-lg flex items-center gap-2">
                    <UploadCloud className="w-5 h-5 text-emerald-400" />
                    Batch Question Paper Upload
                  </h3>
                  <p className="text-xs text-slate-400">
                    Target Test: <strong className="text-white">{currentSelectedTest?.title}</strong>
                  </p>
                </div>
                <button
                  onClick={() => {
                    setIsBatchModalOpen(false);
                    setBatchParsedResult(null);
                  }}
                  className="text-slate-400 hover:text-white"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <div className="flex items-center justify-between gap-4 mb-4">
                <div className="flex items-center gap-2 bg-slate-950 p-1 rounded-xl border border-slate-800">
                  <button
                    type="button"
                    onClick={() => {
                      setBatchFormat('csv');
                      setBatchParsedResult(null);
                    }}
                    className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
                      batchFormat === 'csv'
                        ? 'bg-emerald-600 text-white'
                        : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    CSV Format
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setBatchFormat('json');
                      setBatchParsedResult(null);
                    }}
                    className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
                      batchFormat === 'json'
                        ? 'bg-emerald-600 text-white'
                        : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    JSON Format
                  </button>
                </div>

                {/* Download Sample Buttons */}
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => downloadTemplate(batchFormat)}
                    className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-amber-300 text-xs font-semibold rounded-lg border border-slate-700 flex items-center gap-1.5 transition-colors"
                  >
                    <Download className="w-3.5 h-3.5" />
                    Download Sample {batchFormat.toUpperCase()} Template
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setBatchRawText(
                        batchFormat === 'csv' ? getSampleCsvTemplate() : getSampleJsonTemplate()
                      );
                    }}
                    className="px-3 py-1.5 bg-indigo-950/60 hover:bg-indigo-900/60 text-indigo-300 text-xs font-semibold rounded-lg border border-indigo-700/50"
                  >
                    Load Sample Data
                  </button>
                </div>
              </div>

              <div className="space-y-3">
                <div className="flex items-center justify-between text-xs">
                  <span className="font-semibold text-slate-300">
                    Paste raw {batchFormat.toUpperCase()} data or upload file:
                  </span>
                  <label className="text-emerald-400 hover:underline cursor-pointer font-medium">
                    Upload File (.csv / .json)
                    <input
                      type="file"
                      accept={batchFormat === 'csv' ? '.csv,text/csv' : '.json,application/json'}
                      onChange={(e) => {
                        const file = e.target.files?.[0];
                        if (file) {
                          const reader = new FileReader();
                          reader.onload = (event) => {
                            setBatchRawText(event.target?.result as string);
                          };
                          reader.readAsText(file);
                        }
                      }}
                      className="hidden"
                    />
                  </label>
                </div>

                <textarea
                  value={batchRawText}
                  onChange={(e) => setBatchRawText(e.target.value)}
                  rows={6}
                  className="w-full p-3 bg-slate-950 border border-slate-800 rounded-xl font-mono text-xs text-slate-200 focus:outline-none focus:border-emerald-500"
                  placeholder={
                    batchFormat === 'csv'
                      ? 'Section,Type,Question,ImageUrl,OptionA,OptionB,OptionC,OptionD,CorrectAnswer,PositiveMarks,NegativeMarks,Explanation\n...'
                      : '{\n  "questions": [\n    {\n      "section": "Physics", ...\n    }\n  ]\n}'
                  }
                />

                <div className="flex items-center justify-between">
                  <button
                    type="button"
                    onClick={handleValidateBatch}
                    className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs rounded-xl transition-colors"
                  >
                    Validate & Preview Questions
                  </button>
                </div>

                {/* Validation Preview */}
                {batchParsedResult && (
                  <div className="mt-3 p-3 bg-slate-950 rounded-xl border border-slate-800 max-h-48 overflow-y-auto">
                    {batchParsedResult.errors.length > 0 ? (
                      <div className="text-rose-400 text-xs space-y-1">
                        <p className="font-bold">Errors found during parsing:</p>
                        {batchParsedResult.errors.map((err, i) => (
                          <p key={i}>• {err}</p>
                        ))}
                      </div>
                    ) : (
                      <div className="text-xs space-y-2">
                        <p className="text-emerald-400 font-bold flex items-center gap-1.5">
                          <CheckCircle2 className="w-4 h-4" />
                          Successfully parsed {batchParsedResult.questions.length} questions ready
                          for import!
                        </p>
                        <div className="divide-y divide-slate-800 text-slate-300">
                          {batchParsedResult.questions.map((q, i) => (
                            <div key={i} className="py-1.5 flex items-center justify-between">
                              <span className="truncate max-w-md">
                                <strong>Q{i + 1} ({q.section}):</strong> {q.text}
                              </span>
                              <span className="font-mono text-emerald-400 shrink-0">
                                Key: {q.correctAnswer}
                              </span>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                )}
              </div>
            </div>

            <div className="flex justify-end gap-2 pt-4 border-t border-slate-800 mt-4">
              <button
                type="button"
                onClick={() => setIsBatchModalOpen(false)}
                className="px-4 py-2 bg-slate-800 text-slate-300 rounded-lg hover:bg-slate-700 text-xs"
              >
                Close
              </button>
              <button
                type="button"
                onClick={handleImportBatchQuestions}
                disabled={!batchParsedResult || batchParsedResult.questions.length === 0}
                className="px-5 py-2 bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white font-bold rounded-lg text-xs flex items-center gap-2"
              >
                <Check className="w-4 h-4" />
                Import {batchParsedResult?.questions.length || 0} Questions
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ================= MODAL: INSPECT STUDENT RESPONSE SHEET ================= */}
      {inspectAttempt && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-sm">
          <div className="w-full max-w-4xl bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl p-6 text-white max-h-[90vh] flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between pb-3 border-b border-slate-800 mb-4">
                <div>
                  <h3 className="font-bold text-lg">Student Response Sheet</h3>
                  <p className="text-xs text-slate-400">
                    Candidate: <strong className="text-white">{inspectAttempt.studentName}</strong> (
                    {inspectAttempt.studentRoll}) | Test: {inspectAttempt.testTitle}
                  </p>
                </div>
                <button
                  onClick={() => setInspectAttempt(null)}
                  className="text-slate-400 hover:text-white"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              {/* Quick score summary */}
              <div className="grid grid-cols-4 gap-3 mb-4 bg-slate-950 p-3 rounded-xl border border-slate-800 text-center">
                <div>
                  <p className="text-xs text-slate-400">Total Score</p>
                  <p className="text-xl font-black text-amber-400">
                    {inspectAttempt.score} / {inspectAttempt.maxScore}
                  </p>
                </div>
                <div>
                  <p className="text-xs text-slate-400">Accuracy</p>
                  <p className="text-xl font-black text-emerald-400">{inspectAttempt.accuracy}%</p>
                </div>
                <div>
                  <p className="text-xs text-slate-400">Estimated AIR %ile</p>
                  <p className="text-xl font-black text-indigo-400">
                    {inspectAttempt.percentile}%ile
                  </p>
                </div>
                <div>
                  <p className="text-xs text-slate-400">Correct / Wrong</p>
                  <p className="text-xl font-black text-slate-200">
                    {inspectAttempt.correctCount} / {inspectAttempt.incorrectCount}
                  </p>
                </div>
              </div>

              {/* Section breakdown */}
              <div className="space-y-3 max-h-[50vh] overflow-y-auto pr-2">
                {Object.entries(inspectAttempt.responses).map(([qId, resp], idx) => {
                  const targetTest = tests.find((t) => t.id === inspectAttempt.testId);
                  const q = targetTest?.questions.find((x) => x.id === qId);
                  const isCorrect =
                    resp.selectedOption &&
                    String(resp.selectedOption).trim().toUpperCase() ===
                      String(q?.correctAnswer).trim().toUpperCase();

                  return (
                    <div
                      key={qId}
                      className="p-3 bg-slate-950 rounded-xl border border-slate-800 text-xs"
                    >
                      <div className="flex items-center justify-between mb-1.5">
                        <span className="font-bold text-slate-300">
                          Question {idx + 1} ({q?.section || 'Section'})
                        </span>
                        <span
                          className={`font-bold px-2 py-0.5 rounded text-[10px] ${
                            isCorrect
                              ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                              : resp.selectedOption
                              ? 'bg-rose-500/20 text-rose-400 border border-rose-500/30'
                              : 'bg-slate-800 text-slate-400'
                          }`}
                        >
                          {isCorrect ? 'Correct (+4)' : resp.selectedOption ? 'Incorrect (-1)' : 'Unattempted (0)'}
                        </span>
                      </div>

                      <p className="text-slate-300 mb-2">{q?.text || 'Question text unavailable'}</p>

                      <div className="grid grid-cols-2 gap-2 p-2 bg-slate-900 rounded-lg text-[11px]">
                        <div>
                          <span className="text-slate-400">Candidate Choice: </span>
                          <strong className={isCorrect ? 'text-emerald-400 font-mono' : 'text-rose-400 font-mono'}>
                            {resp.selectedOption || 'None (Unattempted)'}
                          </strong>
                        </div>
                        <div>
                          <span className="text-slate-400">Official Faculty Key: </span>
                          <strong className="text-emerald-400 font-mono">
                            {q?.correctAnswer}
                          </strong>
                        </div>
                      </div>
                      {q?.explanation && (
                        <p className="text-[11px] text-slate-400 italic mt-1.5">
                          Faculty Solution: {q.explanation}
                        </p>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>

            <div className="flex justify-end pt-3 border-t border-slate-800 mt-4">
              <button
                onClick={() => setInspectAttempt(null)}
                className="px-4 py-2 bg-slate-800 text-white rounded-lg text-xs"
              >
                Close Sheet
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ================= MODAL: QUICK AUTOMATED SCHEDULING ================= */}
      {scheduleModalTest && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-sm">
          <div className="w-full max-w-lg bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl p-6 text-white space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <div className="flex items-center gap-2">
                <Calendar className="w-5 h-5 text-indigo-400" />
                <div>
                  <h3 className="font-bold text-base text-white">Automated Exam Scheduling</h3>
                  <p className="text-[11px] text-slate-400">Set start and end times so exams trigger automatically for students</p>
                </div>
              </div>
              <button
                onClick={() => setScheduleModalTest(null)}
                className="text-slate-400 hover:text-white p-1 rounded-lg hover:bg-slate-800"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="bg-slate-950 p-3 rounded-xl border border-slate-800 text-xs">
              <p className="text-slate-400">Target Test:</p>
              <p className="font-bold text-white text-sm">{scheduleModalTest.title}</p>
              <p className="text-amber-400 font-mono text-[11px] mt-0.5">
                CBT Timer Duration: {scheduleModalTest.durationMinutes} mins • Total Questions: {scheduleModalTest.questions.length}
              </p>
            </div>

            {/* Enable Schedule Toggle */}
            <div className="flex items-center justify-between p-3 bg-slate-950/70 rounded-xl border border-slate-800">
              <div>
                <span className="font-bold text-xs text-white block">Enable Automated Scheduling</span>
                <span className="text-[11px] text-slate-400">
                  When active, candidate access triggers automatically at the designated start time.
                </span>
              </div>
              <input
                type="checkbox"
                checked={schedIsActive}
                onChange={(e) => setSchedIsActive(e.target.checked)}
                className="w-4 h-4 rounded text-indigo-600 bg-slate-900 border-slate-700 cursor-pointer"
              />
            </div>

            {/* Inputs */}
            <div className="space-y-3">
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Automated Start Date & Time:
                </label>
                <input
                  type="datetime-local"
                  value={schedStartInput}
                  onChange={(e) => {
                    setSchedStartInput(e.target.value);
                    if (!schedIsActive && e.target.value) setSchedIsActive(true);
                  }}
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-lg text-white font-mono text-xs"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Automated End Date & Time:
                </label>
                <input
                  type="datetime-local"
                  value={schedEndInput}
                  onChange={(e) => setSchedEndInput(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-lg text-white font-mono text-xs"
                />
              </div>
            </div>

            {/* Quick Presets & Instant Trigger */}
            <div className="space-y-2 pt-1">
              <span className="text-[11px] font-semibold text-slate-400 block">Quick Schedule Presets:</span>
              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={() => {
                    const now = new Date();
                    const start = new Date(now.getTime() + 2 * 60 * 1000);
                    const end = new Date(start.getTime() + scheduleModalTest.durationMinutes * 60 * 1000);
                    const toLocalISO = (d: Date) => {
                      const off = d.getTimezoneOffset();
                      const adjusted = new Date(d.getTime() - off * 60 * 1000);
                      return adjusted.toISOString().slice(0, 16);
                    };
                    setSchedStartInput(toLocalISO(start));
                    setSchedEndInput(toLocalISO(end));
                    setSchedIsActive(true);
                  }}
                  className="p-2 text-left bg-slate-950 hover:bg-slate-800 border border-slate-800 rounded-lg text-xs transition-colors"
                >
                  <p className="font-bold text-white text-[11px]">⚡ In 2 Minutes</p>
                  <p className="text-[10px] text-slate-400">Quick automated trigger test</p>
                </button>
                <button
                  type="button"
                  onClick={() => {
                    const now = new Date();
                    const start = new Date(now.getTime() + 15 * 60 * 1000);
                    const end = new Date(start.getTime() + scheduleModalTest.durationMinutes * 60 * 1000);
                    const toLocalISO = (d: Date) => {
                      const off = d.getTimezoneOffset();
                      const adjusted = new Date(d.getTime() - off * 60 * 1000);
                      return adjusted.toISOString().slice(0, 16);
                    };
                    setSchedStartInput(toLocalISO(start));
                    setSchedEndInput(toLocalISO(end));
                    setSchedIsActive(true);
                  }}
                  className="p-2 text-left bg-slate-950 hover:bg-slate-800 border border-slate-800 rounded-lg text-xs transition-colors"
                >
                  <p className="font-bold text-white text-[11px]">🕒 In 15 Minutes</p>
                  <p className="text-[10px] text-slate-400">Standard candidate prep window</p>
                </button>
              </div>

              {/* Instant Trigger Now Button */}
              <button
                type="button"
                onClick={() => {
                  const now = new Date();
                  const end = new Date(now.getTime() + scheduleModalTest.durationMinutes * 60 * 1000);
                  const toLocalISO = (d: Date) => {
                    const off = d.getTimezoneOffset();
                    const adjusted = new Date(d.getTime() - off * 60 * 1000);
                    return adjusted.toISOString().slice(0, 16);
                  };
                  const startStr = toLocalISO(now);
                  const endStr = toLocalISO(end);
                  updateTestSchedule(scheduleModalTest.id, startStr, endStr, true);
                  // Also unlock if locked so students can enter right now
                  if (scheduleModalTest.isLockedByFaculty) {
                    toggleTestLock(scheduleModalTest.id);
                  }
                  setScheduleModalTest(null);
                }}
                className="w-full py-2.5 px-3 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-xl text-xs transition-colors shadow-md flex items-center justify-center gap-1.5"
              >
                <Zap className="w-4 h-4 text-amber-300" />
                <span>⚡ Trigger Exam Now (Go Live Instantly & Auto-Unlock)</span>
              </button>
            </div>

            <div className="flex items-center justify-between pt-3 border-t border-slate-800">
              <button
                type="button"
                onClick={() => {
                  updateTestSchedule(scheduleModalTest.id, undefined, undefined, false);
                  setScheduleModalTest(null);
                }}
                className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg text-xs"
              >
                Clear Schedule (Always Live)
              </button>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setScheduleModalTest(null)}
                  className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg text-xs"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  onClick={() => {
                    updateTestSchedule(
                      scheduleModalTest.id,
                      schedStartInput || undefined,
                      schedEndInput || undefined,
                      schedIsActive
                    );
                    setScheduleModalTest(null);
                  }}
                  className="px-4 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white font-bold rounded-lg text-xs shadow-sm"
                >
                  Save Schedule
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ================= MODAL: QUICK SUBJECT ORDER CONFIGURATION ================= */}
      {orderModalTest && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-sm">
          <div className="w-full max-w-lg bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl p-6 text-white space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <div>
                <h3 className="font-bold text-base text-white">Choose Subject Order</h3>
                <p className="text-xs text-slate-400">
                  Select which subject appears at first on the CBT examination interface for students.
                </p>
              </div>
              <button
                onClick={() => setOrderModalTest(null)}
                className="text-slate-400 hover:text-white p-1 rounded-lg hover:bg-slate-800"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="bg-slate-950 p-3 rounded-xl border border-slate-800 text-xs">
              <p className="text-slate-400">Target Test Paper:</p>
              <p className="font-bold text-white text-sm">{orderModalTest.title}</p>
              <div className="mt-2 flex items-center gap-1.5">
                <span className="text-[11px] text-amber-400 font-bold">1st Subject to Appear:</span>
                <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-amber-500/20 text-amber-300 border border-amber-500/40">
                  ★ {orderSubjects[0]}
                </span>
              </div>
            </div>

            {/* Interactive Ordering List */}
            <div className="space-y-2">
              <label className="block text-xs font-semibold text-slate-300">
                Subject Order Sequence (Top item appears first in student test):
              </label>
              {orderSubjects.map((subj, idx) => (
                <div
                  key={subj}
                  className={`flex items-center justify-between px-3.5 py-2.5 rounded-xl border text-xs transition-all ${
                    idx === 0
                      ? 'bg-amber-500/10 border-amber-500/40 text-amber-200 shadow-sm'
                      : 'bg-slate-950 border-slate-800 text-slate-300'
                  }`}
                >
                  <div className="flex items-center gap-2.5">
                    <span
                      className={`w-6 h-6 rounded-full flex items-center justify-center font-mono font-bold text-xs ${
                        idx === 0 ? 'bg-amber-500 text-slate-950 font-black' : 'bg-slate-800 text-slate-400'
                      }`}
                    >
                      {idx + 1}
                    </span>
                    <div>
                      <span className="font-bold text-white text-sm">{subj}</span>
                      {idx === 0 && (
                        <span className="ml-2 text-[10px] font-bold text-amber-400 bg-amber-500/20 px-2 py-0.5 rounded border border-amber-500/30">
                          ★ 1st Subject in CBT Test
                        </span>
                      )}
                    </div>
                  </div>

                  <div className="flex items-center gap-1.5">
                    {idx !== 0 && (
                      <button
                        type="button"
                        onClick={() => {
                          const newOrder = [subj, ...orderSubjects.filter((s) => s !== subj)];
                          setOrderSubjects(newOrder);
                        }}
                        className="px-2 py-1 rounded-lg text-[10px] font-bold bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 border border-amber-500/30"
                      >
                        Set as 1st
                      </button>
                    )}
                    <button
                      type="button"
                      disabled={idx === 0}
                      onClick={() => {
                        if (idx === 0) return;
                        const newArr = [...orderSubjects];
                        const temp = newArr[idx - 1];
                        newArr[idx - 1] = newArr[idx];
                        newArr[idx] = temp;
                        setOrderSubjects(newArr);
                      }}
                      className={`p-1.5 rounded-lg text-slate-300 ${
                        idx === 0 ? 'opacity-30 cursor-not-allowed' : 'hover:bg-slate-800 bg-slate-900 border border-slate-800'
                      }`}
                      title="Move Up"
                    >
                      <ArrowUp className="w-3.5 h-3.5" />
                    </button>
                    <button
                      type="button"
                      disabled={idx === orderSubjects.length - 1}
                      onClick={() => {
                        if (idx === orderSubjects.length - 1) return;
                        const newArr = [...orderSubjects];
                        const temp = newArr[idx + 1];
                        newArr[idx + 1] = newArr[idx];
                        newArr[idx] = temp;
                        setOrderSubjects(newArr);
                      }}
                      className={`p-1.5 rounded-lg text-slate-300 ${
                        idx === orderSubjects.length - 1
                          ? 'opacity-30 cursor-not-allowed'
                          : 'hover:bg-slate-800 bg-slate-900 border border-slate-800'
                      }`}
                      title="Move Down"
                    >
                      <ArrowDown className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              ))}
            </div>

            <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-800">
              <button
                type="button"
                onClick={() => setOrderModalTest(null)}
                className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg text-xs"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={() => {
                  updateTestSubjectOrder(orderModalTest.id, orderSubjects);
                  setOrderModalTest(null);
                }}
                className="px-4 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white font-bold rounded-lg text-xs shadow-sm"
              >
                Save Subject Order
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Device Management & Live Sync Modal (Max 2 Devices Restriction) */}
      {isDeviceModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl max-w-lg w-full p-6 text-white shadow-2xl relative">
            <button
              onClick={() => setIsDeviceModalOpen(false)}
              className="absolute top-4 right-4 text-slate-400 hover:text-white p-1 rounded-lg hover:bg-slate-800 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="flex items-center gap-3 mb-4">
              <div className="w-12 h-12 rounded-xl bg-amber-500/20 border border-amber-500/30 text-amber-400 flex items-center justify-center">
                <Laptop className="w-6 h-6" />
              </div>
              <div>
                <h3 className="text-lg font-bold text-white flex items-center gap-2">
                  Faculty Device Security
                  <span className="text-[10px] font-black uppercase px-2 py-0.5 rounded bg-amber-500/20 text-amber-300 border border-amber-500/30">
                    Max 2 Devices
                  </span>
                </h3>
                <p className="text-xs text-slate-400">
                  Strict security: Only up to 2 active devices allowed simultaneously.
                </p>
              </div>
            </div>

            {/* Live Student Sync Notification */}
            <div className="mb-4 p-3 bg-indigo-950/40 border border-indigo-500/30 rounded-xl flex items-start gap-2.5 text-xs text-indigo-200">
              <Wifi className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5 animate-pulse" />
              <div>
                <p className="font-bold text-white">Live Real-Time Cross-Student Sync Active</p>
                <p className="text-slate-300 mt-0.5 leading-relaxed">
                  Whatever changes you make in this Faculty App (adding tests, deleting tests, modifying papers, or approving payment verifications) are automatically synchronized to every student's app in real time.
                </p>
              </div>
            </div>

            <div className="space-y-3 mb-5">
              <p className="text-xs font-semibold text-slate-300 uppercase tracking-wider">
                Current Active Faculty Sessions ({activeFacultyDevices?.length || 1}/2 Slots Used):
              </p>

              {(!activeFacultyDevices || activeFacultyDevices.length === 0) ? (
                <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 text-xs text-slate-300 flex items-center justify-between">
                  <div className="flex items-center gap-2.5">
                    <Laptop className="w-4 h-4 text-emerald-400 shrink-0" />
                    <div>
                      <p className="font-bold text-white">This Device (Primary Station)</p>
                      <p className="text-[10px] text-emerald-400 font-mono">Status: Connected & Authenticated</p>
                    </div>
                  </div>
                  <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                    Current Device
                  </span>
                </div>
              ) : (
                activeFacultyDevices.map((dev, idx) => {
                  const isThisDevice = dev.deviceId === currentDeviceId;
                  return (
                    <div
                      key={dev.deviceId || idx}
                      className="p-3 bg-slate-950 rounded-xl border border-slate-800 text-xs flex items-center justify-between gap-3"
                    >
                      <div className="flex items-center gap-2.5 min-w-0">
                        <Laptop className="w-4 h-4 text-amber-400 shrink-0" />
                        <div className="truncate">
                          <p className="font-bold text-white flex items-center gap-1.5 truncate">
                            {dev.deviceName || `Faculty Device ${idx + 1}`}
                            {isThisDevice && (
                              <span className="px-1.5 py-0.2 text-[9px] font-extrabold bg-emerald-500/20 text-emerald-300 rounded border border-emerald-500/30">
                                This Device
                              </span>
                            )}
                          </p>
                          <p className="text-[10px] text-slate-400 mt-0.5">
                            IP: {dev.ip} • Logged in: {new Date(dev.loggedInAt).toLocaleString([], { dateStyle: 'short', timeStyle: 'short' })}
                          </p>
                        </div>
                      </div>

                      {!isThisDevice && (
                        <button
                          type="button"
                          onClick={() => revokeFacultyDevice(dev.deviceId)}
                          className="px-2.5 py-1 text-xs font-bold bg-rose-600 hover:bg-rose-500 text-white rounded-lg transition-colors shrink-0 shadow-sm"
                        >
                          Revoke Slot
                        </button>
                      )}
                    </div>
                  );
                })
              )}

              {/* Unused Slot indicator if < 2 devices */}
              {(activeFacultyDevices?.length || 1) < 2 && (
                <div className="p-3 bg-slate-950/40 border border-dashed border-slate-800 rounded-xl text-xs text-slate-500 flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Smartphone className="w-4 h-4 text-slate-600" />
                    <span>Slot 2: Available for 1 additional faculty device</span>
                  </div>
                  <span className="text-[10px] text-slate-500 font-mono">Available</span>
                </div>
              )}
            </div>

            <div className="flex justify-end pt-3 border-t border-slate-800">
              <button
                type="button"
                onClick={() => setIsDeviceModalOpen(false)}
                className="px-4 py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs rounded-xl shadow-md transition-all"
              >
                Done
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ================= MODAL: CREATE / EDIT FACULTY PROFILE ================= */}
      {isFacultyModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-sm">
          <div className="w-full max-w-xl bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl p-6 text-white text-xs max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800 mb-4">
              <h3 className="font-bold text-base text-white flex items-center gap-2">
                <Users className="w-4 h-4 text-emerald-400" />
                {editingFaculty ? 'Edit Faculty Member Bio & Credentials' : 'Add New Faculty Member'}
              </h3>
              <button
                type="button"
                onClick={() => setIsFacultyModalOpen(false)}
                className="text-slate-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveFaculty} className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-300 mb-1">Faculty Name</label>
                  <input
                    type="text"
                    value={facultyForm.name}
                    onChange={(e) => setFacultyForm({ ...facultyForm, name: e.target.value })}
                    placeholder="e.g. Er. Manish Saha"
                    className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-white text-xs"
                    required
                  />
                </div>

                <div>
                  <label className="block font-semibold text-slate-300 mb-1">Designation / Role</label>
                  <input
                    type="text"
                    value={facultyForm.role}
                    onChange={(e) => setFacultyForm({ ...facultyForm, role: e.target.value })}
                    placeholder="e.g. Head of Physics & Academic Director"
                    className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-white text-xs"
                    required
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-300 mb-1">Department</label>
                  <select
                    value={facultyForm.department}
                    onChange={(e) => setFacultyForm({ ...facultyForm, department: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-white text-xs"
                  >
                    <option value="Physics">Physics</option>
                    <option value="Chemistry">Chemistry</option>
                    <option value="Mathematics">Mathematics</option>
                    <option value="Biology">Biology</option>
                  </select>
                </div>

                <div>
                  <label className="block font-semibold text-slate-300 mb-1">Qualifications & Experience</label>
                  <input
                    type="text"
                    value={facultyForm.qualification}
                    onChange={(e) => setFacultyForm({ ...facultyForm, qualification: e.target.value })}
                    placeholder="e.g. B.Tech - IIT Guwahati | 12+ Yrs Experience"
                    className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-white text-xs"
                    required
                  />
                </div>
              </div>

              {/* Avatar Photo */}
              <div>
                <label className="block font-semibold text-slate-300 mb-1">Profile Photo (URL or Upload)</label>
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-xl border border-slate-700 bg-slate-950 overflow-hidden shrink-0">
                    {facultyForm.avatar ? (
                      <img src={facultyForm.avatar} alt="Avatar" className="w-full h-full object-cover" />
                    ) : (
                      <Users className="w-full h-full p-2.5 text-slate-600" />
                    )}
                  </div>
                  <div className="flex-1 space-y-1.5">
                    <input
                      type="text"
                      value={facultyForm.avatar}
                      onChange={(e) => setFacultyForm({ ...facultyForm, avatar: e.target.value })}
                      placeholder="Paste photo image URL..."
                      className="w-full px-3 py-1.5 bg-slate-950 border border-slate-700 rounded-lg text-white text-xs"
                    />
                    <label className="inline-block px-3 py-1 bg-slate-800 hover:bg-slate-700 border border-slate-700 rounded cursor-pointer text-[11px] text-slate-300">
                      Upload Local Photo
                      <input type="file" accept="image/*" onChange={handleFacultyAvatarFileChange} className="hidden" />
                    </label>
                  </div>
                </div>
              </div>

              <div>
                <label className="block font-semibold text-slate-300 mb-1">Faculty Bio & Teaching Pedagogy</label>
                <textarea
                  value={facultyForm.bio}
                  onChange={(e) => setFacultyForm({ ...facultyForm, bio: e.target.value })}
                  rows={3}
                  placeholder="Describe teaching methodology, conceptual visualization techniques, and mentoring philosophy..."
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-white text-xs"
                  required
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-300 mb-1">Core Focus Subjects (Comma Separated)</label>
                  <input
                    type="text"
                    value={facultyForm.subjects}
                    onChange={(e) => setFacultyForm({ ...facultyForm, subjects: e.target.value })}
                    placeholder="Mechanics, Electrodynamics, Optics"
                    className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-white text-xs"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-slate-300 mb-1">Track Record & Best Ranks</label>
                  <input
                    type="text"
                    value={facultyForm.trackRecord}
                    onChange={(e) => setFacultyForm({ ...facultyForm, trackRecord: e.target.value })}
                    placeholder="e.g. Mentored AIR 142 (JEE Adv), AIR 289 (JEE Main)"
                    className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-white text-xs"
                  />
                </div>
              </div>

              <div>
                <label className="block font-semibold text-slate-300 mb-1">Inspirational Quote</label>
                <input
                  type="text"
                  value={facultyForm.quote}
                  onChange={(e) => setFacultyForm({ ...facultyForm, quote: e.target.value })}
                  placeholder='"Physics is not a formula memorization game..."'
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-white text-xs"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="block font-semibold text-slate-300 mb-1">Contact Phone</label>
                  <input
                    type="text"
                    value={facultyForm.phone}
                    onChange={(e) => setFacultyForm({ ...facultyForm, phone: e.target.value })}
                    placeholder="+91 60007 30250"
                    className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-white text-xs font-mono"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-slate-300 mb-1">Email Address</label>
                  <input
                    type="email"
                    value={facultyForm.email}
                    onChange={(e) => setFacultyForm({ ...facultyForm, email: e.target.value })}
                    placeholder="mentor@argoncoaching.com"
                    className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-white text-xs font-mono"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-slate-300 mb-1">Doubt Clearance Timings</label>
                  <input
                    type="text"
                    value={facultyForm.availableTimings}
                    onChange={(e) => setFacultyForm({ ...facultyForm, availableTimings: e.target.value })}
                    placeholder="Mon-Sat: 4:00 PM - 7:00 PM"
                    className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-white text-xs"
                  />
                </div>
              </div>

              <div className="pt-3 border-t border-slate-800 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsFacultyModalOpen(false)}
                  className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl font-semibold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold rounded-xl shadow-md transition-all flex items-center gap-1.5"
                >
                  <Check className="w-4 h-4" />
                  Save & Live Sync Bio
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
