import React, { useState } from 'react';
import { useApp } from '../context/AppContext.tsx';
import type { PaymentVerificationRequest } from '../types/index.ts';
import {
  ShieldCheck,
  CheckCircle2,
  XCircle,
  Clock,
  Search,
  Phone,
  MessageCircle,
  Hash,
  Check,
  X,
  Plus,
  ArrowRight,
  AlertTriangle,
  RotateCcw,
  Sparkles,
} from 'lucide-react';

interface FacultyVerificationRequestsProps {
  onNavigateToStudent?: (studentRoll: string) => void;
}

export const FacultyVerificationRequests: React.FC<FacultyVerificationRequestsProps> = ({
  onNavigateToStudent,
}) => {
  const {
    verificationRequests,
    approveVerificationRequest,
    rejectVerificationRequest,
    createDirectVerificationRequest,
    students,
    testSeries,
  } = useApp();

  const [filter, setFilter] = useState<'all' | 'pending' | 'approved' | 'rejected'>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [copiedUtrId, setCopiedUtrId] = useState<string | null>(null);
  const [alertMsg, setAlertMsg] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  // Rejection modal state
  const [rejectModalReq, setRejectModalReq] = useState<{
    id: string;
    studentName: string;
    studentRoll: string;
    seriesTitle: string;
    reason: string;
  } | null>(null);

  const pendingRequestsCount = verificationRequests.filter((r) => r.status === 'pending').length;
  const approvedRequestsCount = verificationRequests.filter((r) => r.status === 'approved').length;
  const rejectedRequestsCount = verificationRequests.filter((r) => r.status === 'rejected').length;

  // Filter requests
  const filteredRequests = verificationRequests.filter((req) => {
    if (filter !== 'all' && req.status !== filter) return false;
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      return (
        req.studentName.toLowerCase().includes(q) ||
        req.studentRoll.toLowerCase().includes(q) ||
        req.seriesTitle.toLowerCase().includes(q) ||
        req.upiTxnId.toLowerCase().includes(q) ||
        (req.studentPhone && req.studentPhone.toLowerCase().includes(q))
      );
    }
    return true;
  });

  const handleAccept = (reqId: string) => {
    const req = verificationRequests.find((r) => r.id === reqId);
    approveVerificationRequest(reqId);
    setAlertMsg({
      type: 'success',
      text: `Access Granted! Verification accepted for ${req?.studentName} (${req?.studentRoll}). The student can now access "${req?.seriesTitle}" and take CBT tests!`,
    });
    setTimeout(() => setAlertMsg(null), 6000);
  };

  const handleConfirmReject = () => {
    if (!rejectModalReq) return;
    rejectVerificationRequest(rejectModalReq.id, rejectModalReq.reason);
    setAlertMsg({
      type: 'error',
      text: `Verification rejected for ${rejectModalReq.studentName}. Access remains locked. Reason: "${rejectModalReq.reason}".`,
    });
    setRejectModalReq(null);
    setTimeout(() => setAlertMsg(null), 6000);
  };

  const handleSimulateRequest = () => {
    // Pick an enrolled student without series or first student
    const student = students.find((s) => s.rollNo === 'ARG-2026-888') || students[0];
    const series = testSeries.find((s) => s.price > 0) || testSeries[0];
    const mockUtr = `UPI-REF-${Math.floor(100000000000 + Math.random() * 900000000000)}`;

    createDirectVerificationRequest({
      studentId: student?.id || 'student-demo',
      studentName: student?.name || 'Aspirant',
      studentRoll: student?.rollNo || 'ARG-JEE-2026-999',
      studentPhone: student?.phone || '+91 94350 12345',
      seriesId: series.id,
      upiTxnId: mockUtr,
    });

    setAlertMsg({
      type: 'success',
      text: `Simulated payment verification request created for ${student?.name} (${series?.title}) with UTR: ${mockUtr}! You can now Accept or Reject.`,
    });
    setTimeout(() => setAlertMsg(null), 6000);
  };

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 bg-gradient-to-r from-amber-950/40 via-slate-900 to-indigo-950/30 border border-amber-500/30 rounded-2xl p-6">
        <div>
          <div className="flex items-center gap-2">
            <span className="px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider bg-amber-500/20 text-amber-300 border border-amber-500/30">
              Payment Access Control
            </span>
            <span className="text-xs text-slate-400 font-medium">Faculty Gatekeeper</span>
          </div>
          <h2 className="text-2xl font-black text-white mt-1 flex items-center gap-2">
            <ShieldCheck className="w-6 h-6 text-amber-400" />
            Student Payment Verification Requests
          </h2>
          <p className="text-xs text-slate-300 mt-1.5 max-w-2xl leading-relaxed">
            Students scan the UPI QR code and submit their 12-digit UTR reference here for verification. 
            <strong className="text-amber-300"> Without faculty acceptance, no access will be provided to the test series.</strong> Once you review and accept the request, full CBT examination access is unlocked immediately.
          </p>
        </div>

        {/* Demo Simulation Button */}
        <button
          type="button"
          onClick={handleSimulateRequest}
          className="px-4 py-2.5 bg-slate-800 hover:bg-slate-700 text-amber-300 border border-amber-500/30 font-bold text-xs rounded-xl shadow-md transition-all flex items-center gap-2 shrink-0"
          title="Simulate receiving a new payment verification request from a student"
        >
          <Plus className="w-4 h-4 text-amber-400" />
          Simulate Student Payment Request
        </button>
      </div>

      {/* Action Notification Alert */}
      {alertMsg && (
        <div
          className={`p-4 rounded-xl border flex items-center justify-between text-xs font-bold animate-fadeIn ${
            alertMsg.type === 'success'
              ? 'bg-emerald-500/15 border-emerald-500/30 text-emerald-300'
              : 'bg-rose-500/15 border-rose-500/30 text-rose-300'
          }`}
        >
          <div className="flex items-center gap-2">
            {alertMsg.type === 'success' ? (
              <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-400" />
            ) : (
              <XCircle className="w-4 h-4 shrink-0 text-rose-400" />
            )}
            <span>{alertMsg.text}</span>
          </div>
          <button onClick={() => setAlertMsg(null)} className="p-1 hover:text-white">
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Metric Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4">
          <p className="text-xs text-slate-400 font-semibold uppercase tracking-wider">Total Inquiries</p>
          <p className="text-2xl font-black text-white mt-1">{verificationRequests.length}</p>
          <p className="text-[11px] text-slate-500 mt-1">All UTR submissions</p>
        </div>

        <div className="bg-slate-900 border border-amber-500/30 bg-amber-950/10 rounded-2xl p-4">
          <div className="flex items-center justify-between">
            <p className="text-xs text-amber-400 font-semibold uppercase tracking-wider">Pending Action</p>
            {pendingRequestsCount > 0 && (
              <span className="w-2.5 h-2.5 rounded-full bg-amber-400 animate-ping"></span>
            )}
          </div>
          <p className="text-2xl font-black text-amber-400 mt-1">{pendingRequestsCount}</p>
          <p className="text-[11px] text-amber-300/70 mt-1">Access currently locked</p>
        </div>

        <div className="bg-slate-900 border border-emerald-500/30 bg-emerald-950/10 rounded-2xl p-4">
          <p className="text-xs text-emerald-400 font-semibold uppercase tracking-wider">Accepted & Enrolled</p>
          <p className="text-2xl font-black text-emerald-400 mt-1">{approvedRequestsCount}</p>
          <p className="text-[11px] text-emerald-300/70 mt-1">Access granted to CBT</p>
        </div>

        <div className="bg-slate-900 border border-rose-500/30 bg-rose-950/10 rounded-2xl p-4">
          <p className="text-xs text-rose-400 font-semibold uppercase tracking-wider">Rejected / Denied</p>
          <p className="text-2xl font-black text-rose-400 mt-1">{rejectedRequestsCount}</p>
          <p className="text-[11px] text-rose-300/70 mt-1">Access withheld</p>
        </div>
      </div>

      {/* Filter Tabs and Search Bar */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 flex flex-col md:flex-row items-stretch md:items-center justify-between gap-4">
        <div className="flex flex-wrap items-center gap-2">
          <button
            type="button"
            onClick={() => setFilter('all')}
            className={`px-3.5 py-1.5 rounded-lg text-xs font-bold transition-all ${
              filter === 'all'
                ? 'bg-amber-500 text-slate-950'
                : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
            }`}
          >
            All Requests ({verificationRequests.length})
          </button>
          <button
            type="button"
            onClick={() => setFilter('pending')}
            className={`px-3.5 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 ${
              filter === 'pending'
                ? 'bg-amber-500 text-slate-950'
                : 'bg-slate-800 text-amber-300 hover:bg-slate-700'
            }`}
          >
            <Clock className="w-3.5 h-3.5" />
            Pending Action ({pendingRequestsCount})
          </button>
          <button
            type="button"
            onClick={() => setFilter('approved')}
            className={`px-3.5 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 ${
              filter === 'approved'
                ? 'bg-emerald-500 text-slate-950'
                : 'bg-slate-800 text-emerald-300 hover:bg-slate-700'
            }`}
          >
            <CheckCircle2 className="w-3.5 h-3.5" />
            Approved ({approvedRequestsCount})
          </button>
          <button
            type="button"
            onClick={() => setFilter('rejected')}
            className={`px-3.5 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 ${
              filter === 'rejected'
                ? 'bg-rose-500 text-slate-950'
                : 'bg-slate-800 text-rose-300 hover:bg-slate-700'
            }`}
          >
            <XCircle className="w-3.5 h-3.5" />
            Rejected ({rejectedRequestsCount})
          </button>
        </div>

        <div className="relative min-w-[280px]">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search by student, roll no, or UTR..."
            className="w-full pl-9 pr-3 py-2 bg-slate-800 border border-slate-700 rounded-lg text-xs text-white placeholder:text-slate-500 focus:outline-none focus:border-amber-500"
          />
        </div>
      </div>

      {/* Requests List */}
      {filteredRequests.length === 0 ? (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-12 text-center text-slate-400">
          <ShieldCheck className="w-12 h-12 text-slate-600 mx-auto mb-3" />
          <h4 className="text-base font-bold text-white">No Verification Requests Found</h4>
          <p className="text-xs text-slate-400 mt-1 max-w-md mx-auto">
            {searchQuery
              ? 'No requests matched your search criteria.'
              : 'When students make UPI payment in the Student Portal and submit their UTR number, their requests will appear here for you to Accept or Reject.'}
          </p>
        </div>
      ) : (
        <div className="space-y-4">
          {filteredRequests.map((req) => (
            <div
              key={req.id}
              className={`bg-slate-900 border rounded-2xl p-5 transition-all ${
                req.status === 'pending'
                  ? 'border-amber-500/40 shadow-lg shadow-amber-500/5 bg-gradient-to-r from-slate-900 via-amber-950/10 to-slate-900'
                  : req.status === 'approved'
                  ? 'border-emerald-500/30'
                  : 'border-slate-800 opacity-80'
              }`}
            >
              <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
                {/* Left: Student Identity & Contact */}
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 rounded-xl bg-slate-800 border border-slate-700 flex items-center justify-center font-black text-base text-amber-400 shrink-0">
                    {req.studentName.substring(0, 2).toUpperCase()}
                  </div>

                  <div>
                    <div className="flex flex-wrap items-center gap-2">
                      <h4 className="text-base font-bold text-white">{req.studentName}</h4>
                      <span className="font-mono text-xs px-2 py-0.5 rounded bg-slate-800 border border-slate-700 text-amber-300 font-bold">
                        {req.studentRoll}
                      </span>

                      {/* Status Badges */}
                      {req.status === 'pending' && (
                        <span className="px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider bg-amber-500/20 text-amber-300 border border-amber-500/40 flex items-center gap-1">
                          <Clock className="w-3 h-3 text-amber-400 animate-pulse" />
                          Pending Faculty Verification (Access Locked)
                        </span>
                      )}
                      {req.status === 'approved' && (
                        <span className="px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 flex items-center gap-1">
                          <CheckCircle2 className="w-3 h-3 text-emerald-400" />
                          Verified & Accepted (Access Granted)
                        </span>
                      )}
                      {req.status === 'rejected' && (
                        <span className="px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider bg-rose-500/20 text-rose-300 border border-rose-500/40 flex items-center gap-1">
                          <XCircle className="w-3 h-3 text-rose-400" />
                          Rejected (Access Denied)
                        </span>
                      )}
                    </div>

                    {/* Student Phone with Direct Contact Action */}
                    <div className="flex flex-wrap items-center gap-3 mt-2 text-xs text-slate-400">
                      <span className="flex items-center gap-1.5 text-slate-300 font-medium">
                        <Phone className="w-3.5 h-3.5 text-indigo-400" />
                        {req.studentPhone || 'No contact phone'}
                      </span>

                      {req.studentPhone && (
                        <div className="flex items-center gap-1.5">
                          <a
                            href={`tel:${req.studentPhone.replace(/\s+/g, '')}`}
                            className="px-2 py-0.5 rounded bg-indigo-500/20 hover:bg-indigo-500/30 text-indigo-300 text-[11px] font-semibold flex items-center gap-1 transition-colors"
                            title="Call Student"
                          >
                            <Phone className="w-3 h-3" /> Call
                          </a>
                          <a
                            href={`https://wa.me/${req.studentPhone.replace(/[^0-9]/g, '')}`}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="px-2 py-0.5 rounded bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-300 text-[11px] font-semibold flex items-center gap-1 transition-colors"
                            title="Chat on WhatsApp"
                          >
                            <MessageCircle className="w-3 h-3" /> WhatsApp
                          </a>
                        </div>
                      )}

                      <span className="text-slate-600">•</span>
                      <span className="text-slate-400">
                        Submitted: {new Date(req.requestedAt).toLocaleString('en-IN', {
                          day: 'numeric',
                          month: 'short',
                          hour: '2-digit',
                          minute: '2-digit',
                        })}
                      </span>
                    </div>
                  </div>
                </div>

                {/* Middle: Series Details & UPI UTR */}
                <div className="bg-slate-950/70 border border-slate-800 rounded-xl p-3 min-w-[280px]">
                  <div className="flex items-center justify-between text-xs">
                    <span className="text-slate-400">Test Series:</span>
                    <span className="font-bold text-white text-right truncate max-w-[190px]">
                      {req.seriesTitle}
                    </span>
                  </div>
                  <div className="flex items-center justify-between text-xs mt-1.5">
                    <span className="text-slate-400">Amount Paid:</span>
                    <span className="font-black text-amber-400">₹{req.seriesPrice}</span>
                  </div>
                  <div className="flex items-center justify-between text-xs mt-1.5 pt-1.5 border-t border-slate-800">
                    <span className="text-slate-400">UTR Reference:</span>
                    <div className="flex items-center gap-1.5">
                      <code className="font-mono font-bold text-amber-300 text-xs bg-slate-900 px-1.5 py-0.5 rounded border border-slate-700">
                        {req.upiTxnId}
                      </code>
                      <button
                        type="button"
                        onClick={() => {
                          navigator.clipboard.writeText(req.upiTxnId);
                          setCopiedUtrId(req.id);
                          setTimeout(() => setCopiedUtrId(null), 2000);
                        }}
                        className="p-1 text-slate-400 hover:text-white"
                        title="Copy UTR"
                      >
                        {copiedUtrId === req.id ? (
                          <Check className="w-3.5 h-3.5 text-emerald-400" />
                        ) : (
                          <Hash className="w-3.5 h-3.5" />
                        )}
                      </button>
                    </div>
                  </div>
                </div>

                {/* Right: Actions */}
                <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2 shrink-0">
                  {req.status === 'pending' && (
                    <>
                      <button
                        type="button"
                        onClick={() => handleAccept(req.id)}
                        className="px-4 py-2.5 bg-gradient-to-r from-emerald-600 to-emerald-500 hover:from-emerald-500 hover:to-emerald-400 text-slate-950 font-black text-xs rounded-xl shadow-md shadow-emerald-500/20 transition-all flex items-center justify-center gap-1.5"
                      >
                        <CheckCircle2 className="w-4 h-4" />
                        Accept Verification & Grant Access
                      </button>
                      <button
                        type="button"
                        onClick={() =>
                          setRejectModalReq({
                            id: req.id,
                            studentName: req.studentName,
                            studentRoll: req.studentRoll,
                            seriesTitle: req.seriesTitle,
                            reason: 'UPI transaction reference / UTR not found in bank ledger.',
                          })
                        }
                        className="px-3.5 py-2.5 bg-rose-500/15 hover:bg-rose-500/25 border border-rose-500/40 text-rose-300 font-bold text-xs rounded-xl transition-all flex items-center justify-center gap-1.5"
                      >
                        <XCircle className="w-4 h-4" />
                        Reject
                      </button>
                    </>
                  )}

                  {req.status === 'approved' && (
                    <div className="flex items-center gap-2">
                      <span className="text-[11px] text-emerald-400 font-semibold flex items-center gap-1">
                        <CheckCircle2 className="w-3.5 h-3.5" /> Access Active
                      </span>
                      {onNavigateToStudent && (
                        <button
                          type="button"
                          onClick={() => onNavigateToStudent(req.studentRoll)}
                          className="px-2.5 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold rounded-lg border border-slate-700 transition-colors"
                        >
                          Student Dossier
                        </button>
                      )}
                      <button
                        type="button"
                        onClick={() => {
                          if (confirm(`Revoke access for ${req.studentName}?`)) {
                            rejectVerificationRequest(req.id, 'Access revoked by faculty administrator.');
                          }
                        }}
                        className="px-2.5 py-1.5 bg-rose-500/10 hover:bg-rose-500/20 text-rose-400 text-xs font-semibold rounded-lg border border-rose-500/20 transition-colors"
                        title="Revoke access"
                      >
                        Revoke Access
                      </button>
                    </div>
                  )}

                  {req.status === 'rejected' && (
                    <div className="flex flex-col sm:flex-row items-start sm:items-center gap-2">
                      <div className="text-left text-xs">
                        <p className="text-[11px] text-rose-400 font-semibold">Access Withheld</p>
                        {req.rejectionReason && (
                          <p className="text-[10px] text-slate-400 max-w-[200px] truncate" title={req.rejectionReason}>
                            {req.rejectionReason}
                          </p>
                        )}
                      </div>
                      <button
                        type="button"
                        onClick={() => handleAccept(req.id)}
                        className="px-3 py-1.5 bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-300 border border-emerald-500/40 text-xs font-bold rounded-lg transition-colors flex items-center gap-1"
                      >
                        <RotateCcw className="w-3.5 h-3.5" /> Re-Verify & Accept
                      </button>
                    </div>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Reject Verification Confirmation Modal */}
      {rejectModalReq && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-sm animate-fadeIn">
          <div className="relative w-full max-w-md bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl p-6 text-white">
            <button
              onClick={() => setRejectModalReq(null)}
              className="absolute top-4 right-4 text-slate-400 hover:text-white p-1 rounded-lg hover:bg-slate-800 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 rounded-xl bg-rose-500/20 border border-rose-500/40 flex items-center justify-center text-rose-400 shrink-0">
                <XCircle className="w-6 h-6" />
              </div>
              <div>
                <h3 className="text-lg font-bold text-white">Reject Payment Verification</h3>
                <p className="text-xs text-slate-400">
                  Student: {rejectModalReq.studentName} ({rejectModalReq.studentRoll})
                </p>
              </div>
            </div>

            <p className="text-xs text-slate-300 mb-3 leading-relaxed">
              Without faculty verification acceptance, access to <strong>{rejectModalReq.seriesTitle}</strong> will remain locked.
            </p>

            <div className="space-y-2 mb-4">
              {[
                'UPI transaction reference / UTR not found in bank ledger.',
                'Incorrect amount transferred (payment does not match price).',
                'Duplicate or expired UTR reference submitted.',
                'Student roll number / name mismatch with payment remark.',
              ].map((preset) => (
                <button
                  key={preset}
                  type="button"
                  onClick={() =>
                    setRejectModalReq({ ...rejectModalReq, reason: preset })
                  }
                  className={`w-full text-left p-2.5 rounded-lg text-xs border transition-colors ${
                    rejectModalReq.reason === preset
                      ? 'bg-rose-500/20 border-rose-500/50 text-rose-200 font-semibold'
                      : 'bg-slate-800/60 border-slate-700/60 text-slate-300 hover:bg-slate-800'
                  }`}
                >
                  {preset}
                </button>
              ))}
            </div>

            <div className="mb-5">
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                Custom Rejection Reason / Note to Candidate:
              </label>
              <textarea
                value={rejectModalReq.reason}
                onChange={(e) =>
                  setRejectModalReq({ ...rejectModalReq, reason: e.target.value })
                }
                rows={2}
                className="w-full p-2.5 bg-slate-800 border border-slate-700 rounded-lg text-xs text-white placeholder:text-slate-500 focus:outline-none focus:border-rose-500"
                placeholder="Explain why the payment could not be verified..."
              />
            </div>

            <div className="flex gap-3">
              <button
                type="button"
                onClick={() => setRejectModalReq(null)}
                className="flex-1 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-bold rounded-lg transition-colors"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleConfirmReject}
                className="flex-1 py-2 bg-rose-600 hover:bg-rose-500 text-white text-xs font-bold rounded-lg transition-colors shadow-md shadow-rose-600/30 flex items-center justify-center gap-1.5"
              >
                <XCircle className="w-4 h-4" />
                Confirm Rejection
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
