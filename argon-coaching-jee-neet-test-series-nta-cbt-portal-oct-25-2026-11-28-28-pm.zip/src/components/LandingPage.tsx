import React from 'react';
import { useApp } from '../context/AppContext.tsx';
import { ArgonLogo } from './ArgonLogo.tsx';
import {
  ShieldCheck,
  GraduationCap,
  CheckCircle2,
  BarChart3,
  QrCode,
  FileSpreadsheet,
  Clock,
  ArrowRight,
  BookOpen,
  MapPin,
  Phone,
  Globe,
  Sparkles,
  Trophy,
  Users,
  Award,
  Download,
  Calendar,
  Zap,
} from 'lucide-react';

interface LandingPageProps {
  onOpenAuth: (defaultTab: 'faculty' | 'student') => void;
}

export const LandingPage: React.FC<LandingPageProps> = ({ onOpenAuth }) => {
  const { testSeries, role, setCurrentView, startExam } = useApp();

  return (
    <div className="bg-slate-950 text-slate-100">
      {/* Hero Section */}
      <section className="relative overflow-hidden pt-12 pb-20 border-b border-slate-800 bg-gradient-to-b from-slate-900 via-slate-950 to-slate-950">
        {/* Glow ambient background elements */}
        <div className="absolute top-10 left-1/2 -translate-x-1/2 w-96 h-96 bg-amber-500/10 rounded-full blur-3xl pointer-events-none"></div>
        <div className="absolute top-40 right-10 w-80 h-80 bg-indigo-500/10 rounded-full blur-3xl pointer-events-none"></div>

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="text-center max-w-4xl mx-auto">
            {/* Authentic Argon Logo */}
            <div className="flex justify-center mb-6">
              <ArgonLogo size="xl" theme="dark" showText={false} />
            </div>

            <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-slate-900/90 border border-slate-700/80 text-slate-300 text-xs font-semibold mb-5 shadow-inner">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
              <span>Premier JEE (Main & Advanced) & NEET Institute • Guwahati, Assam</span>
            </div>

            <h1 className="text-3xl sm:text-5xl lg:text-6xl font-black tracking-tight text-white leading-tight uppercase mb-4">
              ARGON COACHING ACADEMY
            </h1>

            <p className="text-base sm:text-lg text-slate-300 leading-relaxed font-normal max-w-2xl mx-auto">
              Empowering students of Assam & North East to secure Top All India Ranks in JEE & NEET.
              Experience high-impact classroom coaching alongside our authentic National Testing Agency (NTA)
              Computer-Based Test (CBT) examination simulator.
            </p>

            {/* Quick Action Navigation CTAs */}
            <div className="mt-8 flex flex-wrap items-center justify-center gap-3">
              <button
                onClick={() => setCurrentView('courses')}
                className="px-6 py-3 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-sm shadow-lg shadow-amber-500/20 transition-all flex items-center gap-2"
              >
                <BookOpen className="w-4 h-4" />
                <span>Explore Classroom Batches</span>
              </button>

              <button
                onClick={() => setCurrentView('test-series')}
                className="px-6 py-3 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-sm shadow-lg shadow-indigo-600/20 transition-all flex items-center gap-2"
              >
                <Sparkles className="w-4 h-4 text-amber-300" />
                <span>CBT Test Series Portal</span>
              </button>

              <button
                onClick={() => setCurrentView('admissions')}
                className="px-5 py-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 font-semibold text-sm transition-all flex items-center gap-2"
              >
                <Calendar className="w-4 h-4 text-emerald-400" />
                <span>ASCAT Scholarship Test</span>
              </button>
            </div>

            {/* Quick Portal Switcher Cards */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-5 mt-12 max-w-3xl mx-auto text-left">
              {/* Student Portal Card */}
              <div
                onClick={() => {
                  if (role === 'student') setCurrentView('student-dashboard');
                  else onOpenAuth('student');
                }}
                className="group relative p-6 rounded-2xl bg-slate-900/90 border border-slate-800 hover:border-indigo-500 shadow-xl cursor-pointer transition-all hover:scale-[1.01]"
              >
                <div className="flex items-center justify-between mb-4">
                  <div className="w-12 h-12 rounded-xl bg-indigo-600/20 border border-indigo-500/30 flex items-center justify-center text-indigo-400 group-hover:bg-indigo-600 group-hover:text-white transition-all">
                    <GraduationCap className="w-6 h-6" />
                  </div>
                  <span className="text-xs font-bold text-indigo-400 uppercase tracking-wider flex items-center gap-1 group-hover:translate-x-1 transition-transform">
                    Enter Portal <ArrowRight className="w-3.5 h-3.5" />
                  </span>
                </div>
                <h3 className="text-lg font-bold text-white group-hover:text-indigo-300 transition-colors">
                  Student Examination Console
                </h3>
                <p className="text-xs text-slate-400 mt-2 leading-relaxed">
                  Practice tests in authentic NTA computer-based exam format with countdown timer, 5-state question palette, and instant scorecard analytics.
                </p>
                <div className="mt-4 flex items-center gap-2 text-xs text-indigo-300 font-medium">
                  <span className="w-2 h-2 rounded-full bg-emerald-400"></span>
                  Candidate Examination Console
                </div>
              </div>

              {/* Faculty Portal Card */}
              <div
                onClick={() => {
                  if (role === 'faculty') setCurrentView('faculty-dashboard');
                  else onOpenAuth('faculty');
                }}
                className="group relative p-6 rounded-2xl bg-slate-900/90 border border-slate-800 hover:border-amber-500 shadow-xl cursor-pointer transition-all hover:scale-[1.01]"
              >
                <div className="flex items-center justify-between mb-4">
                  <div className="w-12 h-12 rounded-xl bg-amber-500/20 border border-amber-500/30 flex items-center justify-center text-amber-400 group-hover:bg-amber-500 group-hover:text-slate-950 transition-all">
                    <ShieldCheck className="w-6 h-6" />
                  </div>
                  <span className="text-xs font-bold text-amber-400 uppercase tracking-wider flex items-center gap-1 group-hover:translate-x-1 transition-transform">
                    Faculty Access <ArrowRight className="w-3.5 h-3.5" />
                  </span>
                </div>
                <h3 className="text-lg font-bold text-white group-hover:text-amber-300 transition-colors">
                  Faculty Management Console
                </h3>
                <p className="text-xs text-slate-400 mt-2 leading-relaxed">
                  Automated test scheduling with start/end times, custom subject sequencing, paper lock controls, UPI payment verification, and real-time push.
                </p>
                <div className="mt-4 flex items-center gap-2 text-xs text-amber-300 font-medium">
                  <span className="w-2 h-2 rounded-full bg-amber-400"></span>
                  Faculty & Admin Control Panel
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Key Stats Bar */}
      <section className="py-8 bg-slate-900/60 border-b border-slate-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 text-center">
            <div>
              <p className="text-3xl font-black text-amber-400">AIR 142</p>
              <p className="text-xs text-slate-400 mt-1 uppercase tracking-wider font-semibold">
                JEE Advanced Top Rank
              </p>
            </div>
            <div>
              <p className="text-3xl font-black text-indigo-400">705/720</p>
              <p className="text-xs text-slate-400 mt-1 uppercase tracking-wider font-semibold">
                NEET Top Score (AIR 310)
              </p>
            </div>
            <div>
              <p className="text-3xl font-black text-emerald-400">100%</p>
              <p className="text-xs text-slate-400 mt-1 uppercase tracking-wider font-semibold">
                ASCAT Scholarship Up To
              </p>
            </div>
            <div>
              <p className="text-3xl font-black text-white">18+ Years</p>
              <p className="text-xs text-slate-400 mt-1 uppercase tracking-wider font-semibold">
                Ex-Kota & IIT Faculty
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Classroom Batches Preview */}
      <section className="py-16 border-b border-slate-800/80 bg-slate-950">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row md:items-end justify-between mb-10">
            <div>
              <span className="text-xs font-bold text-amber-400 uppercase tracking-widest">
                Academic Programs 2026-27
              </span>
              <h2 className="text-3xl font-extrabold text-white mt-1">
                Targeted Classroom Batches at Guwahati Center
              </h2>
              <p className="text-sm text-slate-400 mt-1">
                Small batch sizes (max 40 students) with daily doubt-clearing and individual faculty mentorship
              </p>
            </div>

            <button
              onClick={() => {
                setCurrentView('courses');
                window.scrollTo({ top: 0, behavior: 'smooth' });
              }}
              className="mt-4 md:mt-0 inline-flex items-center gap-2 text-sm font-bold text-amber-400 hover:text-amber-300 transition-colors"
            >
              View All 6 Batches & Fees <ArrowRight className="w-4 h-4" />
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {/* Course 1 */}
            <div className="p-6 rounded-2xl bg-slate-900 border border-slate-800 hover:border-amber-500/50 transition-all flex flex-col justify-between shadow-lg">
              <div>
                <span className="text-[10px] font-bold px-2.5 py-0.5 rounded-full bg-indigo-500/15 text-indigo-300 border border-indigo-500/30 uppercase tracking-wider">
                  JEE Main & Adv
                </span>
                <h3 className="text-lg font-bold text-white mt-3">
                  PINNACLE: 2-Year Program
                </h3>
                <p className="text-xs text-slate-400 mt-1.5">For Class 11 moving to Class 12</p>
                <p className="text-xs text-slate-300 mt-3 leading-relaxed">
                  Comprehensive 2-year classroom preparation integrating board exams with deep conceptual JEE Advanced rigor.
                </p>
                <div className="mt-4 space-y-1.5 text-xs text-slate-300">
                  <div className="flex items-center gap-2 text-[11px]">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                    <span>16-18 Classroom Hours/Week</span>
                  </div>
                  <div className="flex items-center gap-2 text-[11px]">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                    <span>Fortnightly NTA CBT Mock Exams</span>
                  </div>
                </div>
              </div>
              <button
                onClick={() => {
                  setCurrentView('courses');
                  window.scrollTo({ top: 0, behavior: 'smooth' });
                }}
                className="mt-6 w-full py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs font-bold text-amber-400 transition-colors flex items-center justify-center gap-1.5"
              >
                <span>Syllabus & Details</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>

            {/* Course 2 */}
            <div className="p-6 rounded-2xl bg-slate-900 border border-slate-800 hover:border-emerald-500/50 transition-all flex flex-col justify-between shadow-lg">
              <div>
                <span className="text-[10px] font-bold px-2.5 py-0.5 rounded-full bg-emerald-500/15 text-emerald-300 border border-emerald-500/30 uppercase tracking-wider">
                  NEET-UG
                </span>
                <h3 className="text-lg font-bold text-white mt-3">
                  PULSE: 2-Year Medical Program
                </h3>
                <p className="text-xs text-slate-400 mt-1.5">For Medical Aspirants (Class 11)</p>
                <p className="text-xs text-slate-300 mt-3 leading-relaxed">
                  Line-by-line NCERT mastery with AIIMS alumni faculty guidance, diagram-based tests, and high-frequency question drilling.
                </p>
                <div className="mt-4 space-y-1.5 text-xs text-slate-300">
                  <div className="flex items-center gap-2 text-[11px]">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                    <span>360/360 Biology Target Curriculum</span>
                  </div>
                  <div className="flex items-center gap-2 text-[11px]">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                    <span>Daily Practice Problems (DPP)</span>
                  </div>
                </div>
              </div>
              <button
                onClick={() => {
                  setCurrentView('courses');
                  window.scrollTo({ top: 0, behavior: 'smooth' });
                }}
                className="mt-6 w-full py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs font-bold text-emerald-400 transition-colors flex items-center justify-center gap-1.5"
              >
                <span>Syllabus & Details</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>

            {/* Course 3 */}
            <div className="p-6 rounded-2xl bg-slate-900 border border-slate-800 hover:border-amber-500/50 transition-all flex flex-col justify-between shadow-lg">
              <div>
                <span className="text-[10px] font-bold px-2.5 py-0.5 rounded-full bg-amber-500/15 text-amber-300 border border-amber-500/30 uppercase tracking-wider">
                  Droppers / Repeaters
                </span>
                <h3 className="text-lg font-bold text-white mt-3">
                  CONQUEROR: 1-Year Repeater Batch
                </h3>
                <p className="text-xs text-slate-400 mt-1.5">Exclusively for 12th Pass Students</p>
                <p className="text-xs text-slate-300 mt-3 leading-relaxed">
                  High-intensity daily 6-hour rigorous problem solving, rank booster assignments, and weekly full-syllabus mock tests.
                </p>
                <div className="mt-4 space-y-1.5 text-xs text-slate-300">
                  <div className="flex items-center gap-2 text-[11px]">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                    <span>Full 11th & 12th Rapid Re-architecture</span>
                  </div>
                  <div className="flex items-center gap-2 text-[11px]">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                    <span>All-India Rank Benchmarking</span>
                  </div>
                </div>
              </div>
              <button
                onClick={() => {
                  setCurrentView('courses');
                  window.scrollTo({ top: 0, behavior: 'smooth' });
                }}
                className="mt-6 w-full py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs font-bold text-amber-400 transition-colors flex items-center justify-center gap-1.5"
              >
                <span>Syllabus & Details</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* Featured Test Series Catalog */}
      <section className="py-16 bg-slate-900/50 border-b border-slate-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row md:items-end justify-between mb-10">
            <div>
              <span className="text-xs font-bold text-indigo-400 uppercase tracking-widest">
                Computer Based Test Series
              </span>
              <h2 className="text-3xl font-extrabold text-white mt-1">
                Authentic NTA CBT Mock Test Engine
              </h2>
              <p className="text-sm text-slate-400 mt-1">
                Practice in the exact NTA interface with 180-minute timer, 5-state color coded palette, and instant error report
              </p>
            </div>

            <button
              onClick={() => {
                setCurrentView('test-series');
                window.scrollTo({ top: 0, behavior: 'smooth' });
              }}
              className="mt-4 md:mt-0 inline-flex items-center gap-2 text-sm font-bold text-amber-400 hover:text-amber-300 transition-colors"
            >
              Browse All Series & Free Mocks <ArrowRight className="w-4 h-4" />
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {testSeries.map((series) => (
              <div
                key={series.id}
                className="bg-slate-900 border border-slate-800 rounded-2xl p-5 hover:border-slate-700 transition-all flex flex-col justify-between group shadow-lg"
              >
                <div>
                  <div className="flex items-center justify-between mb-3">
                    <span
                      className={`text-[10px] font-bold px-2.5 py-0.5 rounded-full uppercase tracking-wider ${
                        series.targetExam === 'NEET'
                          ? 'bg-emerald-500/15 text-emerald-300 border border-emerald-500/30'
                          : series.targetExam === 'JEE Advanced'
                          ? 'bg-amber-500/15 text-amber-300 border border-amber-500/30'
                          : 'bg-indigo-500/15 text-indigo-300 border border-indigo-500/30'
                      }`}
                    >
                      {series.targetExam}
                    </span>

                    {series.badge && (
                      <span className="text-[10px] font-semibold text-rose-300 bg-rose-500/10 px-2 py-0.5 rounded border border-rose-500/20">
                        {series.badge}
                      </span>
                    )}
                  </div>

                  <h3 className="font-bold text-base text-white group-hover:text-amber-300 transition-colors line-clamp-2">
                    {series.title}
                  </h3>
                  <p className="text-xs text-slate-400 mt-2 line-clamp-3 leading-relaxed">
                    {series.description}
                  </p>

                  <div className="mt-4 pt-3 border-t border-slate-800/80 space-y-1.5 text-xs text-slate-300">
                    {series.features.slice(0, 3).map((feat, idx) => (
                      <div key={idx} className="flex items-center gap-2 text-[11px]">
                        <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                        <span className="truncate">{feat}</span>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="mt-6 pt-4 border-t border-slate-800 flex items-center justify-between">
                  <div>
                    <div className="flex items-baseline gap-1.5">
                      <span className="text-lg font-black text-white">
                        {series.price === 0 ? 'FREE' : `₹ ${series.price}`}
                      </span>
                      {series.originalPrice && (
                        <span className="text-xs text-slate-500 line-through">
                          ₹ {series.originalPrice}
                        </span>
                      )}
                    </div>
                    <span className="text-[10px] text-slate-400">
                      {series.testsCount || 1} Tests Available
                    </span>
                  </div>

                  <button
                    onClick={() => {
                      if (role === 'student') setCurrentView('student-dashboard');
                      else onOpenAuth('student');
                    }}
                    className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
                      series.price === 0
                        ? 'bg-emerald-600 hover:bg-emerald-500 text-white'
                        : 'bg-indigo-600 hover:bg-indigo-500 text-white'
                    }`}
                  >
                    {series.price === 0 ? 'Access Free' : 'Unlock Series'}
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Hall of Fame Teaser */}
      <section className="py-16 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 border-b border-slate-800/80">
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-10">
          <div>
            <span className="text-xs font-bold text-amber-400 uppercase tracking-widest">
              Hall of Fame
            </span>
            <h2 className="text-3xl font-extrabold text-white mt-1">
              Argon's Top Rankers in JEE & NEET
            </h2>
            <p className="text-sm text-slate-400 mt-1">
              Consistent top selections from Guwahati into IIT Bombay, IIT Kharagpur, AIIMS Delhi, and GMC Guwahati
            </p>
          </div>

          <button
            onClick={() => {
              setCurrentView('results');
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
            className="mt-4 md:mt-0 inline-flex items-center gap-2 text-sm font-bold text-amber-400 hover:text-amber-300 transition-colors"
          >
            View All Selections & Testimonials <ArrowRight className="w-4 h-4" />
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="p-6 rounded-2xl bg-gradient-to-b from-slate-900 to-slate-900/70 border border-amber-500/30 flex items-center gap-4">
            <div className="w-14 h-14 rounded-2xl bg-amber-500/20 border border-amber-500/40 text-amber-300 flex items-center justify-center text-xl font-black">
              142
            </div>
            <div>
              <p className="text-sm font-bold text-white">Rohan Talukdar</p>
              <p className="text-xs text-amber-400 font-semibold">AIR 142 • JEE Advanced</p>
              <p className="text-[11px] text-slate-400 mt-1">IIT Bombay (Computer Science)</p>
            </div>
          </div>

          <div className="p-6 rounded-2xl bg-gradient-to-b from-slate-900 to-slate-900/70 border border-emerald-500/30 flex items-center gap-4">
            <div className="w-14 h-14 rounded-2xl bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 flex items-center justify-center text-xl font-black">
              310
            </div>
            <div>
              <p className="text-sm font-bold text-white">Ananya Sarma</p>
              <p className="text-xs text-emerald-400 font-semibold">AIR 310 (705/720) • NEET</p>
              <p className="text-[11px] text-slate-400 mt-1">AIIMS New Delhi</p>
            </div>
          </div>

          <div className="p-6 rounded-2xl bg-gradient-to-b from-slate-900 to-slate-900/70 border border-indigo-500/30 flex items-center gap-4">
            <div className="w-14 h-14 rounded-2xl bg-indigo-500/20 border border-indigo-500/40 text-indigo-300 flex items-center justify-center text-xl font-black">
              289
            </div>
            <div>
              <p className="text-sm font-bold text-white">Bedabrata Deka</p>
              <p className="text-xs text-indigo-400 font-semibold">AIR 289 (99.91%ile) • JEE Main</p>
              <p className="text-[11px] text-slate-400 mt-1">IIT Kharagpur (Electrical)</p>
            </div>
          </div>
        </div>
      </section>

      {/* Free Study Material Teaser */}
      <section className="py-16 bg-slate-900/40 border-b border-slate-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="p-8 rounded-3xl bg-gradient-to-r from-indigo-950/60 via-slate-900 to-amber-950/40 border border-indigo-900/50 flex flex-col lg:flex-row items-center justify-between gap-8">
            <div className="space-y-3 max-w-2xl">
              <span className="text-[10px] font-bold px-3 py-1 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 uppercase tracking-widest">
                100% Free Open Access
              </span>
              <h3 className="text-2xl sm:text-3xl font-black text-white">
                Download Free Formula Handbooks & NCERT Mindmaps
              </h3>
              <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
                Authored by Argon senior faculty: high-yield quick revision sheets for Physics mechanics & electrodynamics,
                Organic Chemistry reaction roadmaps, and past 5 years official NTA PYQs with complete step-by-step solutions.
              </p>
            </div>

            <button
              onClick={() => {
                setCurrentView('free-resources');
                window.scrollTo({ top: 0, behavior: 'smooth' });
              }}
              className="px-6 py-3.5 rounded-2xl bg-gradient-to-r from-amber-400 to-amber-500 hover:from-amber-300 hover:to-amber-400 text-slate-950 font-bold text-sm shadow-xl shadow-amber-500/20 transition-all flex items-center gap-2 shrink-0"
            >
              <Download className="w-4 h-4" />
              <span>Access Free Material</span>
            </button>
          </div>
        </div>
      </section>

      {/* Official Institute Details & Campus Location */}
      <section className="py-16 bg-slate-950">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="bg-slate-900/90 border border-slate-800 rounded-3xl p-6 sm:p-10 flex flex-col lg:flex-row items-start lg:items-center justify-between gap-8">
            <div className="space-y-4 max-w-xl">
              <ArgonLogo size="md" theme="dark" showText={true} />
              <div className="space-y-2 text-xs text-slate-300">
                <div className="flex items-start gap-2.5">
                  <MapPin className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
                  <p className="leading-relaxed">
                    <strong className="text-white block font-semibold">Institute Address:</strong>
                    HouseNo. 1A, Chinaki path, GS Rd, Rukmini Gaon, Guwahati, Assam 781006
                  </p>
                </div>
                <div className="flex items-center gap-2.5 text-slate-400">
                  <Clock className="w-4 h-4 text-amber-400 shrink-0" />
                  <span>Campus Visiting Hours: Mon - Sat: 8:00 AM - 7:30 PM | Sun: 9:00 AM - 2:00 PM</span>
                </div>
              </div>
            </div>

            <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-4 w-full lg:w-auto">
              {/* Phone card */}
              <a
                href="tel:06000730250"
                className="px-5 py-3.5 rounded-2xl bg-slate-950 border border-slate-800 hover:border-amber-500/50 text-xs transition-colors group flex items-center gap-3"
              >
                <div className="w-10 h-10 rounded-xl bg-amber-500/10 border border-amber-500/20 text-amber-400 flex items-center justify-center shrink-0 group-hover:bg-amber-500 group-hover:text-slate-950 transition-colors">
                  <Phone className="w-5 h-5" />
                </div>
                <div>
                  <p className="text-[10px] text-slate-400 uppercase font-bold tracking-wider">Admissions Helpline</p>
                  <p className="text-sm font-bold text-white font-mono group-hover:text-amber-300">060007 30250</p>
                </div>
              </a>

              {/* Website card */}
              <a
                href="https://www.argoncoaching.com"
                target="_blank"
                rel="noreferrer"
                className="px-5 py-3.5 rounded-2xl bg-slate-950 border border-slate-800 hover:border-indigo-500/50 text-xs transition-colors group flex items-center gap-3"
              >
                <div className="w-10 h-10 rounded-xl bg-indigo-500/10 border border-indigo-500/20 text-indigo-400 flex items-center justify-center shrink-0 group-hover:bg-indigo-600 group-hover:text-white transition-colors">
                  <Globe className="w-5 h-5" />
                </div>
                <div>
                  <p className="text-[10px] text-slate-400 uppercase font-bold tracking-wider">Official Portal</p>
                  <p className="text-sm font-bold text-white group-hover:text-indigo-300">www.argoncoaching.com</p>
                </div>
              </a>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};
