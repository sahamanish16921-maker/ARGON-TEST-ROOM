import React, { useState } from 'react';
import { useApp } from '../context/AppContext.tsx';
import { ArgonLogo } from './ArgonLogo.tsx';
import {
  GraduationCap,
  ShieldCheck,
  UserCheck,
  LogOut,
  Sparkles,
  RotateCcw,
  BookOpen,
  Award,
  Phone,
  Globe,
  MapPin,
  Menu,
  X,
  FileText,
  Users,
  Trophy,
  Calendar,
} from 'lucide-react';
import { WebsiteView } from '../types/index.ts';

interface NavbarProps {
  onOpenAuth: (defaultTab?: 'faculty' | 'student') => void;
}

export const Navbar: React.FC<NavbarProps> = ({ onOpenAuth }) => {
  const {
    currentUser,
    role,
    currentView,
    setCurrentView,
    logout,
    resetAllDataToDefault,
    connectionStatus,
    lastSyncTime,
    refreshFromServer,
  } = useApp();

  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const navLinks: { label: string; view: WebsiteView; icon: React.ReactNode }[] = [
    { label: 'Home', view: 'home', icon: null },
    { label: 'Courses & Batches', view: 'courses', icon: <BookOpen className="w-3.5 h-3.5" /> },
    { label: 'Test Series (CBT)', view: 'test-series', icon: <Sparkles className="w-3.5 h-3.5 text-amber-400" /> },
    { label: 'Faculty Mentors', view: 'faculty-mentors', icon: <Users className="w-3.5 h-3.5" /> },
    { label: 'Results', view: 'results', icon: <Trophy className="w-3.5 h-3.5 text-amber-400" /> },
    { label: 'Free Material', view: 'free-resources', icon: <FileText className="w-3.5 h-3.5" /> },
    { label: 'Admissions & Center', view: 'admissions', icon: <Calendar className="w-3.5 h-3.5 text-emerald-400" /> },
  ];

  const handleNavigate = (view: WebsiteView) => {
    setCurrentView(view);
    setMobileMenuOpen(false);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <header className="sticky top-0 z-40 bg-slate-900 border-b border-slate-800 text-white shadow-xl">
      {/* Top Helpline & Campus Bar */}
      <div className="bg-slate-950 border-b border-slate-800/80 text-[11px] text-slate-300 py-1.5 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <span className="inline-flex items-center gap-1 text-amber-400 font-semibold">
              <span className="w-2 h-2 rounded-full bg-amber-400 animate-pulse"></span>
              Admissions Open 2026-27:
            </span>
            <span className="hidden sm:inline text-slate-300">
              JEE Main, Advanced, NEET-UG & Foundation Batches
            </span>
            <span className="hidden md:inline text-slate-500">•</span>
            <span className="hidden md:inline text-emerald-400 font-medium">
              Up to 100% ASCAT Scholarship
            </span>
          </div>

          <div className="flex items-center gap-4 text-slate-400">
            <div className="hidden lg:flex items-center gap-1.5 text-slate-400">
              <MapPin className="w-3 h-3 text-rose-400" />
              <span>Rukmini Gaon, GS Road, Guwahati</span>
            </div>

            <a
              href="tel:06000730250"
              className="hover:text-amber-300 text-amber-400 font-bold flex items-center gap-1 transition-colors"
              title="Call Argon Admissions Helpline"
            >
              <Phone className="w-3 h-3 text-amber-400" />
              <span>Helpline: 060007 30250</span>
            </a>

            <a
              href="https://www.argoncoaching.com"
              target="_blank"
              rel="noreferrer"
              className="hidden sm:flex hover:text-indigo-300 text-indigo-400 font-medium items-center gap-1 transition-colors"
              title="Official Website"
            >
              <Globe className="w-3 h-3" />
              <span>argoncoaching.com</span>
            </a>
          </div>
        </div>
      </div>

      {/* Main Navbar */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo & Institute Branding */}
          <div
            onClick={() => handleNavigate('home')}
            className="flex items-center gap-3 cursor-pointer select-none shrink-0"
          >
            <ArgonLogo size="md" theme="dark" showText={true} />
            <div className="hidden xl:block border-l border-slate-800 pl-3">
              <span className="text-[10px] text-amber-400 font-bold tracking-wider uppercase block">
                Guwahati Center
              </span>
              <span className="text-[10px] text-slate-400">
                JEE & NEET Excellence
              </span>
            </div>
          </div>

          {/* Navigation Links for Desktop */}
          <nav className="hidden xl:flex items-center gap-1 text-xs font-semibold">
            {navLinks.map((link) => {
              const isActive = currentView === link.view;
              return (
                <button
                  key={link.view}
                  onClick={() => handleNavigate(link.view)}
                  className={`px-2.5 py-1.5 rounded-lg transition-colors flex items-center gap-1.5 ${
                    isActive
                      ? 'bg-slate-800 text-amber-400 border border-slate-700/60 shadow-sm'
                      : 'text-slate-300 hover:text-white hover:bg-slate-800/60'
                  }`}
                >
                  {link.icon}
                  <span>{link.label}</span>
                </button>
              );
            })}
          </nav>

          {/* Compact Nav for Medium screens */}
          <nav className="hidden md:flex xl:hidden items-center gap-1 text-xs font-semibold">
            <button
              onClick={() => handleNavigate('home')}
              className={`px-2 py-1.5 rounded-lg ${currentView === 'home' ? 'bg-slate-800 text-amber-400' : 'text-slate-300'}`}
            >
              Home
            </button>
            <button
              onClick={() => handleNavigate('courses')}
              className={`px-2 py-1.5 rounded-lg ${currentView === 'courses' ? 'bg-slate-800 text-amber-400' : 'text-slate-300'}`}
            >
              Courses
            </button>
            <button
              onClick={() => handleNavigate('test-series')}
              className={`px-2 py-1.5 rounded-lg ${currentView === 'test-series' ? 'bg-slate-800 text-amber-400' : 'text-slate-300'}`}
            >
              CBT Tests
            </button>
            <button
              onClick={() => handleNavigate('faculty-mentors')}
              className={`px-2 py-1.5 rounded-lg ${currentView === 'faculty-mentors' ? 'bg-slate-800 text-amber-400' : 'text-slate-300'}`}
            >
              Faculty
            </button>
            <button
              onClick={() => handleNavigate('results')}
              className={`px-2 py-1.5 rounded-lg ${currentView === 'results' ? 'bg-slate-800 text-amber-400' : 'text-slate-300'}`}
            >
              Results
            </button>
            <button
              onClick={() => handleNavigate('admissions')}
              className={`px-2 py-1.5 rounded-lg ${currentView === 'admissions' ? 'bg-slate-800 text-amber-400' : 'text-slate-300'}`}
            >
              Admissions
            </button>
          </nav>

          {/* Right Action Area */}
          <div className="flex items-center gap-2 sm:gap-3">
            {/* Real-time Push Stream Indicator */}
            {connectionStatus === 'connected' ? (
              <div
                title={`Connected to Centralized Cloud Database & Real-Time Push Stream. Last synchronized: ${lastSyncTime}`}
                className="hidden 2xl:flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/25 text-[11px] text-emerald-400 font-medium select-none shadow-sm shadow-emerald-500/5"
              >
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
                <span>Live Sync</span>
              </div>
            ) : connectionStatus === 'connecting' ? (
              <div
                title="Reconnecting to real-time event stream..."
                className="hidden 2xl:flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-amber-500/10 border border-amber-500/25 text-[11px] text-amber-300 font-medium select-none"
              >
                <span className="w-2 h-2 rounded-full bg-amber-400 animate-ping"></span>
                <span>Syncing...</span>
              </div>
            ) : (
              <button
                type="button"
                onClick={refreshFromServer}
                title="Device is currently offline. Click to fetch latest state immediately."
                className="hidden 2xl:flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-rose-500/15 border border-rose-500/30 text-[11px] text-rose-300 hover:bg-rose-500/25 transition-colors font-medium select-none"
              >
                <span className="w-2 h-2 rounded-full bg-rose-400"></span>
                <span>Offline (Sync)</span>
              </button>
            )}

            {/* Quick Demo Switcher when not logged in */}
            {!currentUser ? (
              <div className="flex items-center gap-1.5 sm:gap-2">
                <button
                  onClick={() => onOpenAuth('student')}
                  className="px-2.5 sm:px-3 py-1.5 text-xs font-semibold text-slate-200 bg-slate-800 hover:bg-slate-700 border border-slate-700 rounded-lg transition-all flex items-center gap-1.5"
                >
                  <GraduationCap className="w-3.5 h-3.5 text-indigo-400" />
                  <span className="hidden sm:inline">Student CBT</span>
                  <span className="sm:hidden">Student</span>
                </button>
                <button
                  onClick={() => onOpenAuth('faculty')}
                  className="px-2.5 sm:px-3.5 py-1.5 text-xs font-semibold text-slate-900 bg-gradient-to-r from-amber-400 to-amber-500 hover:from-amber-300 hover:to-amber-400 rounded-lg shadow-sm shadow-amber-500/20 transition-all flex items-center gap-1.5"
                >
                  <ShieldCheck className="w-3.5 h-3.5" />
                  <span className="hidden sm:inline">Faculty Login</span>
                  <span className="sm:hidden">Faculty</span>
                </button>
              </div>
            ) : (
              <div className="flex items-center gap-2">
                {/* Role Badge */}
                <div className="flex items-center gap-2 bg-slate-800/90 border border-slate-700 rounded-xl px-2.5 py-1">
                  <div className="w-6 h-6 rounded-full overflow-hidden bg-slate-700 flex items-center justify-center border border-slate-600">
                    {currentUser.avatar ? (
                      <img
                        src={currentUser.avatar}
                        alt={currentUser.name}
                        className="w-full h-full object-cover"
                      />
                    ) : (
                      <UserCheck className="w-3.5 h-3.5 text-amber-400" />
                    )}
                  </div>
                  <div className="text-left hidden md:block">
                    <p className="text-xs font-semibold text-slate-200 leading-tight truncate max-w-[100px]">
                      {currentUser.name}
                    </p>
                    <p className="text-[10px] text-amber-400 font-medium">
                      {currentUser.role === 'faculty' ? 'Faculty Admin' : currentUser.targetExam || 'Student'}
                    </p>
                  </div>
                </div>

                {/* Dashboard Shortcut */}
                {role === 'faculty' && currentView !== 'faculty-dashboard' && (
                  <button
                    onClick={() => handleNavigate('faculty-dashboard')}
                    className="px-2.5 py-1 text-xs font-medium bg-amber-500/20 text-amber-300 border border-amber-500/40 rounded-lg hover:bg-amber-500/30 transition-colors"
                  >
                    Faculty Portal
                  </button>
                )}

                {role === 'student' && currentView !== 'student-dashboard' && (
                  <button
                    onClick={() => handleNavigate('student-dashboard')}
                    className="px-2.5 py-1 text-xs font-medium bg-indigo-500/20 text-indigo-300 border border-indigo-500/40 rounded-lg hover:bg-indigo-500/30 transition-colors"
                  >
                    My Tests
                  </button>
                )}

                {/* Logout Button */}
                <button
                  onClick={logout}
                  title="Logout"
                  className="p-1.5 text-slate-400 hover:text-rose-400 hover:bg-slate-800 rounded-lg transition-colors"
                >
                  <LogOut className="w-4 h-4" />
                </button>
              </div>
            )}

            {/* Reset Seed Data Button */}
            <button
              onClick={() => {
                if (window.confirm('Reset all tests, series, and attempts to factory seed data?')) {
                  resetAllDataToDefault();
                }
              }}
              title="Reset Demo Data"
              className="p-1.5 text-slate-500 hover:text-slate-300 hover:bg-slate-800 rounded-lg transition-colors hidden xl:flex"
            >
              <RotateCcw className="w-3.5 h-3.5" />
            </button>

            {/* Mobile Hamburger Button */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2 text-slate-300 hover:text-white hover:bg-slate-800 rounded-lg xl:hidden"
              aria-label="Toggle navigation menu"
            >
              {mobileMenuOpen ? <X className="w-5 h-5 text-amber-400" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Drawer Menu */}
      {mobileMenuOpen && (
        <div className="xl:hidden border-t border-slate-800 bg-slate-900/95 backdrop-blur-md px-4 py-4 space-y-2 animate-fadeIn">
          <div className="grid grid-cols-2 gap-2 pb-3 border-b border-slate-800">
            <button
              onClick={() => {
                setMobileMenuOpen(false);
                if (role === 'student') setCurrentView('student-dashboard');
                else onOpenAuth('student');
              }}
              className="p-2.5 rounded-xl bg-indigo-950/60 border border-indigo-800/60 text-indigo-300 text-xs font-bold flex items-center justify-center gap-2"
            >
              <GraduationCap className="w-4 h-4 text-indigo-400" />
              <span>Student CBT</span>
            </button>
            <button
              onClick={() => {
                setMobileMenuOpen(false);
                if (role === 'faculty') setCurrentView('faculty-dashboard');
                else onOpenAuth('faculty');
              }}
              className="p-2.5 rounded-xl bg-amber-950/60 border border-amber-800/60 text-amber-300 text-xs font-bold flex items-center justify-center gap-2"
            >
              <ShieldCheck className="w-4 h-4 text-amber-400" />
              <span>Faculty Portal</span>
            </button>
          </div>

          <div className="space-y-1">
            {navLinks.map((link) => {
              const isActive = currentView === link.view;
              return (
                <button
                  key={link.view}
                  onClick={() => handleNavigate(link.view)}
                  className={`w-full flex items-center justify-between px-3 py-2.5 rounded-lg text-xs font-semibold transition-colors ${
                    isActive
                      ? 'bg-amber-500/15 text-amber-300 border border-amber-500/30'
                      : 'text-slate-300 hover:bg-slate-800 hover:text-white'
                  }`}
                >
                  <span className="flex items-center gap-2">
                    {link.icon || <Globe className="w-3.5 h-3.5 text-slate-400" />}
                    {link.label}
                  </span>
                  <span className="text-[10px] text-slate-500">→</span>
                </button>
              );
            })}
          </div>

          <div className="pt-3 border-t border-slate-800 text-[11px] text-slate-400 space-y-1.5">
            <div className="flex items-center gap-2 text-slate-300">
              <Phone className="w-3.5 h-3.5 text-amber-400" />
              <a href="tel:06000730250" className="hover:text-amber-400 font-bold">
                Call Admissions: 060007 30250
              </a>
            </div>
            <div className="flex items-center gap-2 text-slate-400">
              <MapPin className="w-3.5 h-3.5 text-rose-400" />
              <span>HouseNo. 1A, Chinaki path, GS Rd, Rukmini Gaon, Guwahati</span>
            </div>
          </div>
        </div>
      )}
    </header>
  );
};
