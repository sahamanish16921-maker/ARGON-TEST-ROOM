import React, { useState, useEffect, useRef } from 'react';
import { useApp } from '../context/AppContext.tsx';
import type {
  Test,
  Question,
  QuestionState,
  QuestionResponse,
  SubjectSection,
  OptionKey,
  StudentTestAttempt,
} from '../types/index.ts';
import { evaluateTest, countPaletteStates } from '../utils/examEngine.ts';
import {
  Clock,
  User as UserIcon,
  HelpCircle,
  FileText,
  AlertTriangle,
  ZoomIn,
  X,
  ChevronLeft,
  ChevronRight,
  CheckCircle2,
  Bookmark,
  Check,
  RotateCcw,
  Lock,
  Unlock,
  Radio,
} from 'lucide-react';
import { ArgonLogo } from './ArgonLogo.tsx';

export const NtaExamInterface: React.FC = () => {
  const { tests, activeTestId, currentUser, submitExam, exitExamOrResult } = useApp();

  // Live ticking clock to automatically trigger exam when start time arrives
  const [waitingClock, setWaitingClock] = useState<number>(Date.now());
  useEffect(() => {
    const timer = setInterval(() => setWaitingClock(Date.now()), 1000);
    return () => clearInterval(timer);
  }, []);

  const test: Test | undefined = tests.find((t) => t.id === activeTestId);

  // If no test found, fallback
  if (!test) {
    return (
      <div className="min-h-screen bg-slate-950 text-white flex flex-col items-center justify-center p-4">
        <p className="text-sm text-slate-400 mb-4">No test selected.</p>
        <button
          onClick={exitExamOrResult}
          className="px-4 py-2 bg-indigo-600 rounded-lg text-xs font-bold"
        >
          Return to Dashboard
        </button>
      </div>
    );
  }

  // 1. Lock Check: If test is locked by faculty, block student access until unlocked
  if (test.isLockedByFaculty && currentUser?.role !== 'faculty') {
    return (
      <div className="min-h-screen bg-slate-950 text-white flex flex-col items-center justify-center p-6 text-center">
        <div className="mb-6">
          <ArgonLogo size="lg" theme="dark" />
        </div>
        <div className="w-16 h-16 rounded-2xl bg-rose-500/20 border border-rose-500/40 text-rose-400 flex items-center justify-center mb-4 shadow-xl">
          <Lock className="w-8 h-8" />
        </div>
        <h2 className="text-2xl font-black text-white mb-2">Test Paper Locked by Faculty</h2>
        <p className="text-sm text-slate-300 max-w-md mb-2 leading-relaxed">
          The test paper <strong className="text-white">"{test.title}"</strong> is currently locked by the Faculty Administrator.
        </p>
        <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-slate-900 border border-slate-800 text-xs text-amber-300 mb-6">
          <span className="w-2 h-2 rounded-full bg-amber-400 animate-pulse"></span>
          <span>Awaiting faculty unlock signal • Access will open automatically</span>
        </div>
        <button
          onClick={exitExamOrResult}
          className="px-6 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold rounded-xl text-xs transition-colors"
        >
          Return to Student Dashboard
        </button>
      </div>
    );
  }

  // 2. Schedule Check: If test has an upcoming scheduled start time, block access until start time
  const scheduledStartMs =
    test.isScheduled && test.scheduledStartTime
      ? new Date(test.scheduledStartTime).getTime()
      : 0;
  const isBeforeScheduledStart =
    scheduledStartMs > 0 && waitingClock < scheduledStartMs;

  if (isBeforeScheduledStart && currentUser?.role !== 'faculty') {
    const diffSeconds = Math.max(0, Math.floor((scheduledStartMs - waitingClock) / 1000));
    const hrs = Math.floor(diffSeconds / 3600);
    const mins = Math.floor((diffSeconds % 3600) / 60);
    const secs = diffSeconds % 60;
    const formattedCountdown = `${hrs.toString().padStart(2, '0')}:${mins
      .toString()
      .padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;

    return (
      <div className="min-h-screen bg-slate-950 text-white flex flex-col items-center justify-center p-6 text-center">
        <div className="mb-6">
          <ArgonLogo size="lg" theme="dark" />
        </div>
        <div className="w-16 h-16 rounded-2xl bg-indigo-500/20 border border-indigo-500/40 text-indigo-400 flex items-center justify-center mb-4 shadow-xl">
          <Clock className="w-8 h-8 animate-pulse text-indigo-400" />
        </div>
        <h2 className="text-2xl font-black text-white mb-2">Automated Scheduled Exam</h2>
        <p className="text-sm text-slate-300 max-w-md mb-3">
          This test paper <strong className="text-white">"{test.title}"</strong> is scheduled by faculty to start automatically.
        </p>

        {/* Live Ticking Countdown Box */}
        <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 mb-6 max-w-sm w-full space-y-2">
          <p className="text-xs text-slate-400 uppercase tracking-wider font-semibold">
            Exam Auto-Triggers In
          </p>
          <p className="text-3xl sm:text-4xl font-mono font-black text-amber-400 tracking-wider">
            {formattedCountdown}
          </p>
          <p className="text-[11px] text-emerald-400 flex items-center justify-center gap-1.5 font-medium pt-1">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping"></span>
            Screen will automatically transition into exam when timer hits 00:00:00
          </p>
        </div>

        <button
          onClick={exitExamOrResult}
          className="px-6 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold rounded-xl text-xs transition-colors"
        >
          Return to Student Dashboard
        </button>
      </div>
    );
  }

  // 3. Subject Order Configured by Faculty:
  // Arrange available sections respecting faculty's chosen subjectOrder
  const availableSections: SubjectSection[] = (() => {
    const rawSections = test.sections.length > 0 ? test.sections : (['Physics'] as SubjectSection[]);
    if (test.subjectOrder && test.subjectOrder.length > 0) {
      const inOrder = test.subjectOrder.filter((s) => rawSections.includes(s));
      const remaining = rawSections.filter((s) => !inOrder.includes(s));
      const combined = [...inOrder, ...remaining];
      return combined.length > 0 ? combined : rawSections;
    }
    return rawSections;
  })();

  // First subject in the configured order appears first in the test!
  const [activeSection, setActiveSection] = useState<SubjectSection>(availableSections[0]);

  // Questions in current active section
  const sectionQuestions = test.questions.filter((q) => q.section === activeSection);

  // Active question index within current section
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);

  // Safe active question
  const currentQuestion: Question | undefined =
    sectionQuestions[currentQuestionIndex] || sectionQuestions[0];

  // Candidates responses record: { [qId]: { selectedOption, state, timeSpentSeconds } }
  const [responses, setResponses] = useState<Record<string, QuestionResponse>>(() => {
    const initial: Record<string, QuestionResponse> = {};
    test.questions.forEach((q) => {
      initial[q.id] = {
        selectedOption: undefined,
        state: 'not_visited',
        timeSpentSeconds: 0,
      };
    });
    return initial;
  });

  // Current selected option in working memory for active question
  const [currentOptionChoice, setCurrentOptionChoice] = useState<string>('');

  // Total duration in seconds
  const durationTotalSeconds = Math.max(1, test.durationMinutes * 60);

  // Countdown timer state in seconds
  const [timeLeftSeconds, setTimeLeftSeconds] = useState<number>(durationTotalSeconds);
  const [isAutoSubmitting, setIsAutoSubmitting] = useState<boolean>(false);

  // Absolute end timestamp ref (drift-proof, survives tab throttling and component re-renders)
  const endTimeMsRef = useRef<number>(Date.now() + durationTotalSeconds * 1000);
  const isSubmittingRef = useRef<boolean>(false);
  const timeLeftSecondsRef = useRef<number>(durationTotalSeconds);
  const responsesRef = useRef(responses);
  const currentOptionChoiceRef = useRef(currentOptionChoice);
  const currentQuestionRef = useRef(currentQuestion);

  // Modals
  const [isSubmitModalOpen, setIsSubmitModalOpen] = useState(false);
  const [isQuestionPaperModalOpen, setIsQuestionPaperModalOpen] = useState(false);
  const [isInstructionsModalOpen, setIsInstructionsModalOpen] = useState(false);
  const [zoomedImage, setZoomedImage] = useState<string | null>(null);

  // Keep state refs in sync so auto-submit handler always accesses latest values synchronously
  useEffect(() => {
    responsesRef.current = responses;
  }, [responses]);

  useEffect(() => {
    currentOptionChoiceRef.current = currentOptionChoice;
  }, [currentOptionChoice]);

  useEffect(() => {
    currentQuestionRef.current = currentQuestion;
  }, [currentQuestion]);

  useEffect(() => {
    timeLeftSecondsRef.current = timeLeftSeconds;
  }, [timeLeftSeconds]);

  // Sync working option choice when active question changes
  useEffect(() => {
    if (currentQuestion) {
      const resp = responses[currentQuestion.id];
      setCurrentOptionChoice(resp?.selectedOption || '');

      // Mark as not_answered if it was not_visited
      if (!resp || resp.state === 'not_visited') {
        setResponses((prev) => ({
          ...prev,
          [currentQuestion.id]: {
            selectedOption: undefined,
            state: 'not_answered',
            timeSpentSeconds: prev[currentQuestion.id]?.timeSpentSeconds || 0,
          },
        }));
      }
    }
  }, [currentQuestionIndex, activeSection]);

  // Real-Time Countdown Timer: checks remaining time every 500ms and triggers auto-submission at 0
  useEffect(() => {
    if (isSubmittingRef.current) return;

    const timer = setInterval(() => {
      if (isSubmittingRef.current) {
        clearInterval(timer);
        return;
      }

      const now = Date.now();
      const remainingSeconds = Math.max(0, Math.ceil((endTimeMsRef.current - now) / 1000));
      setTimeLeftSeconds(remainingSeconds);

      // Trigger automatic submission when time reaches zero
      if (remainingSeconds <= 0) {
        clearInterval(timer);
        if (!isSubmittingRef.current) {
          handleFinalSubmit(true);
        }
      }
    }, 500);

    return () => clearInterval(timer);
  }, []);

  // Track time spent on active question (decoupled from countdown timer to prevent interval restarts)
  useEffect(() => {
    if (!currentQuestion) return;

    const qTimer = setInterval(() => {
      if (isSubmittingRef.current) return;
      setResponses((prev) => {
        const current = prev[currentQuestion.id] || {
          selectedOption: undefined,
          state: 'not_answered',
          timeSpentSeconds: 0,
        };
        return {
          ...prev,
          [currentQuestion.id]: {
            ...current,
            timeSpentSeconds: current.timeSpentSeconds + 1,
          },
        };
      });
    }, 1000);

    return () => clearInterval(qTimer);
  }, [currentQuestion?.id]);

  // Format time HH:MM:SS
  const formatTimer = (totalSeconds: number) => {
    const hrs = Math.floor(totalSeconds / 3600);
    const mins = Math.floor((totalSeconds % 3600) / 60);
    const secs = totalSeconds % 60;
    return `${hrs.toString().padStart(2, '0')}:${mins.toString().padStart(2, '0')}:${secs
      .toString()
      .padStart(2, '0')}`;
  };

  // Switch question
  const jumpToQuestion = (qId: string) => {
    const targetQ = test.questions.find((q) => q.id === qId);
    if (!targetQ) return;

    if (targetQ.section !== activeSection) {
      setActiveSection(targetQ.section);
    }
    const idx = test.questions
      .filter((q) => q.section === targetQ.section)
      .findIndex((q) => q.id === qId);
    setCurrentQuestionIndex(idx >= 0 ? idx : 0);
  };

  // Next question handler
  const moveToNextQuestion = () => {
    if (currentQuestionIndex < sectionQuestions.length - 1) {
      setCurrentQuestionIndex((prev) => prev + 1);
    } else {
      // If end of section, jump to next section if available
      const secIdx = availableSections.indexOf(activeSection);
      if (secIdx < availableSections.length - 1) {
        setActiveSection(availableSections[secIdx + 1]);
        setCurrentQuestionIndex(0);
      }
    }
  };

  // Button 1: Save & Next (official NTA: marks as Answered -> Green)
  const handleSaveAndNext = () => {
    if (!currentQuestion) return;

    if (currentOptionChoice.trim() !== '') {
      setResponses((prev) => ({
        ...prev,
        [currentQuestion.id]: {
          selectedOption: currentOptionChoice,
          state: 'answered',
          timeSpentSeconds: prev[currentQuestion.id]?.timeSpentSeconds || 0,
        },
      }));
    } else {
      // If nothing chosen, remains not_answered
      setResponses((prev) => ({
        ...prev,
        [currentQuestion.id]: {
          selectedOption: undefined,
          state: 'not_answered',
          timeSpentSeconds: prev[currentQuestion.id]?.timeSpentSeconds || 0,
        },
      }));
    }
    moveToNextQuestion();
  };

  // Button 2: Clear Response
  const handleClearResponse = () => {
    if (!currentQuestion) return;
    setCurrentOptionChoice('');
    setResponses((prev) => ({
      ...prev,
      [currentQuestion.id]: {
        selectedOption: undefined,
        state: 'not_answered',
        timeSpentSeconds: prev[currentQuestion.id]?.timeSpentSeconds || 0,
      },
    }));
  };

  // Button 3: Save & Mark for Review (Answered & Marked -> Purple with small green dot, counts in evaluation)
  const handleSaveAndMarkForReview = () => {
    if (!currentQuestion) return;

    if (currentOptionChoice.trim() !== '') {
      setResponses((prev) => ({
        ...prev,
        [currentQuestion.id]: {
          selectedOption: currentOptionChoice,
          state: 'answered_and_marked',
          timeSpentSeconds: prev[currentQuestion.id]?.timeSpentSeconds || 0,
        },
      }));
    } else {
      setResponses((prev) => ({
        ...prev,
        [currentQuestion.id]: {
          selectedOption: undefined,
          state: 'marked_for_review',
          timeSpentSeconds: prev[currentQuestion.id]?.timeSpentSeconds || 0,
        },
      }));
    }
    moveToNextQuestion();
  };

  // Button 4: Mark for Review & Next (without answering or answer pending)
  const handleMarkForReviewAndNext = () => {
    if (!currentQuestion) return;

    setResponses((prev) => ({
      ...prev,
      [currentQuestion.id]: {
        selectedOption: currentOptionChoice || undefined,
        state: currentOptionChoice ? 'answered_and_marked' : 'marked_for_review',
        timeSpentSeconds: prev[currentQuestion.id]?.timeSpentSeconds || 0,
      },
    }));
    moveToNextQuestion();
  };

  // Final Test Submission (Supports both manual candidate click and automated timer expiry)
  const handleFinalSubmit = (isAutoSubmit = false) => {
    if (isSubmittingRef.current) return;
    isSubmittingRef.current = true;

    // Merge in-progress option selection if student had selected an option on active question
    const currentActiveQ = currentQuestionRef.current;
    const currentActiveChoice = currentOptionChoiceRef.current;
    const finalResponses = { ...responsesRef.current };

    if (currentActiveQ && currentActiveChoice && currentActiveChoice.trim() !== '') {
      const existing = finalResponses[currentActiveQ.id] || {
        state: 'not_answered',
        timeSpentSeconds: 0,
      };
      finalResponses[currentActiveQ.id] = {
        selectedOption: currentActiveChoice,
        state: existing.state === 'marked_for_review' ? 'answered_and_marked' : 'answered',
        timeSpentSeconds: existing.timeSpentSeconds,
      };
    }

    const timeSpentSeconds = isAutoSubmit
      ? durationTotalSeconds
      : Math.min(durationTotalSeconds, Math.max(0, durationTotalSeconds - timeLeftSecondsRef.current));

    const evaluation = evaluateTest(test.questions, finalResponses);

    const attempt: StudentTestAttempt = {
      id: `attempt-${Date.now()}`,
      testId: test.id,
      testTitle: test.title,
      seriesId: test.seriesId,
      studentId: currentUser?.id || 'demo-candidate-1',
      studentName: currentUser?.name || 'Aspirant',
      studentRoll: currentUser?.rollNo || 'ARG-2026-NTA',
      submittedAt: new Date().toISOString(),
      timeSpentSeconds,
      responses: finalResponses,
      score: evaluation.score,
      maxScore: evaluation.maxScore,
      correctCount: evaluation.correctCount,
      incorrectCount: evaluation.incorrectCount,
      unattemptedCount: evaluation.unattemptedCount,
      accuracy: evaluation.accuracy,
      percentile: evaluation.percentile,
      sectionScores: evaluation.sectionScores,
      autoSubmitted: isAutoSubmit,
    };

    setIsSubmitModalOpen(false);
    setIsQuestionPaperModalOpen(false);
    setIsInstructionsModalOpen(false);

    if (isAutoSubmit) {
      setIsAutoSubmitting(true);
      // Brief 1.5s visual confirmation for student before navigating to scorecard
      setTimeout(() => {
        submitExam(attempt);
      }, 1500);
    } else {
      submitExam(attempt);
    }
  };

  // Palette summary counts
  const allCounts = countPaletteStates(test.questions, responses);
  const sectionCounts = countPaletteStates(test.questions, responses, activeSection);

  return (
    <div className="min-h-screen bg-slate-100 text-slate-800 flex flex-col font-sans select-none">
      {/* 1. Official NTA-Style Top Header Bar */}
      <header className="bg-slate-900 border-b border-slate-800 text-white px-4 py-2 flex items-center justify-between shadow-md">
        <div className="flex items-center gap-3">
          <ArgonLogo size="sm" theme="dark" showText={true} />
          <div className="h-6 w-px bg-slate-700 hidden sm:block" />
          <div>
            <h1 className="font-bold text-xs sm:text-sm text-slate-300 leading-tight">
              NTA CBT EXAMINATION PORTAL
            </h1>
            <p className="text-[11px] text-amber-400 font-semibold">{test.title}</p>
          </div>
        </div>

        <div className="flex items-center gap-3 sm:gap-6">
          {/* Header Action Modals */}
          <div className="hidden md:flex items-center gap-2">
            <button
              onClick={() => setIsQuestionPaperModalOpen(true)}
              className="px-2.5 py-1 text-xs font-semibold bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 rounded flex items-center gap-1 transition-colors"
            >
              <FileText className="w-3.5 h-3.5 text-indigo-400" />
              Question Paper
            </button>
            <button
              onClick={() => setIsInstructionsModalOpen(true)}
              className="px-2.5 py-1 text-xs font-semibold bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 rounded flex items-center gap-1 transition-colors"
            >
              <HelpCircle className="w-3.5 h-3.5 text-amber-400" />
              Instructions
            </button>
          </div>

          {/* Candidate Profile Box */}
          <div className="flex items-center gap-2.5 bg-slate-800/80 px-3 py-1 rounded border border-slate-700">
            <div className="w-8 h-8 rounded bg-slate-700 border border-slate-600 overflow-hidden flex items-center justify-center">
              {currentUser?.avatar ? (
                <img
                  src={currentUser.avatar}
                  alt={currentUser.name}
                  className="w-full h-full object-cover"
                />
              ) : (
                <UserIcon className="w-5 h-5 text-slate-400" />
              )}
            </div>
            <div className="text-left text-xs leading-tight">
              <p className="font-bold text-white truncate max-w-[120px]">
                {currentUser?.name || 'Candidate'}
              </p>
              <p className="font-mono text-[10px] text-slate-400">
                {currentUser?.rollNo || 'ARG-2026-NTA'}
              </p>
            </div>
          </div>
        </div>
      </header>

      {/* 2. Sub-Header: Subject Section Tabs & Live Countdown Timer */}
      <div className="bg-slate-200 border-b border-slate-300 px-4 py-2 flex flex-wrap items-center justify-between gap-2">
        {/* Sections Navigation */}
        <div className="flex items-center gap-1.5 overflow-x-auto">
          <span className="text-xs font-bold text-slate-600 mr-2 uppercase tracking-wide">
            Sections:
          </span>
          {availableSections.map((sec) => {
            const isSelected = activeSection === sec;
            const qCountInSec = test.questions.filter((q) => q.section === sec).length;
            return (
              <button
                key={sec}
                onClick={() => {
                  setActiveSection(sec);
                  setCurrentQuestionIndex(0);
                }}
                className={`px-3.5 py-1.5 rounded text-xs font-bold transition-all flex items-center gap-1.5 ${
                  isSelected
                    ? 'bg-blue-700 text-white shadow-sm'
                    : 'bg-white text-slate-700 hover:bg-slate-50 border border-slate-300'
                }`}
              >
                <span>{sec}</span>
                <span
                  className={`text-[10px] px-1.5 py-0.2 rounded-full ${
                    isSelected ? 'bg-blue-900 text-blue-200' : 'bg-slate-200 text-slate-600'
                  }`}
                >
                  {qCountInSec}
                </span>
              </button>
            );
          })}
        </div>

        {/* NTA Countdown Timer */}
        <div
          className={`flex items-center gap-2 px-3.5 py-1.5 rounded-lg border font-mono font-bold text-xs sm:text-sm transition-all shadow-sm ${
            timeLeftSeconds === 0
              ? 'bg-rose-700 text-white border-rose-800 animate-pulse ring-2 ring-rose-400'
              : timeLeftSeconds <= 60
              ? 'bg-red-600 text-white border-red-700 ring-2 ring-red-400 animate-pulse'
              : timeLeftSeconds <= 300
              ? 'bg-amber-100 text-amber-900 border-amber-400 font-extrabold'
              : 'bg-white text-slate-900 border-slate-300'
          }`}
        >
          <Clock
            className={`w-4 h-4 ${
              timeLeftSeconds <= 60
                ? 'text-white animate-spin'
                : timeLeftSeconds <= 300
                ? 'text-amber-600'
                : 'text-blue-600'
            }`}
          />
          <span
            className={`text-xs font-sans font-semibold ${
              timeLeftSeconds <= 60 ? 'text-red-100' : 'text-slate-500'
            }`}
          >
            {timeLeftSeconds <= 60 ? 'Auto-Submitting:' : 'Time Left:'}
          </span>
          <span className="tracking-wider">{formatTimer(timeLeftSeconds)}</span>
        </div>
      </div>

      {/* Critical Countdown Warning Strip (< 60s) */}
      {timeLeftSeconds > 0 && timeLeftSeconds <= 60 && !isAutoSubmitting && (
        <div className="bg-red-600 text-white text-xs px-4 py-2 font-bold flex items-center justify-between animate-pulse shadow-md z-30">
          <div className="flex items-center gap-2">
            <AlertTriangle className="w-4 h-4 text-amber-300 shrink-0" />
            <span>
              FINAL MINUTE WARNING: Only {timeLeftSeconds} second{timeLeftSeconds === 1 ? '' : 's'} remaining!
              The exam will automatically end and submit all answers when the countdown hits 00:00:00.
            </span>
          </div>
          <span className="hidden md:inline-block font-mono bg-red-800 text-red-100 px-2.5 py-0.5 rounded text-[11px]">
            NTA CBT Auto-Submit Active
          </span>
        </div>
      )}

      {/* 3. Main Examination Canvas (Split Layout) */}
      <div className="flex-1 flex flex-col lg:flex-row overflow-hidden bg-slate-100">
        {/* Left/Center Panel: Question Area & Navigation (75% desktop) */}
        <main className="flex-1 flex flex-col justify-between border-r border-slate-300 bg-white overflow-y-auto">
          {currentQuestion ? (
            <div className="p-4 sm:p-6 max-w-4xl">
              {/* Question Meta Header */}
              <div className="flex items-center justify-between pb-3 border-b border-slate-200 mb-4">
                <div className="flex items-center gap-3">
                  <span className="font-extrabold text-blue-700 text-base sm:text-lg">
                    Question No. {currentQuestionIndex + 1}
                  </span>
                  <span className="text-xs font-semibold px-2 py-0.5 rounded bg-slate-100 border border-slate-300 text-slate-700">
                    {currentQuestion.type === 'mcq'
                      ? 'Single Choice Type'
                      : 'Numerical / Integer Value'}
                  </span>
                </div>

                <div className="text-xs font-semibold text-slate-600">
                  Marks for correct answer:{' '}
                  <span className="text-emerald-600 font-bold">
                    +{currentQuestion.positiveMarks}
                  </span>{' '}
                  | Negative Marks:{' '}
                  <span className="text-red-600 font-bold">-{currentQuestion.negativeMarks}</span>
                </div>
              </div>

              {/* Question Text */}
              <div className="text-sm sm:text-base text-slate-900 font-medium leading-relaxed mb-4">
                {currentQuestion.text}
              </div>

              {/* High-Resolution Diagram / Image */}
              {currentQuestion.imageUrl && (
                <div className="my-4 p-2 bg-slate-50 border border-slate-200 rounded-lg max-w-xl relative group">
                  <img
                    src={currentQuestion.imageUrl}
                    alt="Question Diagram"
                    className="max-h-72 w-auto object-contain mx-auto"
                  />
                  <button
                    onClick={() => setZoomedImage(currentQuestion.imageUrl || null)}
                    className="absolute top-3 right-3 p-1.5 bg-slate-900/80 hover:bg-slate-900 text-white rounded opacity-0 group-hover:opacity-100 transition-opacity flex items-center gap-1 text-xs"
                    title="Enlarge Diagram"
                  >
                    <ZoomIn className="w-3.5 h-3.5" />
                    Enlarge
                  </button>
                </div>
              )}

              {/* Options Section */}
              <div className="mt-6 pt-4 border-t border-slate-200">
                {currentQuestion.type === 'mcq' ? (
                  <div className="space-y-3 max-w-2xl">
                    {currentQuestion.options.map((opt) => {
                      const isChecked = currentOptionChoice === opt.key;
                      return (
                        <label
                          key={opt.key}
                          onClick={() => setCurrentOptionChoice(opt.key)}
                          className={`flex items-start gap-3 p-3 rounded-lg border cursor-pointer transition-all ${
                            isChecked
                              ? 'bg-blue-50 border-blue-600 ring-1 ring-blue-500'
                              : 'bg-white border-slate-300 hover:bg-slate-50'
                          }`}
                        >
                          <input
                            type="radio"
                            name={`q_${currentQuestion.id}`}
                            value={opt.key}
                            checked={isChecked}
                            onChange={() => setCurrentOptionChoice(opt.key)}
                            className="mt-1 w-4 h-4 text-blue-600 border-slate-300 focus:ring-blue-500"
                          />
                          <div className="text-sm font-semibold text-slate-800">
                            <span className="inline-block w-6 font-bold text-blue-800">
                              ({opt.key})
                            </span>
                            <span>{opt.text}</span>
                          </div>
                        </label>
                      );
                    })}
                  </div>
                ) : (
                  <div className="p-4 bg-slate-50 border border-slate-300 rounded-lg max-w-md">
                    <label className="block text-xs font-bold text-slate-700 uppercase mb-2">
                      Enter Numeric / Integer Answer:
                    </label>
                    <input
                      type="text"
                      value={currentOptionChoice}
                      onChange={(e) => setCurrentOptionChoice(e.target.value)}
                      placeholder="e.g. 12 or 2.5"
                      className="w-full px-4 py-2.5 bg-white border border-slate-300 rounded-lg text-base font-bold font-mono text-slate-900 focus:outline-none focus:border-blue-600 focus:ring-1 focus:ring-blue-500"
                    />
                    <p className="text-[11px] text-slate-500 mt-2">
                      Use standard decimal format if fractional (e.g. 12.5).
                    </p>
                  </div>
                )}
              </div>
            </div>
          ) : (
            <div className="p-8 text-center text-slate-500">No question available.</div>
          )}

          {/* Bottom Action Control Bar (Authentic NTA Layout) */}
          <div className="p-3 sm:p-4 bg-slate-200 border-t border-slate-300 flex flex-wrap items-center justify-between gap-2">
            <div className="flex flex-wrap items-center gap-2">
              <button
                onClick={handleSaveAndNext}
                className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs sm:text-sm rounded shadow transition-colors flex items-center gap-1.5"
              >
                <Check className="w-4 h-4" />
                Save & Next
              </button>

              <button
                onClick={handleClearResponse}
                className="px-3.5 py-2 bg-white hover:bg-slate-100 text-slate-700 border border-slate-300 font-semibold text-xs sm:text-sm rounded transition-colors"
              >
                Clear Response
              </button>

              <button
                onClick={handleSaveAndMarkForReview}
                className="px-3.5 py-2 bg-purple-700 hover:bg-purple-800 text-white font-bold text-xs sm:text-sm rounded shadow transition-colors flex items-center gap-1.5"
              >
                <Bookmark className="w-4 h-4" />
                Save & Mark for Review
              </button>

              <button
                onClick={handleMarkForReviewAndNext}
                className="px-3.5 py-2 bg-amber-600 hover:bg-amber-700 text-white font-bold text-xs sm:text-sm rounded shadow transition-colors"
              >
                Mark for Review & Next
              </button>
            </div>

            <div className="flex items-center gap-2">
              <button
                disabled={currentQuestionIndex === 0}
                onClick={() => setCurrentQuestionIndex((prev) => Math.max(0, prev - 1))}
                className="px-3 py-2 bg-white hover:bg-slate-100 disabled:opacity-40 text-slate-700 border border-slate-300 font-semibold text-xs sm:text-sm rounded transition-colors flex items-center gap-1"
              >
                <ChevronLeft className="w-4 h-4" />
                Previous
              </button>

              <button
                disabled={currentQuestionIndex === sectionQuestions.length - 1}
                onClick={() =>
                  setCurrentQuestionIndex((prev) =>
                    Math.min(sectionQuestions.length - 1, prev + 1)
                  )
                }
                className="px-3 py-2 bg-white hover:bg-slate-100 disabled:opacity-40 text-slate-700 border border-slate-300 font-semibold text-xs sm:text-sm rounded transition-colors flex items-center gap-1"
              >
                Next
                <ChevronRight className="w-4 h-4" />
              </button>

              <button
                onClick={() => setIsSubmitModalOpen(true)}
                className="px-5 py-2 bg-blue-700 hover:bg-blue-800 text-white font-extrabold text-xs sm:text-sm rounded shadow-md transition-all ml-2"
              >
                Submit Test
              </button>
            </div>
          </div>
        </main>

        {/* Right Panel: Official NTA Question Palette & Status Legend (25% desktop) */}
        <aside className="w-full lg:w-80 bg-slate-50 border-t lg:border-t-0 border-slate-300 p-4 flex flex-col justify-between overflow-y-auto">
          <div>
            {/* Status Legend Section */}
            <div className="bg-white p-3 rounded-lg border border-slate-300 shadow-sm mb-4">
              <p className="text-xs font-extrabold text-slate-800 uppercase tracking-wider mb-2.5 pb-1 border-b border-slate-200">
                Question Status Palette
              </p>

              <div className="grid grid-cols-2 gap-2 text-[11px] font-semibold text-slate-700">
                <div className="flex items-center gap-2">
                  <div className="w-6 h-6 rounded bg-emerald-600 text-white font-bold flex items-center justify-center text-xs shrink-0 shadow-sm">
                    {sectionCounts.answered}
                  </div>
                  <span>Answered</span>
                </div>

                <div className="flex items-center gap-2">
                  <div className="w-6 h-6 rounded bg-red-600 text-white font-bold flex items-center justify-center text-xs shrink-0 shadow-sm">
                    {sectionCounts.not_answered}
                  </div>
                  <span>Not Answered</span>
                </div>

                <div className="flex items-center gap-2">
                  <div className="w-6 h-6 rounded bg-slate-300 text-slate-800 font-bold flex items-center justify-center text-xs shrink-0">
                    {sectionCounts.not_visited}
                  </div>
                  <span>Not Visited</span>
                </div>

                <div className="flex items-center gap-2">
                  <div className="w-6 h-6 rounded-full bg-purple-700 text-white font-bold flex items-center justify-center text-xs shrink-0 shadow-sm">
                    {sectionCounts.marked_for_review}
                  </div>
                  <span>Marked for Review</span>
                </div>

                <div className="col-span-2 flex items-center gap-2 pt-1 border-t border-slate-100">
                  <div className="w-6 h-6 rounded-full bg-purple-700 text-white font-bold flex items-center justify-center text-xs shrink-0 relative">
                    <span className="w-2 h-2 rounded-full bg-emerald-400 absolute -bottom-0.5 -right-0.5 ring-1 ring-white"></span>
                    {sectionCounts.answered_and_marked}
                  </div>
                  <span className="text-[10px] text-slate-600 leading-tight">
                    Answered & Marked for Review (Evaluated)
                  </span>
                </div>
              </div>
            </div>

            {/* Current Section Questions Grid */}
            <div className="bg-white p-3 rounded-lg border border-slate-300 shadow-sm">
              <div className="flex items-center justify-between mb-3 pb-1 border-b border-slate-200">
                <span className="text-xs font-bold text-slate-800 uppercase">
                  {activeSection} Questions
                </span>
                <span className="text-[11px] font-semibold text-slate-500">
                  {sectionQuestions.length} Questions
                </span>
              </div>

              <div className="grid grid-cols-5 gap-2 max-h-72 overflow-y-auto p-1">
                {sectionQuestions.map((q, idx) => {
                  const resp = responses[q.id];
                  const state = resp?.state || 'not_visited';
                  const isCurrent = idx === currentQuestionIndex;

                  let bgStyle = 'bg-slate-200 text-slate-700 hover:bg-slate-300';
                  if (state === 'answered') {
                    bgStyle = 'bg-emerald-600 text-white';
                  } else if (state === 'not_answered') {
                    bgStyle = 'bg-red-600 text-white';
                  } else if (state === 'marked_for_review') {
                    bgStyle = 'bg-purple-700 text-white rounded-full';
                  } else if (state === 'answered_and_marked') {
                    bgStyle = 'bg-purple-700 text-white rounded-full';
                  }

                  return (
                    <button
                      key={q.id}
                      onClick={() => setCurrentQuestionIndex(idx)}
                      className={`h-9 font-bold text-xs rounded transition-all flex items-center justify-center relative ${bgStyle} ${
                        isCurrent ? 'ring-2 ring-blue-600 ring-offset-1 font-black scale-105' : ''
                      }`}
                    >
                      {idx + 1}
                      {state === 'answered_and_marked' && (
                        <span className="w-2 h-2 rounded-full bg-emerald-400 absolute top-0.5 right-0.5 ring-1 ring-white"></span>
                      )}
                    </button>
                  );
                })}
              </div>
            </div>
          </div>

          {/* Quick Submit Test Action */}
          <div className="mt-4 pt-3 border-t border-slate-300">
            <button
              onClick={() => setIsSubmitModalOpen(true)}
              className="w-full py-2.5 px-4 bg-blue-700 hover:bg-blue-800 text-white font-extrabold text-sm rounded-lg shadow-md transition-all flex items-center justify-center gap-2"
            >
              <CheckCircle2 className="w-4 h-4" />
              Final Test Submission
            </button>
          </div>
        </aside>
      </div>

      {/* ================= MODAL: SUBMISSION CONFIRMATION SUMMARY ================= */}
      {isSubmitModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-fadeIn">
          <div className="w-full max-w-2xl bg-white border border-slate-300 rounded-xl shadow-2xl p-6 text-slate-900">
            <div className="flex items-center justify-between pb-3 border-b border-slate-200 mb-4">
              <h3 className="text-lg font-extrabold text-slate-900 flex items-center gap-2">
                <AlertTriangle className="w-5 h-5 text-amber-500" />
                Exam Submission Confirmation
              </h3>
              <button
                onClick={() => setIsSubmitModalOpen(false)}
                className="text-slate-400 hover:text-slate-700"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <p className="text-xs text-slate-600 mb-4">
              Please review your question attempt summary before submitting your test. Once submitted, you cannot change your answers.
            </p>

            {/* Section Breakdown Table */}
            <div className="border border-slate-300 rounded-lg overflow-hidden mb-6">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-100 text-slate-700 font-bold border-b border-slate-300">
                  <tr>
                    <th className="py-2.5 px-3">Section Name</th>
                    <th className="py-2.5 px-3">No. of Questions</th>
                    <th className="py-2.5 px-3 text-emerald-700">Answered</th>
                    <th className="py-2.5 px-3 text-red-700">Not Answered</th>
                    <th className="py-2.5 px-3 text-purple-700">Marked Review</th>
                    <th className="py-2.5 px-3 text-slate-600">Not Visited</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200 font-medium">
                  {availableSections.map((sec) => {
                    const secCount = countPaletteStates(test.questions, responses, sec);
                    const totalSecQ = test.questions.filter((q) => q.section === sec).length;
                    return (
                      <tr key={sec} className="hover:bg-slate-50">
                        <td className="py-2 px-3 font-bold text-slate-800">{sec}</td>
                        <td className="py-2 px-3">{totalSecQ}</td>
                        <td className="py-2 px-3 font-bold text-emerald-700">
                          {secCount.answered + secCount.answered_and_marked}
                        </td>
                        <td className="py-2 px-3 font-bold text-red-700">
                          {secCount.not_answered}
                        </td>
                        <td className="py-2 px-3 font-bold text-purple-700">
                          {secCount.marked_for_review}
                        </td>
                        <td className="py-2 px-3 text-slate-600">{secCount.not_visited}</td>
                      </tr>
                    );
                  })}
                  <tr className="bg-slate-100 font-bold">
                    <td className="py-2.5 px-3">Total Summary</td>
                    <td className="py-2.5 px-3">{test.questions.length}</td>
                    <td className="py-2.5 px-3 text-emerald-700">
                      {allCounts.answered + allCounts.answered_and_marked}
                    </td>
                    <td className="py-2.5 px-3 text-red-700">{allCounts.not_answered}</td>
                    <td className="py-2.5 px-3 text-purple-700">{allCounts.marked_for_review}</td>
                    <td className="py-2.5 px-3 text-slate-600">{allCounts.not_visited}</td>
                  </tr>
                </tbody>
              </table>
            </div>

            <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-200">
              <button
                type="button"
                onClick={() => setIsSubmitModalOpen(false)}
                className="px-4 py-2 bg-slate-200 hover:bg-slate-300 text-slate-700 font-bold text-xs rounded transition-colors"
              >
                Resume Test
              </button>
              <button
                type="button"
                onClick={() => handleFinalSubmit(false)}
                className="px-6 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold text-xs rounded shadow transition-all"
              >
                Yes, Submit Test Now
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ================= MODAL: FULL QUESTION PAPER VIEW ================= */}
      {isQuestionPaperModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm">
          <div className="w-full max-w-4xl bg-white border border-slate-300 rounded-xl shadow-2xl p-6 text-slate-900 max-h-[85vh] flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between pb-3 border-b border-slate-200 mb-4">
                <h3 className="text-base font-extrabold text-slate-900">
                  Full Question Paper Preview - {test.title}
                </h3>
                <button
                  onClick={() => setIsQuestionPaperModalOpen(false)}
                  className="text-slate-400 hover:text-slate-700"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <div className="space-y-4 max-h-[60vh] overflow-y-auto pr-2 text-xs">
                {test.questions.map((q, idx) => (
                  <div key={q.id} className="p-3 bg-slate-50 border border-slate-200 rounded-lg">
                    <div className="flex items-center justify-between mb-1 font-bold text-blue-800">
                      <span>
                        Q{idx + 1} ({q.section})
                      </span>
                      <span>
                        +{q.positiveMarks} / -{q.negativeMarks} Marks
                      </span>
                    </div>
                    <p className="text-slate-900 font-medium mb-2">{q.text}</p>
                    {q.imageUrl && (
                      <img
                        src={q.imageUrl}
                        alt="Question diagram"
                        className="max-h-36 object-contain my-2 rounded border border-slate-200 bg-white"
                      />
                    )}
                    {q.type === 'mcq' && (
                      <div className="grid grid-cols-2 gap-2 text-slate-700">
                        {q.options.map((opt) => (
                          <div key={opt.key}>
                            <strong className="text-blue-700">({opt.key})</strong> {opt.text}
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>

            <div className="pt-3 border-t border-slate-200 flex justify-end">
              <button
                onClick={() => setIsQuestionPaperModalOpen(false)}
                className="px-4 py-1.5 bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs rounded"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ================= MODAL: INSTRUCTIONS ================= */}
      {isInstructionsModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm">
          <div className="w-full max-w-2xl bg-white border border-slate-300 rounded-xl shadow-2xl p-6 text-slate-900 max-h-[85vh] flex flex-col justify-between text-xs">
            <div>
              <div className="flex items-center justify-between pb-3 border-b border-slate-200 mb-4">
                <h3 className="text-base font-extrabold text-slate-900">
                  General Examination Instructions
                </h3>
                <button
                  onClick={() => setIsInstructionsModalOpen(false)}
                  className="text-slate-400 hover:text-slate-700"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <div className="space-y-3 max-h-[60vh] overflow-y-auto pr-2 text-slate-700 leading-relaxed">
                <p className="font-bold text-slate-900">1. General Overview:</p>
                <p>
                  The countdown timer in the top right corner displays the remaining time for the
                  examination. When the timer reaches zero, the examination will end automatically.
                </p>

                <p className="font-bold text-slate-900">2. Question Palette Colors:</p>
                <ul className="list-disc pl-5 space-y-1">
                  <li>
                    <strong className="text-slate-700">Silver/Gray:</strong> You have not visited
                    the question yet.
                  </li>
                  <li>
                    <strong className="text-red-700">Red:</strong> You have visited the question but
                    not answered it.
                  </li>
                  <li>
                    <strong className="text-emerald-700">Green:</strong> You have answered the
                    question.
                  </li>
                  <li>
                    <strong className="text-purple-700">Purple:</strong> You have marked the
                    question for review without an answer.
                  </li>
                  <li>
                    <strong className="text-purple-700">Purple with Green Dot:</strong> The question
                    has been answered AND marked for review (it will be considered for evaluation).
                  </li>
                </ul>

                <p className="font-bold text-slate-900">3. Marking Scheme:</p>
                <p>
                  Each correct response is awarded +4 marks. An incorrect response incurs a penalty
                  of -1 mark. Unattempted questions receive 0 marks.
                </p>
              </div>
            </div>

            <div className="pt-3 border-t border-slate-200 flex justify-end">
              <button
                onClick={() => setIsInstructionsModalOpen(false)}
                className="px-4 py-1.5 bg-blue-700 hover:bg-blue-800 text-white font-bold text-xs rounded"
              >
                Understood, Return to Test
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ================= MODAL: DIAGRAM ZOOM ================= */}
      {zoomedImage && (
        <div
          onClick={() => setZoomedImage(null)}
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/90 backdrop-blur-sm cursor-zoom-out"
        >
          <div className="max-w-4xl max-h-[90vh] bg-white p-4 rounded-xl shadow-2xl relative">
            <button
              onClick={() => setZoomedImage(null)}
              className="absolute top-2 right-2 p-1 bg-slate-900 text-white rounded-full hover:bg-slate-700"
            >
              <X className="w-4 h-4" />
            </button>
            <img src={zoomedImage} alt="Zoomed Diagram" className="max-h-[80vh] object-contain" />
          </div>
        </div>
      )}

      {/* ================= MODAL: AUTO-SUBMISSION ON TIMER EXPIRY ================= */}
      {isAutoSubmitting && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/90 backdrop-blur-md animate-fadeIn">
          <div className="w-full max-w-lg bg-white border-2 border-red-500 rounded-2xl shadow-2xl p-8 text-center text-slate-900 space-y-4">
            <div className="w-16 h-16 rounded-full bg-red-100 border-2 border-red-500 text-red-600 flex items-center justify-center mx-auto shadow-inner animate-bounce">
              <Clock className="w-8 h-8" />
            </div>

            <div className="space-y-1">
              <span className="text-[10px] uppercase tracking-widest font-extrabold px-3 py-1 rounded-full bg-red-100 text-red-700 border border-red-300">
                NTA CBT Engine • Timer Expiry
              </span>
              <h2 className="text-2xl font-black text-slate-900 pt-2">
                Examination Time Has Expired!
              </h2>
              <p className="text-xs text-slate-600 max-w-md mx-auto leading-relaxed">
                The allocated {test.durationMinutes}-minute examination window has concluded.
                All your saved and marked responses have been automatically captured and submitted to the evaluation engine.
              </p>
            </div>

            <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl space-y-2">
              <div className="flex items-center justify-center gap-2 text-xs font-bold text-blue-700">
                <span className="w-2.5 h-2.5 rounded-full bg-blue-600 animate-ping"></span>
                <span>Submitting responses & generating scorecard...</span>
              </div>
              <p className="text-[11px] text-slate-500">
                Candidate: <strong>{currentUser?.name || 'Aspirant'}</strong> • Roll:{' '}
                <strong>{currentUser?.rollNo || 'ARG-2026-NTA'}</strong>
              </p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
