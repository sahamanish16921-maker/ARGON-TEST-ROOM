import React, { useState } from 'react';
import { useApp } from '../context/AppContext.tsx';
import type { StudentTestAttempt, Question } from '../types/index.ts';
import {
  Trophy,
  CheckCircle2,
  XCircle,
  AlertCircle,
  BarChart2,
  Clock,
  ArrowLeft,
  RotateCcw,
  Printer,
  ChevronRight,
  ChevronLeft,
  Filter,
  Layers,
  Award,
  Sparkles,
  BookOpen,
  Image as ImageIcon,
  Maximize2,
  X,
  Target,
  Zap,
  HelpCircle,
  TrendingUp,
} from 'lucide-react';

export const ResultAnalysisView: React.FC = () => {
  const { attempts, activeAttemptId, tests, startExam, exitExamOrResult } = useApp();

  const attempt: StudentTestAttempt | undefined =
    attempts.find((a) => a.id === activeAttemptId) || attempts[0];

  const test = tests.find((t) => t.id === attempt?.testId);

  // Active top view tab: 'analytics' (Scorecard) vs 'solutions' (Serial Solution Gallery)
  const [viewTab, setViewTab] = useState<'analytics' | 'solutions'>('solutions');

  // Filter for questions in solutions
  const [activeFilter, setActiveFilter] = useState<
    'all' | 'correct' | 'incorrect' | 'unattempted'
  >('all');
  const [selectedSection, setSelectedSection] = useState<string>('All');

  // Selected Serial Question Index for single-focus view in Solution Section
  const [focusedQuestionIndex, setFocusedQuestionIndex] = useState<number>(0);
  const [solutionImageLightbox, setSolutionImageLightbox] = useState<string | null>(null);

  if (!attempt || !test) {
    return (
      <div className="min-h-screen bg-slate-950 text-white flex flex-col items-center justify-center p-4">
        <p className="text-sm text-slate-400 mb-4">No test scorecard found.</p>
        <button
          onClick={exitExamOrResult}
          className="px-4 py-2 bg-indigo-600 rounded-lg text-xs font-bold"
        >
          Return to Dashboard
        </button>
      </div>
    );
  }

  // Filtered questions based on selected section and answer status
  const filteredQuestions = test.questions.filter((q) => {
    if (selectedSection !== 'All' && q.section !== selectedSection) return false;

    const resp = attempt.responses[q.id];
    const isAttempted =
      resp &&
      (resp.state === 'answered' || resp.state === 'answered_and_marked') &&
      resp.selectedOption;

    const isCorrect =
      isAttempted &&
      String(resp?.selectedOption).trim().toUpperCase() ===
        String(q.correctAnswer).trim().toUpperCase();

    if (activeFilter === 'correct') return isCorrect;
    if (activeFilter === 'incorrect') return isAttempted && !isCorrect;
    if (activeFilter === 'unattempted') return !isAttempted;
    return true;
  });

  const currentFocusedQuestion: Question | undefined =
    filteredQuestions[focusedQuestionIndex] || filteredQuestions[0];

  const currentFocusedGlobalNum = currentFocusedQuestion
    ? test.questions.findIndex((q) => q.id === currentFocusedQuestion.id) + 1
    : 1;

  const currentFocusedResp = currentFocusedQuestion
    ? attempt.responses[currentFocusedQuestion.id]
    : undefined;

  const isCurrentAttempted =
    currentFocusedResp &&
    (currentFocusedResp.state === 'answered' ||
      currentFocusedResp.state === 'answered_and_marked') &&
    currentFocusedResp.selectedOption;

  const isCurrentCorrect =
    isCurrentAttempted &&
    currentFocusedQuestion &&
    String(currentFocusedResp?.selectedOption).trim().toUpperCase() ===
      String(currentFocusedQuestion.correctAnswer).trim().toUpperCase();

  const handleOpenQuestionSolution = (questionId: string) => {
    const idx = filteredQuestions.findIndex((q) => q.id === questionId);
    if (idx !== -1) {
      setFocusedQuestionIndex(idx);
    } else {
      setSelectedSection('All');
      setActiveFilter('all');
      const allIdx = test.questions.findIndex((q) => q.id === questionId);
      setFocusedQuestionIndex(Math.max(0, allIdx));
    }
    setViewTab('solutions');
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 pb-16 font-sans">
      {/* Top Header Bar */}
      <header className="bg-slate-900 border-b border-slate-800 py-3.5 px-4 sm:px-6 lg:px-8 sticky top-0 z-40 backdrop-blur-md bg-slate-900/95">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <button
              onClick={exitExamOrResult}
              className="p-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl transition-colors"
              title="Return to Dashboard"
            >
              <ArrowLeft className="w-4 h-4" />
            </button>
            <div>
              <div className="flex items-center gap-2 flex-wrap">
                <span className="text-[11px] font-bold px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                  Evaluated & Synced Live
                </span>
                <span className="text-xs text-amber-400 font-mono font-bold">{test.examType}</span>
                {attempt.autoSubmitted && (
                  <span className="text-[11px] font-bold px-2 py-0.5 rounded bg-rose-500/20 text-rose-300 border border-rose-500/30 flex items-center gap-1">
                    <Clock className="w-3 h-3 text-rose-400" />
                    Auto-Submitted on Timer
                  </span>
                )}
              </div>
              <h1 className="text-lg sm:text-xl font-black text-white mt-0.5">
                {test.title}
              </h1>
            </div>
          </div>

          {/* Mode Switcher Tabs */}
          <div className="flex items-center gap-2 w-full md:w-auto justify-between md:justify-end">
            <div className="flex bg-slate-950 p-1 rounded-xl border border-slate-800 text-xs font-semibold">
              <button
                onClick={() => setViewTab('solutions')}
                className={`py-1.5 px-3.5 rounded-lg transition-all flex items-center gap-1.5 ${
                  viewTab === 'solutions'
                    ? 'bg-amber-500 text-slate-950 font-bold shadow-md shadow-amber-500/20'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                <BookOpen className="w-3.5 h-3.5" />
                <span>Serial Solutions (Image Form)</span>
              </button>
              <button
                onClick={() => setViewTab('analytics')}
                className={`py-1.5 px-3.5 rounded-lg transition-all flex items-center gap-1.5 ${
                  viewTab === 'analytics'
                    ? 'bg-indigo-600 text-white font-bold shadow-md shadow-indigo-600/20'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                <BarChart2 className="w-3.5 h-3.5" />
                <span>Performance Analytics</span>
              </button>
            </div>

            <div className="hidden sm:flex items-center gap-2">
              <button
                onClick={() => window.print()}
                className="px-3 py-1.5 text-xs font-semibold bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-xl border border-slate-700 flex items-center gap-1.5 transition-colors"
              >
                <Printer className="w-3.5 h-3.5" />
                <span>Print</span>
              </button>
              <button
                onClick={() => startExam(test.id)}
                className="px-3 py-1.5 text-xs font-bold bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl shadow-md transition-all flex items-center gap-1.5"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>Retake</span>
              </button>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mt-6">
        {/* ========================================================================= */}
        {/* TAB 1: SERIAL SOLUTION SECTION (IMAGE FORM)                               */}
        {/* ========================================================================= */}
        {viewTab === 'solutions' && (
          <div className="space-y-6">
            {/* Quick Stat Bar */}
            <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-4 flex flex-wrap items-center justify-between gap-4">
              <div className="flex items-center gap-4 flex-wrap">
                <div className="flex items-center gap-2">
                  <span className="text-xs text-slate-400">Score:</span>
                  <span className="text-base font-extrabold text-amber-400">
                    {attempt.score} / {attempt.maxScore}
                  </span>
                </div>
                <div className="h-4 w-px bg-slate-800 hidden sm:block" />
                <div className="flex items-center gap-2">
                  <span className="text-xs text-slate-400">Accuracy:</span>
                  <span className="text-sm font-extrabold text-emerald-400">
                    {attempt.accuracy}%
                  </span>
                </div>
                <div className="h-4 w-px bg-slate-800 hidden sm:block" />
                <div className="flex items-center gap-2 text-xs">
                  <span className="text-emerald-400 font-bold">{attempt.correctCount} Correct</span>
                  <span>•</span>
                  <span className="text-rose-400 font-bold">{attempt.incorrectCount} Incorrect</span>
                  <span>•</span>
                  <span className="text-slate-400">{attempt.unattemptedCount} Skipped</span>
                </div>
              </div>

              {/* Solution Notice */}
              <div className="flex items-center gap-2 text-xs text-indigo-300 bg-indigo-950/40 border border-indigo-500/20 px-3 py-1.5 rounded-xl">
                <Sparkles className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                <span>Serial Faculty Solutions with Step Derivations & Diagrams</span>
              </div>
            </div>

            {/* Filters & Serial Question Navigator Palette */}
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4">
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 pb-3 border-b border-slate-800 mb-3">
                <div className="flex items-center gap-2 flex-wrap">
                  <span className="text-xs font-bold text-slate-300 flex items-center gap-1.5">
                    <Filter className="w-3.5 h-3.5 text-amber-400" />
                    <span>Filter Questions:</span>
                  </span>
                  {(['all', 'incorrect', 'correct', 'unattempted'] as const).map((mode) => (
                    <button
                      key={mode}
                      onClick={() => {
                        setActiveFilter(mode);
                        setFocusedQuestionIndex(0);
                      }}
                      className={`text-xs px-2.5 py-1 rounded-lg font-semibold transition-all ${
                        activeFilter === mode
                          ? mode === 'incorrect'
                            ? 'bg-rose-500 text-white font-bold'
                            : mode === 'correct'
                            ? 'bg-emerald-600 text-white font-bold'
                            : 'bg-indigo-600 text-white font-bold'
                          : 'bg-slate-800 text-slate-400 hover:text-white'
                      }`}
                    >
                      {mode === 'all' && `All (${test.questions.length})`}
                      {mode === 'incorrect' && `Wrong Answers (${attempt.incorrectCount})`}
                      {mode === 'correct' && `Correct (${attempt.correctCount})`}
                      {mode === 'unattempted' && `Skipped (${attempt.unattemptedCount})`}
                    </button>
                  ))}
                </div>

                {/* Section filter */}
                <div className="flex items-center gap-2">
                  <span className="text-xs text-slate-400 font-semibold">Subject:</span>
                  <select
                    value={selectedSection}
                    onChange={(e) => {
                      setSelectedSection(e.target.value);
                      setFocusedQuestionIndex(0);
                    }}
                    className="bg-slate-950 border border-slate-700 text-xs text-slate-200 rounded-lg px-2.5 py-1 focus:outline-none focus:border-indigo-500"
                  >
                    <option value="All">All Subjects ({test.questions.length})</option>
                    {test.sections.map((sec) => (
                      <option key={sec} value={sec}>
                        {sec} ({test.questions.filter((q) => q.section === sec).length})
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              {/* Serial Question Quick Jump Palette */}
              <div>
                <span className="text-[11px] font-bold text-slate-400 block mb-2 uppercase tracking-wider">
                  Jump to Serial Question Solution:
                </span>
                <div className="flex flex-wrap gap-1.5 max-h-28 overflow-y-auto pr-1">
                  {test.questions.map((q, idx) => {
                    const qResp = attempt.responses[q.id];
                    const isAtt =
                      qResp &&
                      (qResp.state === 'answered' || qResp.state === 'answered_and_marked') &&
                      qResp.selectedOption;
                    const isCorr =
                      isAtt &&
                      String(qResp?.selectedOption).trim().toUpperCase() ===
                        String(q.correctAnswer).trim().toUpperCase();

                    const isCurrent = currentFocusedQuestion?.id === q.id;

                    let btnStyle = 'bg-slate-800 text-slate-400 border-slate-700 hover:border-slate-500';
                    if (isCorr) {
                      btnStyle = 'bg-emerald-950/60 text-emerald-300 border-emerald-500/40 hover:bg-emerald-900/60';
                    } else if (isAtt) {
                      btnStyle = 'bg-rose-950/60 text-rose-300 border-rose-500/40 hover:bg-rose-900/60';
                    }

                    if (isCurrent) {
                      btnStyle += ' ring-2 ring-amber-400 font-black scale-105';
                    }

                    return (
                      <button
                        key={q.id}
                        onClick={() => handleOpenQuestionSolution(q.id)}
                        className={`w-8 h-8 rounded-lg text-xs font-bold border transition-all flex items-center justify-center ${btnStyle}`}
                        title={`Q${idx + 1} (${q.section}) - ${
                          isCorr ? 'Correct' : isAtt ? 'Incorrect' : 'Unattempted'
                        }`}
                      >
                        {idx + 1}
                      </button>
                    );
                  })}
                </div>
              </div>
            </div>

            {/* Focused Serial Question & Complete Solution Presentation */}
            {filteredQuestions.length === 0 ? (
              <div className="bg-slate-900 border border-slate-800 rounded-3xl p-12 text-center text-slate-400">
                <AlertCircle className="w-10 h-10 text-slate-600 mx-auto mb-3" />
                <p className="text-sm">No questions match the selected filter criteria.</p>
                <button
                  onClick={() => {
                    setActiveFilter('all');
                    setSelectedSection('All');
                  }}
                  className="mt-3 px-4 py-1.5 rounded-lg bg-indigo-600 text-white text-xs font-bold"
                >
                  Reset Filters
                </button>
              </div>
            ) : currentFocusedQuestion ? (
              <div className="bg-slate-900/90 border border-slate-800 rounded-3xl p-6 sm:p-8 shadow-2xl space-y-6">
                {/* Header of focused question */}
                <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-4 border-b border-slate-800 gap-3">
                  <div className="flex items-center gap-3">
                    <span className="w-10 h-10 rounded-2xl bg-amber-500 text-slate-950 font-black text-base flex items-center justify-center shadow-md shadow-amber-500/20">
                      Q{currentFocusedGlobalNum}
                    </span>
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-extrabold text-amber-400">
                          {currentFocusedQuestion.section}
                        </span>
                        <span className="text-slate-500">•</span>
                        <span className="text-[11px] font-mono text-slate-400">
                          {currentFocusedQuestion.type === 'mcq'
                            ? 'MCQ Single Correct'
                            : 'Numerical Value Question'}
                        </span>
                      </div>
                      <span className="text-[11px] text-slate-400">
                        Marks Scheme: +{currentFocusedQuestion.positiveMarks} / -
                        {currentFocusedQuestion.negativeMarks}
                      </span>
                    </div>
                  </div>

                  {/* Status Indicator */}
                  <div className="flex items-center gap-2">
                    {isCurrentCorrect ? (
                      <span className="px-3 py-1 rounded-full text-xs font-bold bg-emerald-500/15 text-emerald-400 border border-emerald-500/30 flex items-center gap-1.5">
                        <CheckCircle2 className="w-4 h-4" />
                        <span>Your Answer: Correct (+{currentFocusedQuestion.positiveMarks})</span>
                      </span>
                    ) : isCurrentAttempted ? (
                      <span className="px-3 py-1 rounded-full text-xs font-bold bg-rose-500/15 text-rose-400 border border-rose-500/30 flex items-center gap-1.5">
                        <XCircle className="w-4 h-4" />
                        <span>Your Answer: Incorrect (-{currentFocusedQuestion.negativeMarks})</span>
                      </span>
                    ) : (
                      <span className="px-3 py-1 rounded-full text-xs font-bold bg-slate-800 text-slate-400 border border-slate-700">
                        Unattempted (0 Marks)
                      </span>
                    )}
                  </div>
                </div>

                {/* Question Text */}
                <div className="space-y-4">
                  <div className="text-base sm:text-lg font-medium text-slate-100 leading-relaxed">
                    {currentFocusedQuestion.text}
                  </div>

                  {/* Question Diagram / Image if exists */}
                  {currentFocusedQuestion.imageUrl && (
                    <div className="p-3 bg-slate-950 border border-slate-800 rounded-2xl max-w-xl mx-auto shadow-inner">
                      <div className="flex items-center justify-between text-xs text-slate-400 mb-2 px-1">
                        <span className="flex items-center gap-1">
                          <ImageIcon className="w-3.5 h-3.5 text-indigo-400" />
                          Question Diagram
                        </span>
                        <button
                          onClick={() => setSolutionImageLightbox(currentFocusedQuestion.imageUrl || null)}
                          className="text-[11px] text-indigo-400 hover:text-indigo-300 flex items-center gap-1 font-semibold"
                        >
                          <Maximize2 className="w-3 h-3" />
                          Expand
                        </button>
                      </div>
                      <img
                        src={currentFocusedQuestion.imageUrl}
                        alt="Question Diagram"
                        className="max-h-72 object-contain mx-auto rounded-lg cursor-pointer hover:opacity-95"
                        onClick={() => setSolutionImageLightbox(currentFocusedQuestion.imageUrl || null)}
                      />
                    </div>
                  )}

                  {/* Options Comparison (MCQ) */}
                  {currentFocusedQuestion.type === 'mcq' && (
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
                      {currentFocusedQuestion.options.map((opt) => {
                        const isOfficialKey = String(currentFocusedQuestion.correctAnswer) === opt.key;
                        const isStudentChoice = String(currentFocusedResp?.selectedOption) === opt.key;

                        let style = 'bg-slate-950/60 border-slate-800 text-slate-300';
                        if (isOfficialKey) {
                          style =
                            'bg-emerald-950/40 border-emerald-500/50 text-emerald-200 font-bold shadow-sm shadow-emerald-950/50';
                        } else if (isStudentChoice && !isCurrentCorrect) {
                          style =
                            'bg-rose-950/40 border-rose-500/50 text-rose-300 line-through';
                        }

                        return (
                          <div
                            key={opt.key}
                            className={`p-3.5 rounded-xl border flex items-center justify-between gap-3 text-xs sm:text-sm ${style}`}
                          >
                            <div className="flex items-center gap-2.5">
                              <span
                                className={`w-6 h-6 rounded-md font-bold flex items-center justify-center text-xs shrink-0 ${
                                  isOfficialKey
                                    ? 'bg-emerald-500 text-slate-950'
                                    : isStudentChoice
                                    ? 'bg-rose-500 text-white'
                                    : 'bg-slate-800 text-slate-400'
                                }`}
                              >
                                {opt.key}
                              </span>
                              <span>{opt.text}</span>
                            </div>

                            <div className="shrink-0 flex items-center gap-1.5">
                              {isOfficialKey && (
                                <span className="text-[10px] bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 px-2 py-0.5 rounded-md font-bold flex items-center gap-1">
                                  <CheckCircle2 className="w-3 h-3" />
                                  Official Key
                                </span>
                              )}
                              {isStudentChoice && !isOfficialKey && (
                                <span className="text-[10px] bg-rose-500/20 text-rose-400 border border-rose-500/30 px-2 py-0.5 rounded-md font-bold flex items-center gap-1">
                                  <XCircle className="w-3 h-3" />
                                  Your Answer
                                </span>
                              )}
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  )}

                  {/* Numerical Value Comparison */}
                  {currentFocusedQuestion.type === 'numerical' && (
                    <div className="p-4 bg-slate-950 border border-slate-800 rounded-2xl grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs sm:text-sm">
                      <div className="p-3 rounded-xl bg-slate-900 border border-slate-800">
                        <span className="text-slate-400 block text-xs mb-1">Your Submitted Value:</span>
                        <span
                          className={`font-mono font-bold text-lg ${
                            isCurrentCorrect ? 'text-emerald-400' : 'text-rose-400'
                          }`}
                        >
                          {currentFocusedResp?.selectedOption || 'None (Unattempted)'}
                        </span>
                      </div>
                      <div className="p-3 rounded-xl bg-emerald-950/20 border border-emerald-500/30">
                        <span className="text-emerald-400 block text-xs mb-1 font-bold">
                          Official Faculty Answer Key:
                        </span>
                        <span className="font-mono font-black text-lg text-emerald-300">
                          {currentFocusedQuestion.correctAnswer}
                        </span>
                      </div>
                    </div>
                  )}
                </div>

                {/* ========================================================================= */}
                {/* DEDICATED SOLUTION SECTION OF QUESTION (IN IMAGE & DERIVATION FORM)       */}
                {/* ========================================================================= */}
                <div className="border-t border-slate-800 pt-6 mt-6">
                  <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center gap-2">
                      <span className="w-8 h-8 rounded-xl bg-indigo-600/30 border border-indigo-500/40 text-indigo-400 flex items-center justify-center">
                        <Sparkles className="w-4 h-4 text-amber-400" />
                      </span>
                      <div>
                        <h4 className="text-sm sm:text-base font-extrabold text-white">
                          Faculty Solution & Step Derivation Section
                        </h4>
                        <p className="text-[11px] text-slate-400">
                          Authored by Senior Faculty for Question #{currentFocusedGlobalNum}
                        </p>
                      </div>
                    </div>

                    <span className="text-xs font-bold px-2.5 py-1 rounded-lg bg-amber-500/10 border border-amber-500/30 text-amber-300">
                      Correct Key: {currentFocusedQuestion.correctAnswer}
                    </span>
                  </div>

                  {/* Solution in Image Form (Given by faculty or high-res diagram) */}
                  {currentFocusedQuestion.explanationImageUrl ? (
                    <div className="mb-5 p-4 bg-slate-950 border border-indigo-500/30 rounded-2xl">
                      <div className="flex items-center justify-between text-xs text-indigo-300 font-bold mb-3 px-1">
                        <span className="flex items-center gap-1.5">
                          <ImageIcon className="w-4 h-4 text-amber-400" />
                          Faculty Handwritten / Diagrammatic Solution Sheet (Image Form)
                        </span>
                        <button
                          onClick={() => setSolutionImageLightbox(currentFocusedQuestion.explanationImageUrl || null)}
                          className="px-2.5 py-1 rounded-lg bg-indigo-600/30 hover:bg-indigo-600/50 text-indigo-200 border border-indigo-500/40 text-xs font-semibold flex items-center gap-1 transition-all"
                        >
                          <Maximize2 className="w-3 h-3" />
                          <span>Fullscreen Lightbox</span>
                        </button>
                      </div>

                      <div className="relative group flex justify-center bg-slate-900/80 rounded-xl p-2 border border-slate-800">
                        <img
                          src={currentFocusedQuestion.explanationImageUrl}
                          alt={`Solution to Question ${currentFocusedGlobalNum}`}
                          className="max-h-96 w-auto object-contain rounded-lg shadow-xl cursor-zoom-in transition-transform group-hover:scale-[1.01]"
                          onClick={() => setSolutionImageLightbox(currentFocusedQuestion.explanationImageUrl || null)}
                        />
                      </div>
                      <p className="text-[11px] text-slate-400 text-center mt-2">
                        Click on the image above to view full high-resolution derivation diagram.
                      </p>
                    </div>
                  ) : (
                    /* Stylized Digital Pedagogical Whiteboard Derivation Card when no custom image uploaded */
                    <div className="mb-5 p-5 bg-gradient-to-br from-slate-950 to-indigo-950/40 border border-indigo-500/30 rounded-2xl shadow-xl">
                      <div className="flex items-center justify-between text-xs font-bold text-amber-400 mb-2">
                        <span className="flex items-center gap-1.5">
                          <BookOpen className="w-4 h-4 text-indigo-400" />
                          Concept & Mathematical Roadmap
                        </span>
                        <span className="font-mono text-emerald-400 bg-emerald-950/60 border border-emerald-500/30 px-2 py-0.5 rounded text-[11px]">
                          Key: {currentFocusedQuestion.correctAnswer}
                        </span>
                      </div>
                      <div className="font-mono text-xs sm:text-sm text-slate-200 p-4 rounded-xl bg-slate-950/90 border border-slate-800 leading-relaxed whitespace-pre-line shadow-inner">
                        {currentFocusedQuestion.explanation}
                      </div>
                    </div>
                  )}

                  {/* Detailed Text Derivation if separate image was shown */}
                  {currentFocusedQuestion.explanationImageUrl && currentFocusedQuestion.explanation && (
                    <div className="p-4 rounded-2xl bg-indigo-950/20 border border-indigo-500/20 text-xs sm:text-sm">
                      <h5 className="font-bold text-indigo-300 mb-1 flex items-center gap-1.5">
                        <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                        <span>Key Theoretical Takeaways & Formula Derivation:</span>
                      </h5>
                      <p className="text-slate-300 leading-relaxed">
                        {currentFocusedQuestion.explanation}
                      </p>
                    </div>
                  )}
                </div>

                {/* Question Navigation Controls (Previous / Next) */}
                <div className="flex items-center justify-between pt-4 border-t border-slate-800">
                  <button
                    disabled={focusedQuestionIndex === 0}
                    onClick={() => setFocusedQuestionIndex((prev) => Math.max(0, prev - 1))}
                    className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 disabled:opacity-40 disabled:cursor-not-allowed text-slate-200 font-bold text-xs flex items-center gap-1.5 transition-all"
                  >
                    <ChevronLeft className="w-4 h-4" />
                    <span>Previous Question</span>
                  </button>

                  <span className="text-xs text-slate-400 font-semibold">
                    Question {focusedQuestionIndex + 1} of {filteredQuestions.length}
                  </span>

                  <button
                    disabled={focusedQuestionIndex >= filteredQuestions.length - 1}
                    onClick={() =>
                      setFocusedQuestionIndex((prev) =>
                        Math.min(filteredQuestions.length - 1, prev + 1)
                      )
                    }
                    className="px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 disabled:opacity-40 disabled:cursor-not-allowed text-white font-bold text-xs flex items-center gap-1.5 transition-all shadow-md shadow-indigo-600/20"
                  >
                    <span>Next Question</span>
                    <ChevronRight className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ) : null}
          </div>
        )}

        {/* ========================================================================= */}
        {/* TAB 2: COMPREHENSIVE SCORECARD & ANALYTICS                                */}
        {/* ========================================================================= */}
        {viewTab === 'analytics' && (
          <div className="space-y-8">
            {/* Overall Score Summary Cards */}
            <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
              {/* Card 1: Score */}
              <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-lg flex flex-col justify-between">
                <div className="flex items-center justify-between text-slate-400 text-xs font-semibold">
                  <span>Total Marks</span>
                  <Trophy className="w-4 h-4 text-amber-400" />
                </div>
                <div className="mt-2">
                  <span className="text-3xl font-black text-amber-400">{attempt.score}</span>
                  <span className="text-xs text-slate-400"> / {attempt.maxScore}</span>
                </div>
                <p className="text-[11px] text-slate-400 mt-2">
                  {Math.round((attempt.score / (attempt.maxScore || 1)) * 100)}% Marks Scored
                </p>
              </div>

              {/* Card 2: Accuracy */}
              <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-lg flex flex-col justify-between">
                <div className="flex items-center justify-between text-slate-400 text-xs font-semibold">
                  <span>Accuracy</span>
                  <Target className="w-4 h-4 text-emerald-400" />
                </div>
                <div className="mt-2">
                  <span className="text-3xl font-black text-emerald-400">
                    {attempt.accuracy}%
                  </span>
                </div>
                <p className="text-[11px] text-slate-400 mt-2">
                  {attempt.correctCount} of {attempt.correctCount + attempt.incorrectCount} correct
                </p>
              </div>

              {/* Card 3: Correct */}
              <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-lg flex flex-col justify-between">
                <div className="flex items-center justify-between text-slate-400 text-xs font-semibold">
                  <span>Correct</span>
                  <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                </div>
                <div className="mt-2">
                  <span className="text-3xl font-black text-white">{attempt.correctCount}</span>
                  <span className="text-xs text-slate-400"> / {test.questions.length}</span>
                </div>
                <p className="text-[11px] text-emerald-400 font-semibold mt-2">
                  +{attempt.correctCount * 4} Marks Gained
                </p>
              </div>

              {/* Card 4: Negative */}
              <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-lg flex flex-col justify-between">
                <div className="flex items-center justify-between text-slate-400 text-xs font-semibold">
                  <span>Incorrect</span>
                  <XCircle className="w-4 h-4 text-rose-400" />
                </div>
                <div className="mt-2">
                  <span className="text-3xl font-black text-rose-400">
                    {attempt.incorrectCount}
                  </span>
                  <span className="text-xs text-slate-400"> questions</span>
                </div>
                <p className="text-[11px] text-rose-400 font-semibold mt-2">
                  -{attempt.incorrectCount * 1} Negative Marks
                </p>
              </div>

              {/* Card 5: Time Spent */}
              <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-lg flex flex-col justify-between col-span-2 md:col-span-1">
                <div className="flex items-center justify-between text-slate-400 text-xs font-semibold">
                  <span>Time Taken</span>
                  <Clock className="w-4 h-4 text-indigo-400" />
                </div>
                <div className="mt-2">
                  <span className="text-3xl font-black text-white">
                    {Math.floor(attempt.timeSpentSeconds / 60)}
                  </span>
                  <span className="text-xs text-slate-400">m {attempt.timeSpentSeconds % 60}s</span>
                </div>
                <p className="text-[11px] text-slate-400 mt-2">
                  Allowed: {test.durationMinutes} mins
                </p>
              </div>
            </div>

            {/* Section-Wise Breakdown Cards */}
            <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-8">
              <h3 className="text-base sm:text-lg font-black text-white mb-4 flex items-center gap-2">
                <BarChart2 className="w-5 h-5 text-indigo-400" />
                <span>Subject-Wise Performance Breakdown</span>
              </h3>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                {Object.entries(attempt.sectionScores || {}).map(([secName, secData]) => (
                  <div
                    key={secName}
                    className="p-4 bg-slate-950 border border-slate-800 rounded-2xl space-y-3"
                  >
                    <div className="flex items-center justify-between">
                      <span className="text-sm font-bold text-white">{secName}</span>
                      <span className="text-xs font-bold px-2 py-0.5 rounded bg-indigo-500/20 text-indigo-300 font-mono">
                        {secData.score} / {secData.maxScore}
                      </span>
                    </div>

                    <div className="w-full bg-slate-800 h-2 rounded-full overflow-hidden">
                      <div
                        className="bg-gradient-to-r from-amber-500 to-emerald-500 h-full rounded-full transition-all"
                        style={{
                          width: `${Math.max(
                            0,
                            Math.min(100, (secData.score / (secData.maxScore || 1)) * 100)
                          )}%`,
                        }}
                      />
                    </div>

                    <div className="flex items-center justify-between text-xs text-slate-400">
                      <span className="text-emerald-400">{secData.correct} Correct</span>
                      <span className="text-rose-400">{secData.incorrect} Incorrect</span>
                      <span>{secData.unattempted} Skipped</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Question Response Matrix Palette */}
            <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-8">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-4">
                <div>
                  <h3 className="text-base sm:text-lg font-black text-white flex items-center gap-2">
                    <Layers className="w-5 h-5 text-amber-400" />
                    <span>Question Response Palette</span>
                  </h3>
                  <p className="text-xs text-slate-400 mt-0.5">
                    Click any question bubble below to jump directly into its full step derivation solution.
                  </p>
                </div>

                <div className="flex items-center gap-3 text-xs flex-wrap">
                  <div className="flex items-center gap-1.5">
                    <span className="w-3 h-3 rounded-full bg-emerald-500" />
                    <span className="text-slate-300">Correct ({attempt.correctCount})</span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <span className="w-3 h-3 rounded-full bg-rose-500" />
                    <span className="text-slate-300">Incorrect ({attempt.incorrectCount})</span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <span className="w-3 h-3 rounded-full bg-slate-700" />
                    <span className="text-slate-400">Skipped ({attempt.unattemptedCount})</span>
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-5 sm:grid-cols-10 md:grid-cols-15 gap-2 pt-2">
                {test.questions.map((q, idx) => {
                  const resp = attempt.responses[q.id];
                  const isAtt =
                    resp &&
                    (resp.state === 'answered' || resp.state === 'answered_and_marked') &&
                    resp.selectedOption;
                  const isCorr =
                    isAtt &&
                    String(resp?.selectedOption).trim().toUpperCase() ===
                      String(q.correctAnswer).trim().toUpperCase();

                  let bubbleColor = 'bg-slate-800 text-slate-400 border-slate-700 hover:bg-slate-700';
                  if (isCorr) {
                    bubbleColor = 'bg-emerald-600 text-white border-emerald-500 hover:bg-emerald-500';
                  } else if (isAtt) {
                    bubbleColor = 'bg-rose-600 text-white border-rose-500 hover:bg-rose-500';
                  }

                  return (
                    <button
                      key={q.id}
                      onClick={() => handleOpenQuestionSolution(q.id)}
                      className={`h-9 rounded-xl border text-xs font-bold transition-transform hover:scale-110 flex items-center justify-center ${bubbleColor}`}
                      title={`Q${idx + 1}: Click to view faculty solution`}
                    >
                      {idx + 1}
                    </button>
                  );
                })}
              </div>

              <div className="mt-6 text-center">
                <button
                  onClick={() => setViewTab('solutions')}
                  className="px-6 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-extrabold text-xs shadow-lg shadow-amber-500/20 transition-all inline-flex items-center gap-2"
                >
                  <BookOpen className="w-4 h-4" />
                  <span>Open Full Serial Solution Section (Image Form) →</span>
                </button>
              </div>
            </div>
          </div>
        )}
      </main>

      {/* Lightbox Modal for High-Resolution Solution Image */}
      {solutionImageLightbox && (
        <div
          className="fixed inset-0 z-50 bg-black/95 backdrop-blur-md flex flex-col items-center justify-center p-4"
          onClick={() => setSolutionImageLightbox(null)}
        >
          <div className="absolute top-4 right-4 flex items-center gap-3">
            <span className="text-xs text-slate-300">Click anywhere to close</span>
            <button
              onClick={() => setSolutionImageLightbox(null)}
              className="p-2 rounded-full bg-slate-800 hover:bg-slate-700 text-white transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
          <img
            src={solutionImageLightbox}
            alt="High-resolution Solution Diagram"
            className="max-h-[90vh] max-w-[95vw] object-contain rounded-xl shadow-2xl border border-slate-700"
            onClick={(e) => e.stopPropagation()}
          />
        </div>
      )}
    </div>
  );
};
