import React, { useState, useRef } from 'react';
import { useApp } from '../context/AppContext.tsx';
import type {
  SubjectSection,
  QuestionType,
  Question,
  Test,
} from '../types/index.ts';
import {
  DIAGRAM_OPTICS,
  DIAGRAM_CIRCUIT,
  DIAGRAM_GENETICS,
} from '../data/seedData.ts';
import {
  Image as ImageIcon,
  Upload,
  Plus,
  Trash2,
  CheckCircle2,
  ArrowRight,
  ArrowLeft,
  Sparkles,
  BookOpen,
  Layers,
  Check,
  Eye,
  X,
  FileSpreadsheet,
  AlertCircle,
  HelpCircle,
  Zap,
} from 'lucide-react';

interface SerialImagePaperBuilderProps {
  selectedTestId: string;
  onSelectTestId: (id: string) => void;
}

// Preset scientific diagrams for instant faculty prototyping
const SAMPLE_DIAGRAM_PRESETS: { label: string; section: SubjectSection; url: string; correct: string }[] = [
  {
    label: 'Ray Optics Lens Prism (Physics)',
    section: 'Physics',
    url: DIAGRAM_OPTICS,
    correct: 'B',
  },
  {
    label: 'Wheatstone Circuit & Galvanometer (Physics)',
    section: 'Physics',
    url: DIAGRAM_CIRCUIT,
    correct: 'C',
  },
  {
    label: 'Organic Esterification & Aldol (Chemistry)',
    section: 'Chemistry',
    url: 'https://images.unsplash.com/photo-1532187863486-abf9dbad1b69?auto=format&fit=crop&w=600&q=80',
    correct: 'A',
  },
  {
    label: 'Pedigree Genetics & Mendelian Chart (Biology)',
    section: 'Biology',
    url: DIAGRAM_GENETICS,
    correct: 'A',
  },
  {
    label: 'Conic Sections & Parabola Locus (Maths)',
    section: 'Mathematics',
    url: 'https://images.unsplash.com/photo-1635070041078-e363dbe005cb?auto=format&fit=crop&w=600&q=80',
    correct: 'D',
  },
];

export const SerialImagePaperBuilder: React.FC<SerialImagePaperBuilderProps> = ({
  selectedTestId,
  onSelectTestId,
}) => {
  const { tests, addQuestion, updateQuestion, deleteQuestion, batchAddQuestions, saveTestToCloud } = useApp();

  const currentTest = tests.find((t) => t.id === selectedTestId) || tests[0];

  // Active section for serial entry
  const [activeSection, setActiveSection] = useState<SubjectSection>('Physics');

  // Question Type
  const [qType, setQType] = useState<QuestionType>('mcq');

  // Serial state for current question being composed
  const [currentImage, setCurrentImage] = useState<string>('');
  const [solutionImage, setSolutionImage] = useState<string>('');
  const [currentCorrectAnswer, setCurrentCorrectAnswer] = useState<string>('A');
  const [positiveMarks, setPositiveMarks] = useState<number>(4);
  const [negativeMarks, setNegativeMarks] = useState<number>(1);
  const [customText, setCustomText] = useState<string>('');
  const [explanationText, setExplanationText] = useState<string>('');
  const [previewZoomModal, setPreviewZoomModal] = useState<string | null>(null);
  const [lastActionToast, setLastActionToast] = useState<string | null>(null);
  const [isCloudSaving, setIsCloudSaving] = useState<boolean>(false);

  // File input ref for single image upload
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const solutionFileInputRef = useRef<HTMLInputElement | null>(null);
  // File input ref for multi-file serial upload
  const bulkFileInputRef = useRef<HTMLInputElement | null>(null);

  // Filter questions of the current test by the active section
  const sectionQuestions = (currentTest?.questions || []).filter(
    (q) => q.section === activeSection
  );

  // Calculate next serial number in this section
  const nextSerialInSec = sectionQuestions.length + 1;
  const overallTotalQCount = currentTest?.questions?.length || 0;

  // Handle single image file upload
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (!file.type.startsWith('image/')) {
        alert('Please select a valid image file (PNG, JPG, JPEG, WEBP).');
        return;
      }
      const reader = new FileReader();
      reader.onload = (event) => {
        if (event.target?.result) {
          setCurrentImage(event.target.result as string);
        }
      };
      reader.readAsDataURL(file);
    }
  };

  // Handle bulk multi-file serial upload (e.g. Q1.png, Q2.png, Q3.png)
  const handleBulkFilesSelected = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0 || !currentTest) return;

    const fileList = Array.from(files).filter((f) => f.type.startsWith('image/'));
    // Sort naturally by filename so Q1, Q2, Q3 or 01, 02, 03 are in order
    fileList.sort((a, b) =>
      a.name.localeCompare(b.name, undefined, { numeric: true, sensitivity: 'base' })
    );

    const questionsToAdd: Question[] = [];
    let currentStartIndex = sectionQuestions.length;

    for (let i = 0; i < fileList.length; i++) {
      const file = fileList[i];
      const dataUrl = await new Promise<string>((resolve) => {
        const reader = new FileReader();
        reader.onload = (ev) => resolve(ev.target?.result as string);
        reader.readAsDataURL(file);
      });

      const qNum = currentStartIndex + i + 1;
      questionsToAdd.push({
        id: `q-serial-${Date.now()}-${i}-${Math.floor(Math.random() * 1000)}`,
        section: activeSection,
        type: 'mcq',
        text: `Q${qNum} [${activeSection}]: Refer to the problem image below.`,
        imageUrl: dataUrl,
        options: [
          { key: 'A', text: 'Option (A)' },
          { key: 'B', text: 'Option (B)' },
          { key: 'C', text: 'Option (C)' },
          { key: 'D', text: 'Option (D)' },
        ],
        correctAnswer: 'A',
        positiveMarks: 4,
        negativeMarks: 1,
        explanation: `Solution for Question ${qNum} in ${activeSection}.`,
      });
    }

    batchAddQuestions(currentTest.id, questionsToAdd);
    setLastActionToast(
      `Successfully added ${questionsToAdd.length} serial question images to ${activeSection}!`
    );
    setTimeout(() => setLastActionToast(null), 5000);

    // Reset file input
    if (bulkFileInputRef.current) bulkFileInputRef.current.value = '';
  };

  // Save current question and advance to next serial number
  const handleSaveAndNext = (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentTest) return;

    if (!currentImage.trim() && !customText.trim()) {
      alert('Please upload an image or provide question text for this serial number.');
      return;
    }

    const qNum = nextSerialInSec;
    const qTitle = customText.trim()
      ? customText.trim()
      : `Q${qNum} [${activeSection}]: Refer to the question image below.`;

    const newQ: Omit<Question, 'id'> = {
      section: activeSection,
      type: qType,
      text: qTitle,
      imageUrl: currentImage.trim() || undefined,
      explanationImageUrl: solutionImage.trim() || undefined,
      options:
        qType === 'mcq'
          ? [
              { key: 'A', text: 'Option (A)' },
              { key: 'B', text: 'Option (B)' },
              { key: 'C', text: 'Option (C)' },
              { key: 'D', text: 'Option (D)' },
            ]
          : [],
      correctAnswer: currentCorrectAnswer,
      positiveMarks,
      negativeMarks: qType === 'numerical' ? 0 : negativeMarks,
      explanation:
        explanationText.trim() ||
        `Official explanation for Question ${qNum} (${activeSection}).`,
    };

    addQuestion(currentTest.id, newQ);

    setLastActionToast(
      `Saved Q${qNum} in ${activeSection}! Ready for Question #${qNum + 1}.`
    );
    setTimeout(() => setLastActionToast(null), 4000);

    // Clear state for next serial question
    setCurrentImage('');
    setSolutionImage('');
    setCustomText('');
    setExplanationText('');
    setCurrentCorrectAnswer('A');
    if (fileInputRef.current) fileInputRef.current.value = '';
    if (solutionFileInputRef.current) solutionFileInputRef.current.value = '';
  };

  const handleManualCloudSave = async () => {
    if (!currentTest) return;
    setIsCloudSaving(true);
    const res = await saveTestToCloud(currentTest.id);
    setIsCloudSaving(false);
    setLastActionToast(res.message);
    setTimeout(() => setLastActionToast(null), 5000);
  };

  return (
    <div className="space-y-6">
      {/* Test Paper Selector & Rapid Serial Bar */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div className="flex-1 w-full">
          <label className="block text-xs font-semibold text-slate-400 mb-1.5 flex items-center gap-1.5">
            <BookOpen className="w-4 h-4 text-amber-400" />
            Target Test Paper for Serial Image Adding:
          </label>
          <select
            value={currentTest?.id}
            onChange={(e) => onSelectTestId(e.target.value)}
            className="w-full md:max-w-md px-3.5 py-2 bg-slate-950 border border-slate-700 rounded-xl text-sm font-bold text-white focus:outline-none focus:border-amber-500"
          >
            {tests.map((t) => (
              <option key={t.id} value={t.id}>
                {t.title} ({t.examType}) — {t.questions.length} Questions ({t.totalMarks} Marks)
              </option>
            ))}
          </select>
        </div>

        {/* Multi-file batch serial shortcut & Cloud Save */}
        <div className="flex items-center gap-2.5 flex-wrap">
          <button
            type="button"
            onClick={handleManualCloudSave}
            disabled={isCloudSaving}
            className="px-4 py-2.5 bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white font-bold text-xs rounded-xl shadow-md shadow-emerald-600/20 transition-all flex items-center gap-2 shrink-0"
            title="Permanently commits this test, all questions, and answer key into Supabase Cloud"
          >
            <CheckCircle2 className="w-4 h-4 text-emerald-200" />
            <span>{isCloudSaving ? 'Saving to Supabase...' : 'Save Test to Supabase'}</span>
          </button>
          <input
            type="file"
            ref={bulkFileInputRef}
            onChange={handleBulkFilesSelected}
            multiple
            accept="image/*"
            className="hidden"
          />
          <button
            type="button"
            onClick={() => bulkFileInputRef.current?.click()}
            className="px-3.5 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold text-xs rounded-xl border border-slate-700 transition-all flex items-center gap-2 shrink-0"
            title="Select multiple images (e.g. Q1.png, Q2.png, Q3.png) to add all serially at once"
          >
            <Upload className="w-4 h-4 text-indigo-400" />
            Bulk Multi-Image Serial Upload
          </button>
        </div>
      </div>

      {/* Toast Notification */}
      {lastActionToast && (
        <div className="bg-emerald-500/15 border border-emerald-500/30 text-emerald-300 p-3.5 rounded-xl text-xs font-bold flex items-center justify-between animate-fadeIn">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 shrink-0" />
            <span>{lastActionToast}</span>
          </div>
          <button onClick={() => setLastActionToast(null)} className="p-1 hover:text-white">
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Section Switcher Tabs (Physics, Chemistry, Biology, Maths) */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-800">
          <div>
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <Zap className="w-4 h-4 text-amber-400" />
              Select Section to Add Serial Image Questions:
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">
              Switch sections to upload questions one by one with assigned images and answer keys
            </p>
          </div>
          <span className="text-xs font-semibold px-2.5 py-1 rounded-full bg-slate-800 text-slate-300 border border-slate-700">
            Total Paper Questions: <strong className="text-amber-400">{overallTotalQCount}</strong>
          </span>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mt-4">
          {(
            [
              { sec: 'Physics', icon: '⚛️', color: 'from-blue-600 to-indigo-600' },
              { sec: 'Chemistry', icon: '🧪', color: 'from-amber-600 to-orange-600' },
              { sec: 'Biology', icon: '🧬', color: 'from-emerald-600 to-teal-600' },
              { sec: 'Mathematics', icon: '📐', color: 'from-rose-600 to-pink-600' },
            ] as const
          ).map((item) => {
            const count = (currentTest?.questions || []).filter(
              (q) => q.section === item.sec
            ).length;
            const isSelected = activeSection === item.sec;

            return (
              <button
                key={item.sec}
                type="button"
                onClick={() => setActiveSection(item.sec)}
                className={`p-3 rounded-xl border text-left transition-all relative overflow-hidden ${
                  isSelected
                    ? 'bg-slate-800 border-amber-500 shadow-md shadow-amber-500/10'
                    : 'bg-slate-950/60 border-slate-800 hover:border-slate-700 text-slate-400 hover:text-white'
                }`}
              >
                <div className="flex items-center justify-between mb-1.5">
                  <span className="text-lg">{item.icon}</span>
                  <span
                    className={`text-[11px] font-bold px-2 py-0.5 rounded-full ${
                      isSelected
                        ? 'bg-amber-500 text-slate-950'
                        : 'bg-slate-800 text-slate-400'
                    }`}
                  >
                    {count} Questions
                  </span>
                </div>
                <h4
                  className={`text-sm font-extrabold ${
                    isSelected ? 'text-white' : 'text-slate-300'
                  }`}
                >
                  {item.sec}
                </h4>
                <p className="text-[10px] text-slate-400 mt-0.5">
                  Next: Question #{count + 1}
                </p>
                {isSelected && (
                  <div className="absolute bottom-0 left-0 right-0 h-1 bg-amber-500"></div>
                )}
              </button>
            );
          })}
        </div>
      </div>

      {/* Main 2-Column Serial Builder: Form (Left) & Section Grid (Right) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column (7 cols): Serial Image Upload Form for Current Question Number */}
        <div className="lg:col-span-7 bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-5">
          {/* Header of Current Question */}
          <div className="flex items-center justify-between pb-3 border-b border-slate-800">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-amber-500/20 border border-amber-500/30 flex items-center justify-center text-amber-400 font-black text-sm">
                #{nextSerialInSec}
              </div>
              <div>
                <h3 className="text-base font-extrabold text-white flex items-center gap-2">
                  <span>Adding Question #{nextSerialInSec}</span>
                  <span className="text-xs px-2 py-0.5 rounded bg-amber-500/20 text-amber-300 border border-amber-500/30 font-semibold">
                    {activeSection}
                  </span>
                </h3>
                <p className="text-xs text-slate-400">
                  Upload question image and set the correct answer key
                </p>
              </div>
            </div>

            {/* Quick Presets Dropdown */}
            <div className="relative group">
              <button
                type="button"
                className="px-2.5 py-1.5 bg-slate-800 hover:bg-slate-700 text-amber-300 border border-amber-500/30 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-colors"
              >
                <Sparkles className="w-3.5 h-3.5" />
                Sample Diagram
              </button>
              <div className="absolute right-0 mt-1 w-64 bg-slate-900 border border-slate-700 rounded-xl shadow-2xl p-2 hidden group-hover:block z-20 space-y-1">
                <p className="text-[10px] uppercase font-bold text-slate-400 px-2 py-1">
                  Click to Fill Diagram:
                </p>
                {SAMPLE_DIAGRAM_PRESETS.map((preset) => (
                  <button
                    key={preset.label}
                    type="button"
                    onClick={() => {
                      setCurrentImage(preset.url);
                      setActiveSection(preset.section);
                      setCurrentCorrectAnswer(preset.correct);
                    }}
                    className="w-full text-left p-2 rounded-lg text-xs hover:bg-slate-800 text-slate-200 transition-colors flex items-center gap-2"
                  >
                    <img
                      src={preset.url}
                      alt={preset.label}
                      className="w-7 h-7 rounded object-cover border border-slate-700"
                    />
                    <span className="truncate">{preset.label}</span>
                  </button>
                ))}
              </div>
            </div>
          </div>

          <form onSubmit={handleSaveAndNext} className="space-y-5">
            {/* 1. Image Upload Box for this Serial Question */}
            <div>
              <label className="block text-xs font-bold text-slate-200 mb-2 flex items-center justify-between">
                <span>1. Question Image (Problem Statement / Diagram / Options):</span>
                {currentImage && (
                  <button
                    type="button"
                    onClick={() => setCurrentImage('')}
                    className="text-[11px] text-rose-400 hover:underline flex items-center gap-1"
                  >
                    <Trash2 className="w-3 h-3" /> Remove Image
                  </button>
                )}
              </label>

              {currentImage ? (
                /* Image Preview Container */
                <div className="relative border border-amber-500/40 rounded-xl overflow-hidden bg-slate-950 p-2 group">
                  <img
                    src={currentImage}
                    alt={`Question ${nextSerialInSec}`}
                    className="w-full max-h-72 object-contain rounded-lg mx-auto bg-slate-900"
                  />
                  <div className="absolute top-4 right-4 flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => setPreviewZoomModal(currentImage)}
                      className="p-1.5 bg-slate-900/90 hover:bg-slate-800 text-white rounded-lg border border-slate-700 shadow"
                      title="Zoom Image"
                    >
                      <Eye className="w-4 h-4" />
                    </button>
                    <button
                      type="button"
                      onClick={() => setCurrentImage('')}
                      className="p-1.5 bg-rose-900/90 hover:bg-rose-800 text-white rounded-lg border border-rose-700 shadow"
                      title="Remove"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  </div>
                  <p className="text-center text-[11px] text-emerald-400 font-semibold mt-2 flex items-center justify-center gap-1">
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    Question Image Attached for Q#{nextSerialInSec}
                  </p>
                </div>
              ) : (
                /* Upload Drop Area */
                <div
                  onClick={() => fileInputRef.current?.click()}
                  className="border-2 border-dashed border-slate-700 hover:border-amber-500/70 bg-slate-950/70 hover:bg-slate-950 rounded-xl p-8 text-center cursor-pointer transition-all group"
                >
                  <input
                    type="file"
                    ref={fileInputRef}
                    onChange={handleFileChange}
                    accept="image/*"
                    className="hidden"
                  />
                  <div className="w-14 h-14 rounded-2xl bg-amber-500/10 border border-amber-500/30 text-amber-400 flex items-center justify-center mx-auto mb-3 group-hover:scale-105 transition-transform">
                    <Upload className="w-7 h-7" />
                  </div>
                  <h4 className="text-sm font-bold text-white group-hover:text-amber-400 transition-colors">
                    Click to Upload Question #{nextSerialInSec} Image
                  </h4>
                  <p className="text-xs text-slate-400 mt-1">
                    Upload scanned paper crop, handwritten question, or diagram (PNG, JPG, WEBP)
                  </p>
                  <p className="text-[11px] text-amber-300 font-semibold mt-3">
                    or paste image URL below
                  </p>
                </div>
              )}

              {/* Paste URL input fallback */}
              <div className="mt-2.5">
                <input
                  type="url"
                  value={currentImage}
                  onChange={(e) => setCurrentImage(e.target.value)}
                  placeholder="Or paste direct image URL (https://...)"
                  className="w-full px-3 py-1.5 bg-slate-950 border border-slate-700 rounded-lg text-xs text-white placeholder:text-slate-500 focus:outline-none focus:border-amber-500"
                />
              </div>
            </div>

            {/* 2. Question Type & Answer Key Selection */}
            <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 space-y-3">
              <div className="flex items-center justify-between">
                <label className="text-xs font-bold text-slate-200">
                  2. Select Question Type & Correct Answer Key:
                </label>
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => {
                      setQType('mcq');
                      setCurrentCorrectAnswer('A');
                    }}
                    className={`px-2.5 py-1 rounded text-xs font-semibold transition-colors ${
                      qType === 'mcq'
                        ? 'bg-amber-500 text-slate-950'
                        : 'bg-slate-800 text-slate-400'
                    }`}
                  >
                    MCQ (A/B/C/D)
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setQType('numerical');
                      setCurrentCorrectAnswer('4');
                    }}
                    className={`px-2.5 py-1 rounded text-xs font-semibold transition-colors ${
                      qType === 'numerical'
                        ? 'bg-amber-500 text-slate-950'
                        : 'bg-slate-800 text-slate-400'
                    }`}
                  >
                    Numerical Value
                  </button>
                </div>
              </div>

              {qType === 'mcq' ? (
                /* MCQ Option Keys (A, B, C, D) */
                <div>
                  <p className="text-[11px] text-slate-400 mb-2">
                    Click the correct option key corresponding to Question #{nextSerialInSec}:
                  </p>
                  <div className="grid grid-cols-4 gap-3">
                    {(['A', 'B', 'C', 'D'] as const).map((opt) => (
                      <button
                        key={opt}
                        type="button"
                        onClick={() => setCurrentCorrectAnswer(opt)}
                        className={`py-3 rounded-xl border font-black text-sm transition-all flex flex-col items-center justify-center gap-1 ${
                          currentCorrectAnswer === opt
                            ? 'bg-gradient-to-b from-amber-500 to-amber-600 text-slate-950 border-amber-400 shadow-md shadow-amber-500/20 scale-102'
                            : 'bg-slate-900 border-slate-700 text-slate-300 hover:bg-slate-800 hover:text-white'
                        }`}
                      >
                        <span>({opt})</span>
                        <span className="text-[10px] font-bold opacity-80">
                          {currentCorrectAnswer === opt ? '✓ Correct Key' : 'Option'}
                        </span>
                      </button>
                    ))}
                  </div>
                </div>
              ) : (
                /* Numerical value input */
                <div>
                  <p className="text-[11px] text-slate-400 mb-2">
                    Enter the exact integer or decimal numerical value:
                  </p>
                  <input
                    type="text"
                    value={currentCorrectAnswer}
                    onChange={(e) => setCurrentCorrectAnswer(e.target.value)}
                    placeholder="e.g. 24 or 3.14"
                    className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-lg text-sm font-mono text-white focus:outline-none focus:border-amber-500"
                  />
                </div>
              )}
            </div>

            {/* 3. Marking Scheme & Optional Subtext */}
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Positive Marks (+):
                </label>
                <input
                  type="number"
                  value={positiveMarks}
                  onChange={(e) => setPositiveMarks(Number(e.target.value))}
                  className="w-full px-3 py-1.5 bg-slate-950 border border-slate-700 rounded-lg text-xs text-white"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Negative Marks (-):
                </label>
                <input
                  type="number"
                  value={negativeMarks}
                  onChange={(e) => setNegativeMarks(Number(e.target.value))}
                  disabled={qType === 'numerical'}
                  className="w-full px-3 py-1.5 bg-slate-950 border border-slate-700 rounded-lg text-xs text-white disabled:opacity-50"
                />
              </div>
            </div>

            {/* Optional text or equation note */}
            <div>
              <label className="block text-xs font-semibold text-slate-400 mb-1">
                Optional Question Caption / Context (Optional):
              </label>
              <input
                type="text"
                value={customText}
                onChange={(e) => setCustomText(e.target.value)}
                placeholder={`Default: Q${nextSerialInSec} [${activeSection}]: Refer to the problem image`}
                className="w-full px-3 py-1.5 bg-slate-950 border border-slate-700 rounded-lg text-xs text-white placeholder:text-slate-500 focus:outline-none focus:border-amber-500"
              />
            </div>

            {/* Faculty Solution in Image Form (Handwritten / Diagram) & Step Derivation */}
            <div className="p-4 rounded-xl bg-indigo-950/20 border border-indigo-500/20 space-y-3">
              <div className="flex items-center justify-between">
                <label className="text-xs font-bold text-indigo-300 flex items-center gap-1.5">
                  <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                  <span>Faculty Solution in Image Form (Handwritten / Diagram Derivation):</span>
                </label>
                {solutionImage && (
                  <button
                    type="button"
                    onClick={() => setSolutionImage('')}
                    className="text-[11px] text-rose-400 hover:underline flex items-center gap-1"
                  >
                    <Trash2 className="w-3 h-3" /> Remove Solution Image
                  </button>
                )}
              </div>

              {solutionImage ? (
                <div className="relative border border-indigo-500/40 rounded-xl overflow-hidden bg-slate-950 p-2">
                  <img
                    src={solutionImage}
                    alt="Solution Derivation"
                    className="w-full max-h-56 object-contain rounded-lg mx-auto bg-slate-900"
                  />
                </div>
              ) : (
                <div className="flex items-center gap-2">
                  <input
                    type="file"
                    ref={solutionFileInputRef}
                    accept="image/*"
                    className="hidden"
                    onChange={(e) => {
                      const file = e.target.files?.[0];
                      if (file) {
                        const reader = new FileReader();
                        reader.onload = (ev) => {
                          if (ev.target?.result) setSolutionImage(ev.target.result as string);
                        };
                        reader.readAsDataURL(file);
                      }
                    }}
                  />
                  <button
                    type="button"
                    onClick={() => solutionFileInputRef.current?.click()}
                    className="px-3 py-2 bg-indigo-600/30 hover:bg-indigo-600/50 text-indigo-200 border border-indigo-500/40 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-all shrink-0"
                  >
                    <Upload className="w-3.5 h-3.5" />
                    Upload Solution Image / Diagram
                  </button>
                  <input
                    type="text"
                    value={solutionImage}
                    onChange={(e) => setSolutionImage(e.target.value)}
                    placeholder="or paste solution image URL..."
                    className="flex-1 px-3 py-1.5 bg-slate-950 border border-slate-700 rounded-lg text-xs text-white placeholder:text-slate-500"
                  />
                </div>
              )}

              <div>
                <label className="block text-[11px] font-semibold text-slate-400 mb-1">
                  Step-by-Step Derivation & Explanation Text:
                </label>
                <textarea
                  value={explanationText}
                  onChange={(e) => setExplanationText(e.target.value)}
                  rows={2}
                  placeholder={`Detailed steps, formula substitution, and conceptual explanation for Question #${nextSerialInSec}...`}
                  className="w-full px-3 py-1.5 bg-slate-950 border border-slate-700 rounded-lg text-xs text-white placeholder:text-slate-500 focus:outline-none focus:border-indigo-500"
                />
              </div>
            </div>

            {/* 4. Action Buttons: Save & Next Serial Question */}
            <div className="pt-2 flex flex-col sm:flex-row items-stretch sm:items-center gap-3">
              <button
                type="submit"
                className="flex-1 py-3 px-5 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-black text-sm rounded-xl shadow-lg shadow-amber-500/20 transition-all flex items-center justify-center gap-2"
              >
                <span>Save Question #{nextSerialInSec} & Next (Q#{nextSerialInSec + 1})</span>
                <ArrowRight className="w-4 h-4" />
              </button>

              <button
                type="button"
                onClick={() => {
                  setCurrentImage('');
                  setCustomText('');
                  setExplanationText('');
                  if (fileInputRef.current) fileInputRef.current.value = '';
                }}
                className="py-3 px-4 bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold rounded-xl transition-colors"
              >
                Clear Current
              </button>
            </div>
          </form>
        </div>

        {/* Right Column (5 cols): Serial Question Grid / Filmstrip for Active Section */}
        <div className="lg:col-span-5 bg-slate-900 border border-slate-800 rounded-2xl p-5 flex flex-col h-full">
          <div className="flex items-center justify-between pb-3 border-b border-slate-800 mb-4">
            <div>
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <Layers className="w-4 h-4 text-amber-400" />
                {activeSection} Questions ({sectionQuestions.length})
              </h3>
              <p className="text-[11px] text-slate-400 mt-0.5">
                Serial list of questions created for {activeSection}
              </p>
            </div>
          </div>

          {sectionQuestions.length === 0 ? (
            <div className="flex-1 flex flex-col items-center justify-center p-8 text-center text-slate-500 border border-dashed border-slate-800 rounded-xl bg-slate-950/40">
              <ImageIcon className="w-10 h-10 text-slate-600 mb-2" />
              <p className="text-xs font-bold text-slate-400">No questions in {activeSection} yet</p>
              <p className="text-[11px] text-slate-500 mt-1 max-w-xs">
                Upload your first image question on the left to start serial building for {activeSection}.
              </p>
            </div>
          ) : (
            <div className="flex-1 overflow-y-auto max-h-[620px] space-y-3 pr-1">
              {sectionQuestions.map((q, idx) => (
                <div
                  key={q.id}
                  className="bg-slate-950 border border-slate-800 hover:border-slate-700 rounded-xl p-3 transition-colors flex items-center justify-between gap-3"
                >
                  <div className="flex items-center gap-3 min-w-0">
                    <span className="w-7 h-7 rounded-lg bg-slate-800 border border-slate-700 text-amber-400 font-black text-xs flex items-center justify-center shrink-0">
                      {idx + 1}
                    </span>

                    {/* Image Thumbnail if attached */}
                    {q.imageUrl ? (
                      <div
                        onClick={() => setPreviewZoomModal(q.imageUrl || null)}
                        className="w-12 h-12 rounded-lg overflow-hidden bg-slate-900 border border-slate-700 shrink-0 cursor-pointer hover:opacity-80 transition-opacity"
                        title="Click to view full image"
                      >
                        <img
                          src={q.imageUrl}
                          alt={`Q${idx + 1}`}
                          className="w-full h-full object-cover"
                        />
                      </div>
                    ) : (
                      <div className="w-12 h-12 rounded-lg bg-slate-900 border border-slate-800 flex items-center justify-center text-slate-600 shrink-0">
                        <ImageIcon className="w-5 h-5" />
                      </div>
                    )}

                    <div className="min-w-0">
                      <p className="text-xs font-bold text-white truncate max-w-[180px]">
                        {q.text}
                      </p>
                      <div className="flex items-center gap-2 mt-1">
                        <span className="px-1.5 py-0.2 rounded bg-amber-500/20 text-amber-300 font-mono text-[10px] font-bold">
                          Key: ({q.correctAnswer})
                        </span>
                        <span className="text-[10px] text-slate-500">
                          +{q.positiveMarks} / -{q.negativeMarks}
                        </span>
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center gap-1.5 shrink-0">
                    {q.imageUrl && (
                      <button
                        type="button"
                        onClick={() => setPreviewZoomModal(q.imageUrl || null)}
                        className="p-1 text-slate-400 hover:text-white"
                        title="View Full Diagram"
                      >
                        <Eye className="w-3.5 h-3.5" />
                      </button>
                    )}
                    <button
                      type="button"
                      onClick={() => {
                        if (confirm(`Delete Question #${idx + 1} from ${activeSection}?`)) {
                          deleteQuestion(currentTest.id, q.id);
                        }
                      }}
                      className="p-1 text-rose-400 hover:text-rose-300"
                      title="Delete Question"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Image Zoom Modal */}
      {previewZoomModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/90 backdrop-blur-md animate-fadeIn">
          <div className="relative max-w-4xl max-h-[90vh] bg-slate-900 border border-slate-700 rounded-2xl p-4 overflow-hidden flex flex-col">
            <button
              onClick={() => setPreviewZoomModal(null)}
              className="absolute top-4 right-4 p-1.5 bg-slate-800 text-slate-300 hover:text-white rounded-lg z-10"
            >
              <X className="w-5 h-5" />
            </button>
            <h4 className="text-xs font-bold text-slate-400 mb-2 uppercase tracking-wider">
              Question Diagram Preview
            </h4>
            <div className="flex-1 overflow-auto flex items-center justify-center bg-slate-950 rounded-xl p-2">
              <img
                src={previewZoomModal}
                alt="Enlarged Diagram"
                className="max-w-full max-h-[75vh] object-contain rounded-lg"
              />
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
