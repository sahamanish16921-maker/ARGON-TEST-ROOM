import React, { useState, useEffect } from 'react';
import { useApp } from '../context/AppContext.tsx';
import type { ExamType, TestSeries, Test, SubjectSection } from '../types/index.ts';
import { INITIAL_FACULTY_PROFILES } from '../data/seedData.ts';
import {
  GraduationCap,
  Sparkles,
  CheckCircle2,
  Lock,
  Unlock,
  Play,
  RotateCcw,
  BarChart3,
  QrCode,
  Copy,
  Check,
  Clock,
  BookOpen,
  Award,
  Filter,
  X,
  Calendar,
  Timer,
  Layers,
  ArrowRight,
  ShieldAlert,
  Phone,
  MessageCircle,
  User,
  Users,
  Save,
  CheckCircle,
  ShieldCheck,
  AlertCircle,
  FileCheck,
  RefreshCw,
  MapPin,
  Globe,
  Zap,
  Download,
  Image as ImageIcon,
  Mail,
} from 'lucide-react';
import { ArgonLogo } from './ArgonLogo.tsx';
import { StudentPerformanceOverview } from './StudentPerformanceOverview.tsx';

export const StudentDashboard: React.FC = () => {
  const {
    currentUser,
    testSeries,
    tests,
    attempts,
    verificationRequests,
    instituteUpi,
    sendVerificationRequest,
    enrollInSeries,
    startExam,
    viewResult,
    updateStudentPhone,
    notices,
    materials,
    facultyProfiles,
    lastSyncTime,
    isSupabaseConnected,
  } = useApp();

  const [activeTab, setActiveTab] = useState<
    'store' | 'my-tests' | 'verifications' | 'performance' | 'profile' | 'notices' | 'materials' | 'faculty'
  >('store');

  const displayFaculty =
    facultyProfiles && facultyProfiles.length > 0
      ? facultyProfiles
      : INITIAL_FACULTY_PROFILES;

  const [filterExam, setFilterExam] = useState<string>('All');
  const [filterPrice, setFilterPrice] = useState<'All' | 'Free' | 'Paid'>('All');

  // Phone number state for student
  const [phoneInput, setPhoneInput] = useState(currentUser?.phone || '+91 98765 43210');
  const [phoneSavedMsg, setPhoneSavedMsg] = useState('');

  // UPI Payment Modal State
  const [paymentModalSeries, setPaymentModalSeries] = useState<TestSeries | null>(null);
  const [upiTxnId, setUpiTxnId] = useState('');
  const [copiedUpi, setCopiedUpi] = useState(false);
  const [paymentSuccess, setPaymentSuccess] = useState(false);

  // Live timer tick for automated test scheduling countdown
  const [currentTime, setCurrentTime] = useState<number>(Date.now());
  useEffect(() => {
    const timer = setInterval(() => setCurrentTime(Date.now()), 1000);
    return () => clearInterval(timer);
  }, []);

  const formatCountdown = (diffSeconds: number): string => {
    if (diffSeconds <= 0) return '0s';
    const days = Math.floor(diffSeconds / 86400);
    const hrs = Math.floor((diffSeconds % 86400) / 3600);
    const mins = Math.floor((diffSeconds % 3600) / 60);
    const secs = diffSeconds % 60;
    if (days > 0) return `${days}d ${hrs}h ${mins}m`;
    if (hrs > 0) return `${hrs}h ${mins}m ${secs}s`;
    if (mins > 0) return `${mins}m ${secs}s`;
    return `${secs}s`;
  };

  const enrolledIds = currentUser?.enrolledSeriesIds || [];

  // Verification requests belonging to this student
  const myVerificationRequests = verificationRequests.filter(
    (r) =>
      r.studentId === currentUser?.id ||
      r.studentRoll === currentUser?.rollNo ||
      r.studentName.toLowerCase() === (currentUser?.name || '').toLowerCase()
  );

  const pendingRequestsCount = myVerificationRequests.filter((r) => r.status === 'pending').length;

  // Filtered Test Series for Store
  const filteredSeries = testSeries.filter((s) => {
    if (filterExam !== 'All' && s.targetExam !== filterExam) return false;
    if (filterPrice === 'Free' && s.price !== 0) return false;
    if (filterPrice === 'Paid' && s.price === 0) return false;
    return true;
  });

  // Tests from Enrolled Series
  const enrolledTests = tests.filter((t) => enrolledIds.includes(t.seriesId));

  const handleCopyUpi = () => {
    navigator.clipboard.writeText(paymentModalSeries?.upiId || instituteUpi.upiId);
    setCopiedUpi(true);
    setTimeout(() => setCopiedUpi(false), 2000);
  };

  const handleConfirmPayment = (e: React.FormEvent) => {
    e.preventDefault();
    if (!paymentModalSeries) return;

    if (!upiTxnId.trim()) {
      alert('Please enter your 12-digit UPI UTR / Transaction Reference ID');
      return;
    }

    sendVerificationRequest(paymentModalSeries.id, upiTxnId.trim());
    setPaymentSuccess(true);
    setTimeout(() => {
      setPaymentSuccess(false);
      setPaymentModalSeries(null);
      setUpiTxnId('');
      setActiveTab('verifications');
    }, 1200);
  };

  // Check for any automated live scheduled test that is currently open
  const activeScheduledLiveTests = enrolledTests.filter((t) => {
    if (!t.isScheduled || !t.scheduledStartTime) return false;
    const startMs = new Date(t.scheduledStartTime).getTime();
    const endMs = t.scheduledEndTime ? new Date(t.scheduledEndTime).getTime() : 0;
    const isLive = currentTime >= startMs && (endMs === 0 || currentTime <= endMs);
    const notAttempted = !attempts.some((a) => a.testId === t.id && a.studentId === currentUser?.id);
    return isLive && !t.isLockedByFaculty && notAttempted;
  });

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 pb-16">
      {/* Top Welcome Header */}
      <div className="bg-slate-900 border-b border-slate-800 py-6 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div className="flex flex-col sm:flex-row sm:items-center gap-4">
            <ArgonLogo size="md" theme="dark" />
            <div className="hidden sm:block h-8 w-px bg-slate-800" />
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-xl bg-gradient-to-tr from-indigo-600 to-violet-600 p-0.5 shadow-md shadow-indigo-600/20">
                <div className="w-full h-full bg-slate-900 rounded-[10px] flex items-center justify-center overflow-hidden">
                  {currentUser?.avatar ? (
                    <img
                      src={currentUser.avatar}
                      alt={currentUser.name}
                      className="w-full h-full object-cover"
                    />
                  ) : (
                    <GraduationCap className="w-6 h-6 text-indigo-400" />
                  )}
                </div>
              </div>

              <div>
                <div className="flex items-center gap-2">
                  <h1 className="text-xl font-bold text-white tracking-tight">
                    Welcome, {currentUser?.name || 'Aspirant'}
                  </h1>
                  <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
                    {currentUser?.targetExam || 'JEE & NEET'}
                  </span>
                </div>
              <div className="flex flex-wrap items-center gap-2 mt-1">
                <p className="text-xs text-slate-400">
                  Roll No: <span className="font-mono text-amber-300 font-bold">{currentUser?.rollNo || 'ARG-2026-REG'}</span>
                </p>
                <span className="text-slate-600">•</span>
                <button
                  type="button"
                  onClick={() => setActiveTab('profile')}
                  className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-lg bg-emerald-500/15 border border-emerald-500/30 text-emerald-400 hover:bg-emerald-500/25 transition-colors font-mono text-xs"
                  title="Click to view/update contact phone number seen by faculty"
                >
                  <Phone className="w-3 h-3 text-emerald-400" />
                  <span>{currentUser?.phone || '+91 98765 43210'}</span>
                  <span className="text-[10px] text-emerald-300/80 font-sans font-medium">(Faculty Contact)</span>
                </button>
                <span className="text-slate-600">•</span>
                <p className="text-xs text-slate-400">
                  Enrolled Series: <strong className="text-amber-400">{enrolledIds.length}</strong>
                </p>
              </div>
            </div>
          </div>
        </div>

          {/* Quick Metrics */}
          <div className="flex items-center gap-3">
            <button
              onClick={() => setActiveTab('performance')}
              className="bg-slate-950/70 hover:bg-slate-800/80 transition-all border border-slate-800 hover:border-indigo-500/50 rounded-xl px-4 py-2 text-center cursor-pointer group"
              title="Click to view detailed performance charts and score trends"
            >
              <p className="text-[10px] text-slate-400 group-hover:text-indigo-300 uppercase font-semibold">Tests Taken</p>
              <p className="text-lg font-black text-indigo-400">
                {attempts.filter((a) => a.studentId === currentUser?.id || a.studentRoll === currentUser?.rollNo).length}
              </p>
            </button>
            <button
              onClick={() => setActiveTab('my-tests')}
              className="bg-slate-950/70 hover:bg-slate-800/80 transition-all border border-slate-800 hover:border-amber-500/50 rounded-xl px-4 py-2 text-center cursor-pointer group"
              title="Click to view all enrolled CBT examination papers"
            >
              <p className="text-[10px] text-slate-400 group-hover:text-amber-300 uppercase font-semibold">Available Tests</p>
              <p className="text-lg font-black text-amber-400">{enrolledTests.length}</p>
            </button>
          </div>
        </div>

        {/* Dashboard Tabs */}
        <div className="max-w-7xl mx-auto mt-6 flex flex-wrap gap-2 sm:gap-3 border-b border-slate-800 pb-1">
          <button
            onClick={() => setActiveTab('store')}
            className={`px-4 py-2 rounded-lg text-xs font-bold transition-all flex items-center gap-2 ${
              activeTab === 'store'
                ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/20'
                : 'text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
          >
            <BookOpen className="w-4 h-4" />
            1. Test Series Store & Pricing
          </button>

          <button
            onClick={() => setActiveTab('my-tests')}
            className={`px-4 py-2 rounded-lg text-xs font-bold transition-all flex items-center gap-2 ${
              activeTab === 'my-tests'
                ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/20'
                : 'text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
          >
            <Play className="w-4 h-4" />
            2. My Enrolled CBT Tests ({enrolledTests.length})
          </button>

          <button
            onClick={() => setActiveTab('verifications')}
            className={`px-4 py-2 rounded-lg text-xs font-bold transition-all flex items-center gap-2 ${
              activeTab === 'verifications'
                ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/20'
                : 'text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
          >
            <ShieldCheck className="w-4 h-4 text-amber-400" />
            3. Verification Requests ({myVerificationRequests.length})
            {pendingRequestsCount > 0 && (
              <span className="px-1.5 py-0.2 rounded-full bg-amber-500 text-slate-950 font-black text-[10px] animate-pulse">
                {pendingRequestsCount} Pending
              </span>
            )}
          </button>

          <button
            onClick={() => setActiveTab('performance')}
            className={`px-4 py-2 rounded-lg text-xs font-bold transition-all flex items-center gap-2 ${
              activeTab === 'performance'
                ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/20'
                : 'text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
          >
            <BarChart3 className="w-4 h-4 text-emerald-400" />
            4. Performance Overview & Analytics
          </button>

          <button
            onClick={() => setActiveTab('profile')}
            className={`px-4 py-2 rounded-lg text-xs font-bold transition-all flex items-center gap-2 ${
              activeTab === 'profile'
                ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/20'
                : 'text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
          >
            <Phone className="w-4 h-4 text-emerald-400" />
            5. My Profile & Contact Phone
          </button>

          <button
            onClick={() => setActiveTab('notices')}
            className={`px-4 py-2 rounded-lg text-xs font-bold transition-all flex items-center gap-2 ${
              activeTab === 'notices'
                ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/20'
                : 'text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
          >
            <MessageCircle className="w-4 h-4 text-amber-400" />
            6. Institute Notices ({notices.length})
            {notices.some((n) => n.priority === 'urgent') && (
              <span className="w-2 h-2 rounded-full bg-rose-500 animate-ping"></span>
            )}
          </button>

          <button
            onClick={() => setActiveTab('materials')}
            className={`px-4 py-2 rounded-lg text-xs font-bold transition-all flex items-center gap-2 ${
              activeTab === 'materials'
                ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/20'
                : 'text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
          >
            <BookOpen className="w-4 h-4 text-indigo-400" />
            7. Study Materials ({materials.length})
          </button>

          <button
            onClick={() => setActiveTab('faculty')}
            className={`px-4 py-2 rounded-lg text-xs font-bold transition-all flex items-center gap-2 ${
              activeTab === 'faculty'
                ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/20'
                : 'text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
          >
            <Users className="w-4 h-4 text-emerald-400" />
            8. Faculty & Mentors ({displayFaculty.length})
          </button>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mt-8">
        {/* Live Urgent Notice Banner from Faculty */}
        {notices.some((n) => n.priority === 'urgent') && (
          <div className="mb-4 p-4 rounded-2xl bg-gradient-to-r from-rose-500/20 via-rose-500/10 to-transparent border border-rose-500/40 shadow-lg flex items-start gap-3">
            <div className="w-8 h-8 rounded-lg bg-rose-500/20 border border-rose-500/30 text-rose-400 flex items-center justify-center shrink-0 mt-0.5">
              <AlertCircle className="w-4 h-4 animate-pulse" />
            </div>
            <div className="flex-1">
              <div className="flex items-center gap-2">
                <span className="px-2 py-0.5 rounded bg-rose-500 text-slate-950 text-[10px] font-black uppercase tracking-wider">
                  Urgent Notice
                </span>
                <h4 className="font-bold text-sm text-white">
                  {notices.find((n) => n.priority === 'urgent')?.title}
                </h4>
              </div>
              <p className="text-xs text-slate-300 mt-1 leading-relaxed">
                {notices.find((n) => n.priority === 'urgent')?.content}
              </p>
            </div>
            <button
              onClick={() => setActiveTab('notices')}
              className="px-3 py-1.5 bg-rose-500/20 hover:bg-rose-500/30 text-rose-300 border border-rose-500/30 text-xs font-bold rounded-lg transition-colors shrink-0"
            >
              View Notice Board →
            </button>
          </div>
        )}

        {/* Automated Live Exam Alert Banner */}
        {activeScheduledLiveTests.length > 0 && (
          <div className="mb-6 p-4 rounded-2xl bg-gradient-to-r from-emerald-500/20 via-teal-500/15 to-transparent border border-emerald-500/50 shadow-xl shadow-emerald-950/30 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-emerald-500/20 border border-emerald-500/40 text-emerald-400 flex items-center justify-center shrink-0">
                <Zap className="w-5 h-5 animate-pulse text-amber-300" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <span className="text-[10px] font-black uppercase tracking-wider px-2 py-0.5 rounded bg-emerald-500 text-slate-950">
                    EXAM LIVE NOW
                  </span>
                  <span className="font-bold text-white text-sm">
                    {activeScheduledLiveTests[0].title}
                  </span>
                </div>
                <p className="text-xs text-slate-300 mt-0.5">
                  Automated exam window is now active. Timer set by faculty:{' '}
                  <strong className="text-amber-400 font-mono">
                    {activeScheduledLiveTests[0].durationMinutes} mins
                  </strong>
                  .
                </p>
              </div>
            </div>
            <button
              onClick={() => startExam(activeScheduledLiveTests[0].id)}
              className="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs rounded-xl shadow-lg shadow-emerald-600/30 transition-all flex items-center justify-center gap-2 shrink-0"
            >
              <Play className="w-4 h-4 fill-white" />
              <span>Enter CBT Exam Now</span>
            </button>
          </div>
        )}

        {/* ================= TAB 1: TEST SERIES STORE ================= */}
        {activeTab === 'store' && (
          <div className="space-y-6">
            {/* Filter Bar */}
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 flex flex-wrap items-center justify-between gap-4">
              <div className="flex items-center gap-2">
                <Filter className="w-4 h-4 text-slate-400" />
                <span className="text-xs font-bold text-slate-300">Target Exam:</span>
                <div className="flex gap-1">
                  {['All', 'JEE Main', 'JEE Advanced', 'NEET'].map((exam) => (
                    <button
                      key={exam}
                      onClick={() => setFilterExam(exam)}
                      className={`px-3 py-1 rounded-lg text-xs font-semibold transition-all ${
                        filterExam === exam
                          ? 'bg-indigo-600 text-white'
                          : 'bg-slate-800 text-slate-400 hover:text-white'
                      }`}
                    >
                      {exam}
                    </button>
                  ))}
                </div>
              </div>

              <div className="flex items-center gap-2">
                <span className="text-xs font-bold text-slate-300">Price:</span>
                <div className="flex gap-1">
                  {(['All', 'Free', 'Paid'] as const).map((p) => (
                    <button
                      key={p}
                      onClick={() => setFilterPrice(p)}
                      className={`px-3 py-1 rounded-lg text-xs font-semibold transition-all ${
                        filterPrice === p
                          ? 'bg-amber-500 text-slate-950'
                          : 'bg-slate-800 text-slate-400 hover:text-white'
                      }`}
                    >
                      {p}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {/* Test Series Cards Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredSeries.map((series) => {
                const isEnrolled = enrolledIds.includes(series.id);
                const seriesTests = tests.filter((t) => t.seriesId === series.id);

                return (
                  <div
                    key={series.id}
                    className="bg-slate-900 border border-slate-800 rounded-2xl p-5 hover:border-slate-700 transition-all flex flex-col justify-between shadow-lg"
                  >
                    <div>
                      <div className="flex items-center justify-between mb-3">
                        <span
                          className={`text-[10px] font-bold px-2.5 py-0.5 rounded-full uppercase tracking-wider ${
                            series.targetExam === 'NEET'
                              ? 'bg-emerald-500/15 text-emerald-300 border border-emerald-500/30'
                              : series.targetExam === 'JEE Advanced'
                              ? 'bg-amber-500/15 text-amber-300 border border-amber-500/30'
                              : 'bg-indigo-500/15 text-indigo-300 border border-indigo-500/30'
                          }`}
                        >
                          {series.targetExam}
                        </span>

                        {isEnrolled ? (
                          <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 flex items-center gap-1">
                            <CheckCircle2 className="w-3 h-3" /> Enrolled & Verified
                          </span>
                        ) : myVerificationRequests.find((r) => r.seriesId === series.id && r.status === 'pending') ? (
                          <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-amber-500/20 text-amber-300 border border-amber-500/30 flex items-center gap-1">
                            <Clock className="w-3 h-3 text-amber-400" /> Verification Pending
                          </span>
                        ) : series.badge ? (
                          <span className="text-[10px] font-semibold text-rose-300 bg-rose-500/10 px-2 py-0.5 rounded border border-rose-500/20">
                            {series.badge}
                          </span>
                        ) : null}
                      </div>

                      <h3 className="font-extrabold text-lg text-white mb-2">{series.title}</h3>
                      <p className="text-xs text-slate-400 line-clamp-3 mb-4 leading-relaxed">
                        {series.description}
                      </p>

                      <div className="bg-slate-950/60 rounded-xl p-3 border border-slate-800/80 mb-4 space-y-1.5 text-xs text-slate-300">
                        {series.features.map((feat, idx) => (
                          <div key={idx} className="flex items-center gap-2 text-[11px]">
                            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                            <span className="truncate">{feat}</span>
                          </div>
                        ))}
                      </div>
                    </div>

                    <div className="pt-4 border-t border-slate-800 flex items-center justify-between">
                      <div>
                        <div className="flex items-baseline gap-1.5">
                          <span className="text-xl font-black text-white">
                            {series.price === 0 ? 'FREE' : `₹${series.price}`}
                          </span>
                          {series.originalPrice && series.originalPrice > series.price && (
                            <span className="text-xs text-slate-500 line-through">
                              ₹{series.originalPrice}
                            </span>
                          )}
                        </div>
                        <span className="text-[10px] text-slate-400">
                          {seriesTests.length} Mock Tests Included
                        </span>
                      </div>

                      {isEnrolled ? (
                        <button
                          onClick={() => setActiveTab('my-tests')}
                          className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs rounded-xl transition-all flex items-center gap-1.5 shadow-md shadow-indigo-600/20"
                        >
                          <Play className="w-3.5 h-3.5" />
                          Go to Tests
                        </button>
                      ) : myVerificationRequests.find((r) => r.seriesId === series.id && r.status === 'pending') ? (
                        <button
                          onClick={() => setActiveTab('verifications')}
                          className="px-3.5 py-2 bg-amber-500/20 text-amber-300 hover:bg-amber-500/30 border border-amber-500/40 font-bold text-xs rounded-xl transition-all flex items-center gap-1.5"
                          title="Payment sent. Awaiting Faculty acceptance"
                        >
                          <Clock className="w-3.5 h-3.5 text-amber-400" />
                          Pending Faculty Review
                        </button>
                      ) : series.price === 0 ? (
                        <button
                          onClick={() => enrollInSeries(series.id)}
                          className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs rounded-xl transition-all shadow-md shadow-emerald-600/20 flex items-center gap-1.5"
                        >
                          <Unlock className="w-3.5 h-3.5" />
                          Enroll Free
                        </button>
                      ) : (
                        <button
                          onClick={() => setPaymentModalSeries(series)}
                          className="px-4 py-2 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-bold text-xs rounded-xl transition-all shadow-md shadow-amber-500/20 flex items-center gap-1.5"
                        >
                          <QrCode className="w-3.5 h-3.5" />
                          Pay & Request Verification
                        </button>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* ================= TAB 2: MY ENROLLED CBT TESTS ================= */}
        {activeTab === 'my-tests' && (
          <div className="space-y-6">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-xl font-bold text-white flex items-center gap-2">
                  <Play className="w-5 h-5 text-indigo-400" />
                  NTA-Pattern Computer Based Tests
                </h2>
                <p className="text-xs text-slate-400 mt-1">
                  Launch the exact CBT examination simulator with timer, question palette, and instant analysis
                </p>
              </div>
            </div>

            {enrolledTests.length === 0 ? (
              <div className="bg-slate-900 border border-slate-800 rounded-2xl p-12 text-center text-slate-400 text-xs">
                <BookOpen className="w-10 h-10 mx-auto text-slate-600 mb-3" />
                <p className="font-semibold text-slate-300">You haven't enrolled in any test series yet.</p>
                <p className="mt-1">Browse the store to enroll in free or premium mock test series.</p>
                <button
                  onClick={() => setActiveTab('store')}
                  className="mt-4 px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white font-bold rounded-xl text-xs"
                >
                  Explore Test Series Store
                </button>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {enrolledTests.map((test) => {
                  const studentAttempt = attempts.find(
                    (a) => a.testId === test.id && a.studentId === currentUser?.id
                  );

                  const isLocked = !!test.isLockedByFaculty;
                  const isScheduled = !!test.isScheduled && !!test.scheduledStartTime;
                  const startTimeMs = isScheduled ? new Date(test.scheduledStartTime!).getTime() : 0;
                  const endTimeMs = test.scheduledEndTime ? new Date(test.scheduledEndTime).getTime() : 0;
                  const isUpcoming = isScheduled && currentTime < startTimeMs;
                  const isEnded = endTimeMs > 0 && currentTime > endTimeMs;
                  const countdownSec = isUpcoming ? Math.max(0, Math.floor((startTimeMs - currentTime) / 1000)) : 0;

                  // Faculty Subject Order
                  const orderedSections = (() => {
                    const raw: SubjectSection[] = test.sections.length > 0 ? test.sections : ['Physics'];
                    if (test.subjectOrder && test.subjectOrder.length > 0) {
                      const inOrder = test.subjectOrder.filter((s) => raw.includes(s));
                      const remaining = raw.filter((s) => !inOrder.includes(s));
                      return [...inOrder, ...remaining];
                    }
                    return raw;
                  })();

                  return (
                    <div
                      key={test.id}
                      className={`bg-slate-900 border rounded-2xl p-5 transition-all flex flex-col justify-between ${
                        isLocked
                          ? 'border-rose-500/30 shadow-lg shadow-rose-950/20'
                          : isUpcoming
                          ? 'border-indigo-500/40 shadow-lg shadow-indigo-950/30'
                          : 'border-slate-800 hover:border-slate-700'
                      }`}
                    >
                      <div>
                        <div className="flex items-center justify-between mb-3 gap-2 flex-wrap">
                          <div className="flex items-center gap-1.5 flex-wrap">
                            <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-slate-800 text-amber-400 border border-slate-700">
                              {test.examType}
                            </span>
                            {isLocked ? (
                              <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-rose-500/20 text-rose-300 border border-rose-500/40 flex items-center gap-1">
                                <Lock className="w-3 h-3 text-rose-400" />
                                Locked by Faculty
                              </span>
                            ) : isUpcoming ? (
                              <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-indigo-500/20 text-indigo-300 border border-indigo-500/40 flex items-center gap-1 animate-pulse">
                                <Clock className="w-3 h-3 text-indigo-400" />
                                Starts in {formatCountdown(countdownSec)}
                              </span>
                            ) : isEnded ? (
                              <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-slate-800 text-slate-400 border border-slate-700">
                                Exam Window Closed
                              </span>
                            ) : isScheduled ? (
                              <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 flex items-center gap-1">
                                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping"></span>
                                Live Scheduled Exam
                              </span>
                            ) : null}
                          </div>

                          <span className="text-xs text-slate-400 flex items-center gap-1 font-mono">
                            <Clock className="w-3.5 h-3.5 text-amber-400" />
                            {test.durationMinutes} mins
                          </span>
                        </div>

                        {/* Notice for Locked or Scheduled test */}
                        {isLocked ? (
                          <div className="mb-3 p-2.5 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-300 text-xs flex items-start gap-2">
                            <Lock className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
                            <div>
                              <p className="font-bold">Test Paper Locked</p>
                              <p className="text-[11px] text-rose-300/80 mt-0.5">
                                Locked by faculty administrator. Students will get access immediately once unlocked by faculty.
                              </p>
                            </div>
                          </div>
                        ) : isUpcoming ? (
                          <div className="mb-3 p-2.5 rounded-xl bg-indigo-950/40 border border-indigo-500/30 text-indigo-200 text-xs flex items-start gap-2">
                            <Calendar className="w-4 h-4 text-indigo-400 shrink-0 mt-0.5" />
                            <div>
                              <p className="font-bold">Automated Scheduled Exam</p>
                              <p className="text-[11px] text-indigo-300/80 mt-0.5">
                                Start: {new Date(test.scheduledStartTime!).toLocaleString([], { dateStyle: 'short', timeStyle: 'short' })}
                              </p>
                              <p className="text-[11px] font-mono font-bold text-amber-300 mt-0.5">
                                Auto-triggers in: {formatCountdown(countdownSec)}
                              </p>
                            </div>
                          </div>
                        ) : null}

                        <h3 className="font-bold text-base text-white mb-2">{test.title}</h3>
                        <p className="text-xs text-slate-400 line-clamp-2 mb-3">
                          {test.description}
                        </p>

                        <div className="bg-slate-950/60 rounded-xl p-3 border border-slate-800/80 mb-3 space-y-1.5 text-xs">
                          <div className="flex justify-between text-slate-300">
                            <span>CBT Timer Duration:</span>
                            <span className="font-bold text-amber-400 font-mono">{test.durationMinutes} Minutes</span>
                          </div>
                          <div className="flex justify-between text-slate-300">
                            <span>Total Questions:</span>
                            <span className="font-bold text-white">{test.questions.length}</span>
                          </div>
                          <div className="flex justify-between text-slate-300">
                            <span>Total Marks:</span>
                            <span className="font-bold text-amber-400">{test.totalMarks}</span>
                          </div>
                          <div className="pt-2 border-t border-slate-800/80">
                            <span className="text-[11px] text-slate-400 block mb-1 font-medium">
                              Faculty Subject Order (1st appears first in CBT):
                            </span>
                            <div className="flex items-center gap-1.5 flex-wrap">
                              {orderedSections.map((sec, idx) => (
                                <span
                                  key={sec}
                                  className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                                    idx === 0
                                      ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40 shadow-sm'
                                      : 'bg-slate-800 text-slate-300 border border-slate-700'
                                  }`}
                                >
                                  {idx + 1}. {sec} {idx === 0 && '★ First Subject'}
                                </span>
                              ))}
                            </div>
                          </div>
                        </div>

                        {studentAttempt && (
                          <div className="p-3 bg-indigo-950/30 border border-indigo-500/30 rounded-xl mb-3 text-xs">
                            <div className="flex items-center justify-between mb-1">
                              <span className="text-indigo-300 font-semibold">Latest Score:</span>
                              <span className="font-black text-amber-400 text-sm">
                                {studentAttempt.score} / {studentAttempt.maxScore}
                              </span>
                            </div>
                            <div className="flex items-center justify-between text-[11px] text-slate-400">
                              <span>Accuracy: {studentAttempt.accuracy}%</span>
                              <span className="text-emerald-400 font-semibold">
                                {studentAttempt.percentile}%ile
                              </span>
                            </div>
                          </div>
                        )}
                      </div>

                      <div className="pt-3 border-t border-slate-800 flex items-center gap-2">
                        {isLocked ? (
                          <button
                            disabled
                            className="w-full py-2.5 px-4 bg-slate-800/80 border border-rose-500/30 text-rose-300/80 font-bold text-xs rounded-xl flex items-center justify-center gap-2 cursor-not-allowed"
                            title="Faculty has locked this test. Access will unlock when faculty releases it."
                          >
                            <Lock className="w-4 h-4 text-rose-400" />
                            <span>Locked by Faculty</span>
                          </button>
                        ) : isUpcoming ? (
                          <button
                            disabled
                            className="w-full py-2.5 px-4 bg-indigo-950/50 border border-indigo-500/40 text-indigo-300 font-bold text-xs rounded-xl flex items-center justify-center gap-2 cursor-not-allowed shadow-md shadow-indigo-950/50"
                            title="Exam triggers automatically when countdown expires."
                          >
                            <Clock className="w-4 h-4 text-indigo-400 animate-pulse" />
                            <span>Triggers in {formatCountdown(countdownSec)}</span>
                          </button>
                        ) : isEnded ? (
                          <button
                            disabled
                            className="w-full py-2.5 px-4 bg-slate-800 text-slate-500 font-bold text-xs rounded-xl cursor-not-allowed"
                          >
                            Exam Window Closed
                          </button>
                        ) : studentAttempt ? (
                          <>
                            <button
                              onClick={() => viewResult(studentAttempt.id)}
                              className="flex-1 py-2 px-3 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-bold text-xs rounded-xl transition-all flex items-center justify-center gap-1.5 shadow-md shadow-amber-500/20"
                              title="View Serial Questions with Step Solutions & Analysis"
                            >
                              <ImageIcon className="w-3.5 h-3.5 text-slate-950" />
                              <span>View Solutions & Analysis</span>
                            </button>
                            <button
                              onClick={() => startExam(test.id)}
                              className="py-2 px-3 bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs rounded-xl transition-all flex items-center justify-center gap-1.5"
                              title="Re-attempt Test"
                            >
                              <RotateCcw className="w-3.5 h-3.5" />
                              Re-attempt
                            </button>
                          </>
                        ) : (
                          <button
                            onClick={() => startExam(test.id)}
                            className="w-full py-2.5 px-4 bg-gradient-to-r from-indigo-600 to-indigo-700 hover:from-indigo-500 hover:to-indigo-600 text-white font-bold text-xs rounded-xl shadow-md shadow-indigo-600/20 transition-all flex items-center justify-center gap-2"
                          >
                            <Play className="w-4 h-4" />
                            Start NTA CBT Test
                          </button>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        )}

        {/* ================= TAB 3: VERIFICATION REQUESTS & PAYMENT STATUS ================= */}
        {activeTab === 'verifications' && (
          <div className="space-y-6 max-w-4xl mx-auto">
            {/* Header / Notice */}
            <div className="bg-gradient-to-r from-amber-950/40 via-slate-900 to-indigo-950/40 border border-amber-500/30 rounded-2xl p-6 shadow-xl">
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 rounded-2xl bg-amber-500/20 border border-amber-500/40 text-amber-400 flex items-center justify-center shrink-0 shadow-md">
                  <ShieldCheck className="w-6 h-6" />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <h2 className="text-xl font-bold text-white">Payment Verification Requests</h2>
                    <span className="text-[10px] font-bold px-2.5 py-0.5 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/30">
                      Faculty Access Control
                    </span>
                  </div>
                  <p className="text-xs text-slate-300 mt-1.5 leading-relaxed">
                    After completing UPI payment, your verification request with the UTR number is sent to the <strong className="text-amber-400">Faculty App</strong>. 
                    <strong className="text-white"> Without faculty verification and acceptance, no access will be provided.</strong> Once accepted by the faculty, your test series will unlock automatically.
                  </p>
                </div>
              </div>
            </div>

            {/* Quick Metrics */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-center">
              <div className="bg-slate-900 border border-slate-800 rounded-xl p-3.5">
                <p className="text-[10px] text-slate-400 uppercase font-semibold">Total Requests</p>
                <p className="text-2xl font-black text-white mt-1">{myVerificationRequests.length}</p>
              </div>
              <div className="bg-slate-900 border border-slate-800 rounded-xl p-3.5">
                <p className="text-[10px] text-slate-400 uppercase font-semibold">Pending Review</p>
                <p className="text-2xl font-black text-amber-400 mt-1">{pendingRequestsCount}</p>
              </div>
              <div className="bg-slate-900 border border-slate-800 rounded-xl p-3.5">
                <p className="text-[10px] text-slate-400 uppercase font-semibold">Verified & Granted</p>
                <p className="text-2xl font-black text-emerald-400 mt-1">
                  {myVerificationRequests.filter((r) => r.status === 'approved').length}
                </p>
              </div>
            </div>

            {/* Verification Request Cards List */}
            {myVerificationRequests.length === 0 ? (
              <div className="bg-slate-900 border border-slate-800 rounded-2xl p-10 text-center text-xs space-y-3">
                <FileCheck className="w-12 h-12 text-slate-600 mx-auto" />
                <h4 className="text-base font-bold text-white">No Verification Requests Sent Yet</h4>
                <p className="text-slate-400 max-w-md mx-auto">
                  When you scan the UPI QR code in the Test Series Store and submit your transaction UTR, your verification request will appear here for real-time tracking.
                </p>
                <button
                  onClick={() => setActiveTab('store')}
                  className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white font-bold rounded-xl text-xs transition-colors"
                >
                  Browse Store & Unlock Series
                </button>
              </div>
            ) : (
              <div className="space-y-4">
                {myVerificationRequests.map((req) => (
                  <div
                    key={req.id}
                    className={`p-5 rounded-2xl border transition-all text-xs space-y-3.5 shadow-lg ${
                      req.status === 'approved'
                        ? 'bg-emerald-950/15 border-emerald-500/40'
                        : req.status === 'rejected'
                        ? 'bg-rose-950/15 border-rose-500/40'
                        : 'bg-amber-950/15 border-amber-500/40'
                    }`}
                  >
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 border-b border-slate-800/80">
                      <div>
                        <div className="flex items-center gap-2">
                          <h4 className="text-base font-bold text-white">{req.seriesTitle}</h4>
                          <span className="font-black text-amber-400 text-sm">₹{req.seriesPrice}</span>
                        </div>
                        <p className="text-[11px] text-slate-400 mt-0.5">
                          Requested: {new Date(req.requestedAt).toLocaleDateString()} at{' '}
                          {new Date(req.requestedAt).toLocaleTimeString()}
                        </p>
                      </div>

                      {/* Status Badges */}
                      <div>
                        {req.status === 'approved' && (
                          <span className="px-3 py-1 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 font-bold text-xs flex items-center gap-1.5 shadow-sm">
                            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                            Verified & Access Granted
                          </span>
                        )}
                        {req.status === 'pending' && (
                          <span className="px-3 py-1 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/40 font-bold text-xs flex items-center gap-1.5 shadow-sm">
                            <Clock className="w-3.5 h-3.5 text-amber-400 animate-spin" />
                            Pending Faculty Review
                          </span>
                        )}
                        {req.status === 'rejected' && (
                          <span className="px-3 py-1 rounded-full bg-rose-500/20 text-rose-300 border border-rose-500/40 font-bold text-xs flex items-center gap-1.5 shadow-sm">
                            <AlertCircle className="w-3.5 h-3.5 text-rose-400" />
                            Verification Declined
                          </span>
                        )}
                      </div>
                    </div>

                    {/* Details Box */}
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 bg-slate-950/70 p-3.5 rounded-xl border border-slate-800/80 text-[11px]">
                      <div>
                        <span className="text-slate-400">UPI Transaction / UTR Number:</span>
                        <p className="font-mono font-bold text-amber-300 text-xs mt-0.5 truncate">
                          {req.upiTxnId}
                        </p>
                      </div>
                      <div>
                        <span className="text-slate-400">Student Roll & Registered Phone:</span>
                        <p className="font-mono text-slate-200 mt-0.5">
                          {req.studentRoll} • <span className="text-emerald-400 font-bold">{req.studentPhone}</span>
                        </p>
                      </div>
                    </div>

                    {/* Notes & Actions */}
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pt-2">
                      <div className="text-[11px] text-slate-300">
                        {req.status === 'approved' && (
                          <p className="text-emerald-300 flex items-center gap-1.5">
                            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                            <span>
                              Accepted by {req.reviewedBy || 'Faculty'} on {req.reviewedAt ? new Date(req.reviewedAt).toLocaleDateString() : 'recent'}. All tests in this series are now unlocked!
                            </span>
                          </p>
                        )}
                        {req.status === 'pending' && (
                          <p className="text-amber-300 flex items-center gap-1.5">
                            <Clock className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                            <span>
                              Awaiting verification by Faculty Admin. Without verification, access is locked. Faculty will accept shortly.
                            </span>
                          </p>
                        )}
                        {req.status === 'rejected' && (
                          <p className="text-rose-300 flex items-center gap-1.5">
                            <AlertCircle className="w-3.5 h-3.5 text-rose-400 shrink-0" />
                            <span>Reason: {req.rejectionReason || 'UTR not verified in institute accounts.'}</span>
                          </p>
                        )}
                      </div>

                      {req.status === 'approved' && (
                        <button
                          onClick={() => setActiveTab('my-tests')}
                          className="px-4 py-2 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-bold text-xs rounded-xl shadow-md transition-all flex items-center gap-1.5 shrink-0"
                        >
                          <Play className="w-3.5 h-3.5" />
                          Launch CBT Tests Now →
                        </button>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* ================= TAB 4: PERFORMANCE OVERVIEW & ANALYTICS ================= */}
        {activeTab === 'performance' && (
          <StudentPerformanceOverview />
        )}

        {/* ================= TAB 5: MY PROFILE & PHONE NUMBER SECTION ================= */}
        {activeTab === 'profile' && (
          <div className="space-y-6 max-w-4xl mx-auto">
            {/* Phone Number Banner / Notice */}
            <div className="bg-gradient-to-r from-emerald-950/40 via-slate-900 to-indigo-950/40 border border-emerald-500/30 rounded-2xl p-6 shadow-xl">
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 rounded-2xl bg-emerald-500/20 border border-emerald-500/40 text-emerald-400 flex items-center justify-center shrink-0 shadow-md">
                  <Phone className="w-6 h-6" />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <h2 className="text-xl font-bold text-white">Student Contact Phone Number</h2>
                    <span className="text-[10px] font-bold px-2.5 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                      Live Faculty Sync
                    </span>
                  </div>
                  <p className="text-xs text-slate-300 mt-1.5 leading-relaxed">
                    This phone number is synchronized with the <strong className="text-amber-400">Faculty App ("Enrolled Students" section)</strong>. 
                    The Admin and Faculty mentors use this contact to reach you directly for performance reviews, doubt sessions, and counseling calls.
                  </p>
                </div>
              </div>
            </div>

            {/* Phone Number Edit & Status Card */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* Left: Interactive Phone Number Form */}
              <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-lg">
                <h3 className="text-sm font-bold text-white mb-4 flex items-center gap-2">
                  <Phone className="w-4 h-4 text-emerald-400" />
                  Update Contact Phone Number
                </h3>

                {phoneSavedMsg && (
                  <div className="mb-4 p-3 rounded-xl bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 text-xs flex items-center gap-2">
                    <CheckCircle className="w-4 h-4 shrink-0 text-emerald-400" />
                    <span>{phoneSavedMsg}</span>
                  </div>
                )}

                <form
                  onSubmit={(e) => {
                    e.preventDefault();
                    if (currentUser && phoneInput.trim()) {
                      updateStudentPhone(currentUser.id, phoneInput.trim());
                      setPhoneSavedMsg('Phone number updated successfully! It is now visible to the Admin.');
                      setTimeout(() => setPhoneSavedMsg(''), 4000);
                    }
                  }}
                  className="space-y-4"
                >
                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                      Phone Number (Mobile / WhatsApp)
                    </label>
                    <div className="relative">
                      <Phone className="w-4 h-4 text-slate-500 absolute left-3 top-3" />
                      <input
                        type="tel"
                        value={phoneInput}
                        onChange={(e) => setPhoneInput(e.target.value)}
                        placeholder="+91 98765 43210"
                        className="w-full pl-9 pr-3 py-2.5 bg-slate-950 border border-slate-700 rounded-xl text-white font-mono text-sm focus:outline-none focus:border-emerald-500"
                        required
                      />
                    </div>
                    <p className="text-[11px] text-slate-400 mt-1">
                      Include country code (e.g. +91 98765 43210) for direct WhatsApp messaging by mentors.
                    </p>
                  </div>

                  <button
                    type="submit"
                    className="w-full py-2.5 px-4 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-bold text-xs rounded-xl shadow-md shadow-emerald-600/20 transition-all flex items-center justify-center gap-2"
                  >
                    <Save className="w-4 h-4" />
                    Save & Sync Phone Number to Faculty App
                  </button>
                </form>
              </div>

              {/* Right: Preview of how Admin sees it */}
              <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-lg flex flex-col justify-between">
                <div>
                  <h3 className="text-sm font-bold text-white mb-2 flex items-center gap-2">
                    <ShieldAlert className="w-4 h-4 text-amber-400" />
                    Faculty View Preview
                  </h3>
                  <p className="text-xs text-slate-400 mb-4">
                    Here is how your card appears to the Admin when they inspect your Roll Number in the Faculty App:
                  </p>

                  <div className="p-4 bg-slate-950 rounded-xl border border-slate-800 space-y-3">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm font-bold text-white">{currentUser?.name}</p>
                        <p className="text-[11px] font-mono text-amber-400">Roll: {currentUser?.rollNo}</p>
                      </div>
                      <span className="text-[10px] px-2 py-0.5 rounded bg-indigo-500/20 text-indigo-300 font-bold border border-indigo-500/30">
                        {currentUser?.targetExam}
                      </span>
                    </div>

                    <div className="pt-2 border-t border-slate-800/80 flex items-center justify-between">
                      <div className="flex items-center gap-1.5 text-xs text-emerald-400 font-mono font-bold">
                        <Phone className="w-3.5 h-3.5" />
                        <span>{phoneInput || currentUser?.phone || 'No phone'}</span>
                      </div>
                      <div className="flex items-center gap-1.5">
                        <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-slate-800 text-slate-300 border border-slate-700 flex items-center gap-1">
                          <Phone className="w-2.5 h-2.5 text-emerald-400" /> Call
                        </span>
                        <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-950 text-emerald-300 border border-emerald-700/60 flex items-center gap-1">
                          <MessageCircle className="w-2.5 h-2.5" /> WhatsApp
                        </span>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="mt-4 pt-3 border-t border-slate-800 text-[11px] text-slate-400">
                  <span className="text-emerald-400 font-bold">✓ Active Link:</span> Faculty can click one button to phone you or send performance report PDFs directly to your WhatsApp.
                </div>
              </div>
            </div>

            {/* Academic Credentials Registered by Admin */}
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-lg">
              <h3 className="text-sm font-bold text-white mb-4 flex items-center gap-2">
                <GraduationCap className="w-4 h-4 text-indigo-400" />
                Institute Academic Dossier
              </h3>

              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4 text-xs">
                <div className="bg-slate-950 p-3.5 rounded-xl border border-slate-800">
                  <p className="text-[10px] text-slate-400 uppercase font-semibold">Student Name</p>
                  <p className="text-sm font-bold text-white mt-1">{currentUser?.name}</p>
                  <p className="text-[10px] text-slate-500 mt-0.5">As registered by Admin</p>
                </div>

                <div className="bg-slate-950 p-3.5 rounded-xl border border-slate-800">
                  <p className="text-[10px] text-slate-400 uppercase font-semibold">Assigned Roll No</p>
                  <p className="text-sm font-mono font-bold text-amber-400 mt-1">{currentUser?.rollNo}</p>
                  <p className="text-[10px] text-slate-500 mt-0.5">Used for CBT Login</p>
                </div>

                <div className="bg-slate-950 p-3.5 rounded-xl border border-slate-800">
                  <p className="text-[10px] text-slate-400 uppercase font-semibold">Target Examination</p>
                  <p className="text-sm font-bold text-indigo-400 mt-1">{currentUser?.targetExam}</p>
                  <p className="text-[10px] text-slate-500 mt-0.5">Curriculum Track</p>
                </div>

                <div className="bg-slate-950 p-3.5 rounded-xl border border-slate-800">
                  <p className="text-[10px] text-slate-400 uppercase font-semibold">Registered Email</p>
                  <p className="text-sm font-bold text-slate-300 mt-1 truncate">{currentUser?.email}</p>
                  <p className="text-[10px] text-slate-500 mt-0.5">Scorecard Delivery</p>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* ================= TAB 6: NOTICES & ANNOUNCEMENTS ================= */}
        {activeTab === 'notices' && (
          <div className="space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <h2 className="text-xl font-bold text-white flex items-center gap-2">
                  <MessageCircle className="w-5 h-5 text-amber-400" />
                  Institute Notice Board & Announcements
                </h2>
                <p className="text-xs text-slate-400 mt-0.5">
                  Live notifications posted by Faculty & Academic Directors. Synced across all your devices via Supabase Cloud.
                </p>
              </div>
              <span className="px-3 py-1 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 text-xs font-semibold flex items-center gap-1.5 self-start">
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
                Live Synced with Faculty Portal
              </span>
            </div>

            <div className="space-y-4">
              {notices.length === 0 ? (
                <div className="p-12 bg-slate-900 border border-slate-800 rounded-2xl text-center text-slate-400 text-xs">
                  <MessageCircle className="w-8 h-8 text-slate-600 mx-auto mb-2" />
                  No announcements at this moment. Any exam notices posted by faculty will appear here immediately.
                </div>
              ) : (
                notices.map((n) => (
                  <div
                    key={n.id}
                    className={`p-5 rounded-2xl border transition-all ${
                      n.priority === 'urgent'
                        ? 'bg-rose-950/20 border-rose-500/40 shadow-lg shadow-rose-950/20'
                        : 'bg-slate-900 border-slate-800 hover:border-slate-700'
                    }`}
                  >
                    <div className="flex flex-wrap items-center gap-2 mb-2">
                      {n.priority === 'urgent' && (
                        <span className="px-2.5 py-0.5 rounded-full bg-rose-500 text-slate-950 text-[10px] font-black uppercase tracking-wider animate-pulse">
                          🚨 Urgent Notice
                        </span>
                      )}
                      <span className="px-2.5 py-0.5 rounded-full bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 text-[10px] font-bold">
                        {n.targetExam || 'All Aspirants'}
                      </span>
                      <span className="text-[11px] text-slate-500">
                        {new Date(n.createdAt).toLocaleDateString()} at {new Date(n.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                      </span>
                    </div>

                    <h3 className="font-extrabold text-base text-white mb-2">{n.title}</h3>
                    <p className="text-xs text-slate-300 leading-relaxed whitespace-pre-line">{n.content}</p>

                    <div className="mt-4 pt-3 border-t border-slate-800/80 flex items-center justify-between text-[11px] text-slate-400">
                      <span>Issued by: <strong className="text-slate-200">{n.author || 'Academic Faculty'}</strong></span>
                      <span className="text-emerald-400 font-mono text-[10px]">Verified Official Notice</span>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        )}

        {/* ================= TAB 7: STUDY MATERIALS & HANDBOOKS ================= */}
        {activeTab === 'materials' && (
          <div className="space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <h2 className="text-xl font-bold text-white flex items-center gap-2">
                  <BookOpen className="w-5 h-5 text-indigo-400" />
                  Study Materials, Handbooks & Solved Papers
                </h2>
                <p className="text-xs text-slate-400 mt-0.5">
                  Exclusive academic formula sheets, reaction maps, and NCERT line-by-line mindmaps uploaded by faculty.
                </p>
              </div>
              <span className="px-3 py-1 rounded-full bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 text-xs font-semibold flex items-center gap-1.5 self-start">
                <span className="w-2 h-2 rounded-full bg-indigo-400 animate-pulse"></span>
                Live Supabase Library
              </span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
              {materials.map((m) => (
                <div
                  key={m.id}
                  className="bg-slate-900 border border-slate-800 rounded-2xl p-5 hover:border-indigo-500/40 transition-all flex flex-col justify-between"
                >
                  <div>
                    <div className="flex items-center justify-between mb-3">
                      <span className="px-2.5 py-0.5 rounded-full bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 text-[10px] font-bold uppercase">
                        {m.category} • {m.type}
                      </span>
                      {m.isHot && (
                        <span className="px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/30 text-[10px] font-bold">
                          🔥 High-Yield
                        </span>
                      )}
                    </div>

                    <h3 className="font-extrabold text-base text-white mb-2">{m.title}</h3>
                    <p className="text-xs text-slate-400 leading-relaxed line-clamp-3 mb-4">{m.description}</p>
                  </div>

                  <div className="pt-3 border-t border-slate-800 flex items-center justify-between text-xs">
                    <span className="text-slate-500 text-[11px]">Size: {m.size || '3.5 MB'}</span>
                    <button
                      onClick={() => alert(`Starting download for "${m.title}"...`)}
                      className="px-3.5 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white font-bold rounded-xl transition-all shadow-md shadow-indigo-600/20 flex items-center gap-1.5 text-xs"
                    >
                      <Download className="w-3.5 h-3.5" />
                      Download Material
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* ================= TAB 8: FACULTY & MENTORS ================= */}
        {activeTab === 'faculty' && (
          <div className="space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <h2 className="text-xl font-bold text-white flex items-center gap-2">
                  <Users className="w-5 h-5 text-emerald-400" />
                  Institute Faculty Mentors & Doubt Hours
                </h2>
                <p className="text-xs text-slate-400 mt-1">
                  Connect with your IITian, Ph.D. and Medical faculty for 1-on-1 doubt clearance, strategy, and paper feedback.
                </p>
              </div>
              <span className="px-3 py-1 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 text-xs font-semibold flex items-center gap-1.5 self-start">
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
                Live Synced with Faculty Portal
              </span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {displayFaculty.map((faculty) => (
                <div
                  key={faculty.id}
                  className="bg-slate-900 border border-slate-800 rounded-3xl p-6 hover:border-slate-700 transition-all shadow-xl flex flex-col justify-between"
                >
                  <div>
                    <div className="flex items-start gap-4 mb-4">
                      <img
                        src={faculty.avatar}
                        alt={faculty.name}
                        className="w-16 h-16 rounded-2xl object-cover border-2 border-slate-700 shadow-md shrink-0 bg-slate-800"
                      />
                      <div>
                        <h3 className="text-lg font-bold text-white">{faculty.name}</h3>
                        <p className="text-xs font-bold text-amber-400">{faculty.role}</p>
                        <p className="text-[11px] text-slate-400 font-medium">{faculty.qualification}</p>
                        {faculty.department && (
                          <span className="inline-block mt-1 px-2 py-0.5 rounded text-[10px] font-bold bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
                            {faculty.department} Department
                          </span>
                        )}
                      </div>
                    </div>

                    <p className="text-xs text-slate-300 leading-relaxed mb-4">{faculty.bio}</p>

                    {faculty.quote && (
                      <div className="p-3 rounded-xl bg-slate-950/80 border-l-4 border-amber-500 mb-4 text-xs italic text-slate-300">
                        {faculty.quote}
                      </div>
                    )}

                    <div className="space-y-2 mb-4">
                      {faculty.subjects && faculty.subjects.length > 0 && (
                        <div>
                          <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-1">
                            Key Focus Subjects:
                          </span>
                          <div className="flex flex-wrap gap-1">
                            {faculty.subjects.map((sub, i) => (
                              <span
                                key={i}
                                className="px-2 py-0.5 rounded bg-slate-800 text-[10px] text-indigo-300 border border-slate-700/60"
                              >
                                {sub}
                              </span>
                            ))}
                          </div>
                        </div>
                      )}

                      {faculty.trackRecord && (
                        <div className="p-2.5 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-xs text-emerald-300 flex items-center gap-2">
                          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                          <span>Track Record: <strong>{faculty.trackRecord}</strong></span>
                        </div>
                      )}

                      {faculty.availableTimings && (
                        <div className="p-2.5 rounded-xl bg-amber-500/10 border border-amber-500/20 text-xs text-amber-300 flex items-center gap-2 font-mono">
                          <Clock className="w-4 h-4 text-amber-400 shrink-0" />
                          <span>Doubt Hours: <strong>{faculty.availableTimings}</strong></span>
                        </div>
                      )}
                    </div>
                  </div>

                  <div className="pt-3 border-t border-slate-800 flex items-center justify-between text-xs text-slate-400">
                    <span className="text-[11px]">Guwahati Classroom & Offline Mentorship</span>
                    {faculty.phone ? (
                      <a
                        href={`tel:${faculty.phone}`}
                        className="px-3 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 font-semibold text-xs flex items-center gap-1.5 transition-colors"
                      >
                        <Phone className="w-3.5 h-3.5 text-emerald-400" />
                        <span>{faculty.phone}</span>
                      </a>
                    ) : (
                      <span className="text-emerald-400 font-medium">Daily 1-on-1 Available</span>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* ================= MODAL: UPI PAYMENT & QR CODE INTEGRATION ================= */}
      {paymentModalSeries && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-sm animate-fadeIn">
          <div className="w-full max-w-md bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl p-6 text-white text-xs relative">
            <button
              onClick={() => setPaymentModalSeries(null)}
              className="absolute top-4 right-4 text-slate-400 hover:text-white"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="text-center mb-4">
              <div className="w-10 h-10 rounded-xl bg-amber-500/20 text-amber-400 border border-amber-500/30 flex items-center justify-center mx-auto mb-2">
                <QrCode className="w-5 h-5" />
              </div>
              <h3 className="text-lg font-bold text-white">Unlock Test Series via UPI</h3>
              <p className="text-slate-400 text-xs mt-0.5">{paymentModalSeries.title}</p>
            </div>

            {/* QR Code Card */}
            <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 flex flex-col items-center mb-4">
              <div className="w-44 h-44 bg-white p-2.5 rounded-xl flex items-center justify-center shadow-inner">
                <img
                  src={paymentModalSeries.upiQrUrl || instituteUpi.qrUrl}
                  alt="UPI QR Code"
                  className="w-full h-full object-contain"
                />
              </div>

              <div className="mt-3 text-center">
                <p className="text-[11px] text-slate-400 uppercase font-semibold">Institute UPI ID</p>
                <div className="mt-1 flex items-center justify-center gap-2">
                  <span className="font-mono text-amber-400 font-bold text-sm bg-slate-900 px-2 py-0.5 rounded border border-slate-800">
                    {paymentModalSeries.upiId || instituteUpi.upiId}
                  </span>
                  <button
                    type="button"
                    onClick={handleCopyUpi}
                    className="p-1 bg-slate-800 hover:bg-slate-700 rounded text-slate-300 transition-colors"
                    title="Copy UPI ID"
                  >
                    {copiedUpi ? (
                      <Check className="w-3.5 h-3.5 text-emerald-400" />
                    ) : (
                      <Copy className="w-3.5 h-3.5" />
                    )}
                  </button>
                </div>
              </div>
            </div>

            <div className="p-3 bg-slate-950/80 rounded-xl border border-slate-800/80 mb-4 space-y-1.5">
              <div className="flex justify-between text-xs">
                <span className="text-slate-400">Series Amount to Pay:</span>
                <span className="font-black text-emerald-400 text-sm">
                  ₹{paymentModalSeries.price}
                </span>
              </div>
              <p className="text-[11px] text-slate-400 leading-relaxed">
                Scan with Google Pay, PhonePe, Paytm, or any BHIM UPI app.
              </p>
            </div>

            {paymentSuccess ? (
              <div className="p-3 bg-emerald-500/20 border border-emerald-500/40 rounded-xl text-emerald-300 text-center font-bold flex items-center justify-center gap-2">
                <CheckCircle2 className="w-5 h-5 text-emerald-400" />
                <span>Payment Verified! Series Unlocked...</span>
              </div>
            ) : (
              <form onSubmit={handleConfirmPayment} className="space-y-3">
                <div>
                  <label className="block font-semibold text-slate-300 mb-1">
                    UPI 12-Digit Reference / UTR Number
                  </label>
                  <input
                    type="text"
                    value={upiTxnId}
                    onChange={(e) => setUpiTxnId(e.target.value)}
                    placeholder="e.g. 408912345678 (or leave blank for demo instant verify)"
                    className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-lg text-white font-mono text-xs focus:border-amber-500"
                  />
                </div>

                <button
                  type="submit"
                  className="w-full py-2.5 px-4 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-bold rounded-xl shadow-md shadow-emerald-600/20 transition-all flex items-center justify-center gap-2"
                >
                  <Unlock className="w-4 h-4" />
                  Verify Payment & Unlock Series Now
                </button>
              </form>
            )}
          </div>
        </div>
      )}

      {/* Official Institute Footer (Minimal) */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mt-12 pt-6 border-t border-slate-800 text-xs text-slate-400">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <ArgonLogo size="sm" theme="dark" showText={true} />
            <span className="hidden sm:inline text-slate-600">|</span>
            <p className="text-[11px] text-slate-400">
              HouseNo. 1A, Chinaki path, GS Rd, Rukmini Gaon, Guwahati, Assam 781006
            </p>
          </div>
          <div className="flex items-center gap-4 text-[11px]">
            <a href="tel:06000730250" className="flex items-center gap-1 text-slate-300 hover:text-amber-400 transition-colors">
              <Phone className="w-3.5 h-3.5 text-amber-400" />
              <span>060007 30250</span>
            </a>
            <a
              href="https://www.argoncoaching.com"
              target="_blank"
              rel="noreferrer"
              className="flex items-center gap-1 text-slate-300 hover:text-indigo-400 transition-colors"
            >
              <Globe className="w-3.5 h-3.5 text-indigo-400" />
              <span>www.argoncoaching.com</span>
            </a>
          </div>
        </div>
      </div>
    </div>
  );
};
