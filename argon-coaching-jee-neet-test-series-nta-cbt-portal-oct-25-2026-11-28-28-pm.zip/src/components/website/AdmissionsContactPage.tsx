import React, { useState } from 'react';
import {
  MapPin,
  Phone,
  Mail,
  Clock,
  Send,
  CheckCircle2,
  AlertCircle,
  Award,
  Sparkles,
  Calendar,
  FileCheck,
  Building,
  ArrowRight,
  Globe,
} from 'lucide-react';
import { ArgonLogo } from '../ArgonLogo.tsx';

export const AdmissionsContactPage: React.FC = () => {
  const [studentName, setStudentName] = useState('');
  const [studentPhone, setStudentPhone] = useState('');
  const [studentEmail, setStudentEmail] = useState('');
  const [currentGrade, setCurrentGrade] = useState('Class 11 Moving');
  const [targetExam, setTargetExam] = useState('JEE (Main & Advanced)');
  const [message, setMessage] = useState('');
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (!studentName.trim() || !studentPhone.trim()) {
      setError('Please provide your full name and contact phone number.');
      return;
    }

    setSubmitting(true);
    setTimeout(() => {
      setSubmitting(false);
      setIsSubmitted(true);
    }, 600);
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto mb-14">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-amber-500/10 border border-amber-500/20 text-amber-300 text-xs font-semibold mb-3">
            <Sparkles className="w-4 h-4 text-amber-400" />
            <span>Admissions Open for Session 2026 - 2027</span>
          </div>
          <h1 className="text-3xl sm:text-4xl lg:text-5xl font-black text-white tracking-tight">
            Admissions & Center Contact
          </h1>
          <p className="mt-3 text-slate-300 text-sm sm:text-base leading-relaxed">
            Visit our Guwahati campus in Rukmini Gaon or request an immediate counseling callback from our senior IITian academic advisors.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 mb-16">
          {/* Left Column: Inquiry Form & Scholarship details */}
          <div className="lg:col-span-7 bg-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-8 shadow-xl">
            <div className="mb-6">
              <span className="text-xs font-bold text-indigo-400 uppercase tracking-widest">
                Direct Application & Callback
              </span>
              <h2 className="text-2xl font-black text-white mt-1">
                Book Free Counseling & Scholarship Test
              </h2>
              <p className="text-xs text-slate-400 mt-1">
                Fill the details below. Our academic dean will contact you within 2 business hours.
              </p>
            </div>

            {isSubmitted ? (
              <div className="text-center py-12 space-y-4">
                <div className="w-16 h-16 rounded-2xl bg-emerald-500/20 border border-emerald-500/40 text-emerald-400 flex items-center justify-center mx-auto shadow-lg shadow-emerald-950/40">
                  <CheckCircle2 className="w-10 h-10" />
                </div>
                <h3 className="text-2xl font-black text-white">Inquiry Received!</h3>
                <p className="text-sm text-slate-300 max-w-md mx-auto leading-relaxed">
                  Thank you, <strong className="text-white">{studentName}</strong>. Our Guwahati academic team has received your inquiry for <strong>{targetExam}</strong>.
                </p>
                <div className="p-4 bg-slate-950 border border-slate-800 rounded-2xl max-w-sm mx-auto text-xs text-slate-400 space-y-1">
                  <p>Admissions Office: <strong className="text-amber-400">060007 30250</strong></p>
                  <p>Campus: Rukmini Gaon, GS Road, Guwahati</p>
                </div>
                <button
                  onClick={() => {
                    setIsSubmitted(false);
                    setStudentName('');
                    setStudentPhone('');
                    setStudentEmail('');
                  }}
                  className="px-6 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-white text-xs font-bold transition-colors"
                >
                  Submit Another Inquiry
                </button>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-4">
                {error && (
                  <div className="p-3 rounded-xl bg-rose-500/15 border border-rose-500/30 text-rose-300 text-xs flex items-center gap-2">
                    <AlertCircle className="w-4 h-4 shrink-0" />
                    <span>{error}</span>
                  </div>
                )}

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                      Student Full Name *
                    </label>
                    <input
                      type="text"
                      value={studentName}
                      onChange={(e) => setStudentName(e.target.value)}
                      placeholder="e.g. Rahul Sharma"
                      className="w-full px-4 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-white placeholder-slate-500 text-xs focus:outline-none focus:border-indigo-500"
                      required
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                      Contact Phone Number *
                    </label>
                    <input
                      type="tel"
                      value={studentPhone}
                      onChange={(e) => setStudentPhone(e.target.value)}
                      placeholder="e.g. 98765 43210"
                      className="w-full px-4 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-white placeholder-slate-500 text-xs focus:outline-none focus:border-indigo-500"
                      required
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                      Email Address (Optional)
                    </label>
                    <input
                      type="email"
                      value={studentEmail}
                      onChange={(e) => setStudentEmail(e.target.value)}
                      placeholder="e.g. rahul@example.com"
                      className="w-full px-4 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-white placeholder-slate-500 text-xs focus:outline-none focus:border-indigo-500"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                      Current Grade / Standing
                    </label>
                    <select
                      value={currentGrade}
                      onChange={(e) => setCurrentGrade(e.target.value)}
                      className="w-full px-4 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-white text-xs focus:outline-none focus:border-indigo-500"
                    >
                      <option>Class 10 Moving to 11</option>
                      <option>Class 11 Moving to 12</option>
                      <option>Class 12 Appearing</option>
                      <option>12th Passed / Repeater</option>
                      <option>Class 8 or 9 (Foundation)</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                    Target Competitive Exam
                  </label>
                  <select
                    value={targetExam}
                    onChange={(e) => setTargetExam(e.target.value)}
                    className="w-full px-4 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-white text-xs focus:outline-none focus:border-indigo-500"
                  >
                    <option>JEE (Main & Advanced)</option>
                    <option>NEET-UG (Medical)</option>
                    <option>Foundation (Olympiads / NTSE)</option>
                    <option>Online CBT Mock Test Series Only</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                    Specific Questions or Career Goal (Optional)
                  </label>
                  <textarea
                    rows={3}
                    value={message}
                    onChange={(e) => setMessage(e.target.value)}
                    placeholder="Tell us about your previous preparation or queries about hostel/transport..."
                    className="w-full px-4 py-2 rounded-xl bg-slate-950 border border-slate-800 text-white placeholder-slate-500 text-xs focus:outline-none focus:border-indigo-500 resize-none"
                  />
                </div>

                <button
                  type="submit"
                  disabled={submitting}
                  className="w-full py-3 px-6 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 text-slate-950 font-black text-sm shadow-xl shadow-amber-500/20 transition-all flex items-center justify-center gap-2"
                >
                  <Send className="w-4 h-4" />
                  <span>{submitting ? 'Submitting Inquiry...' : 'Submit Admission Inquiry & Book Counseling'}</span>
                </button>
              </form>
            )}
          </div>

          {/* Right Column: Guwahati Campus Info & Direct Hotline */}
          <div className="lg:col-span-5 space-y-6">
            {/* Campus Contact Card */}
            <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-8 shadow-xl">
              <div className="flex items-center gap-3 mb-6">
                <ArgonLogo size="sm" theme="dark" />
                <div>
                  <h3 className="font-bold text-white text-base">Guwahati Head Campus</h3>
                  <p className="text-xs text-amber-400 font-semibold">Argon Coaching Academy Assam</p>
                </div>
              </div>

              <div className="space-y-4 text-xs">
                <div className="flex items-start gap-3 p-3.5 rounded-xl bg-slate-950 border border-slate-800">
                  <MapPin className="w-5 h-5 text-rose-400 shrink-0 mt-0.5" />
                  <div>
                    <p className="font-bold text-white mb-0.5">Physical Campus Address</p>
                    <p className="text-slate-300 leading-relaxed">
                      HouseNo. 1A, Chinaki Path, GS Road, Rukmini Gaon, Guwahati, Assam 781006
                    </p>
                    <p className="text-[10px] text-slate-500 mt-1">Landmark: Opposite Rukmini Gaon Bus Stop, GS Road</p>
                  </div>
                </div>

                <div className="flex items-start gap-3 p-3.5 rounded-xl bg-slate-950 border border-slate-800">
                  <Phone className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
                  <div>
                    <p className="font-bold text-white mb-0.5">Direct Admission Helpline</p>
                    <a
                      href="tel:06000730250"
                      className="text-sm font-black text-amber-300 font-mono hover:underline"
                    >
                      060007 30250
                    </a>
                    <p className="text-[10px] text-slate-500 mt-0.5">Available 8:00 AM - 8:00 PM (Mon - Sun)</p>
                  </div>
                </div>

                <div className="flex items-start gap-3 p-3.5 rounded-xl bg-slate-950 border border-slate-800">
                  <Mail className="w-5 h-5 text-indigo-400 shrink-0 mt-0.5" />
                  <div>
                    <p className="font-bold text-white mb-0.5">Official Inquiries</p>
                    <p className="text-slate-300 font-mono text-[11px]">admissions@argoncoaching.com</p>
                    <a
                      href="https://www.argoncoaching.com"
                      target="_blank"
                      rel="noreferrer"
                      className="text-[11px] text-indigo-400 hover:underline block mt-0.5"
                    >
                      www.argoncoaching.com
                    </a>
                  </div>
                </div>

                <div className="flex items-start gap-3 p-3.5 rounded-xl bg-slate-950 border border-slate-800">
                  <Clock className="w-5 h-5 text-emerald-400 shrink-0 mt-0.5" />
                  <div>
                    <p className="font-bold text-white mb-0.5">Campus Working Hours</p>
                    <p className="text-slate-300">Monday – Saturday: 8:00 AM – 7:30 PM</p>
                    <p className="text-slate-300">Sunday: 9:00 AM – 4:00 PM (Mock Tests & Counseling)</p>
                  </div>
                </div>
              </div>
            </div>

            {/* ASCAT Scholarship Highlight */}
            <div className="bg-gradient-to-br from-indigo-950/80 to-slate-900 border border-indigo-500/30 rounded-3xl p-6 shadow-xl">
              <div className="flex items-center gap-2.5 text-xs font-bold text-indigo-300 mb-2">
                <Award className="w-4 h-4 text-indigo-400" />
                <span>Argon Scholarship Cum Admission Test (ASCAT)</span>
              </div>
              <h4 className="font-black text-white text-lg mb-2">Up to 100% Fee Waiver</h4>
              <p className="text-xs text-slate-300 leading-relaxed mb-4">
                Deserving and meritorious students from Assam & Northeast receive significant fee scholarships. Next test date: <strong>Every Sunday at Guwahati Campus or Online</strong>.
              </p>
              <div className="flex items-center gap-2 text-xs text-emerald-400 font-semibold">
                <CheckCircle2 className="w-4 h-4 shrink-0" />
                <span>Zero registration fee for government school students</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
