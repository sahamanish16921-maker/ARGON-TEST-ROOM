import React, { useState } from 'react';
import { useApp } from '../../context/AppContext.tsx';
import {
  GraduationCap,
  Calendar,
  Clock,
  CheckCircle2,
  Users,
  Award,
  ArrowRight,
  BookOpen,
  Sparkles,
  PhoneCall,
  FileCheck,
  Zap,
} from 'lucide-react';

interface CoursesPageProps {
  onOpenAuth: (defaultTab: 'faculty' | 'student') => void;
}

export const CoursesPage: React.FC<CoursesPageProps> = ({ onOpenAuth }) => {
  const { setCurrentView } = useApp();
  const [selectedExamFilter, setSelectedExamFilter] = useState<'ALL' | 'JEE' | 'NEET' | 'FOUNDATION'>('ALL');

  const COURSES = [
    {
      id: 'course-jee-2yr',
      category: 'JEE',
      badge: 'Most Popular',
      title: 'PINNACLE: 2-Year Classroom Program for JEE (Main & Advanced)',
      targetClass: 'Class 11 Students (Moving to Class 12)',
      duration: '2 Years (2026 - 2028)',
      hoursPerWeek: '16-18 Hours Classroom + Daily Doubt Hours',
      description:
        'Comprehensive classroom curriculum covering Class 11th and 12th syllabus thoroughly from fundamental board level to deep conceptual multi-concept JEE Advanced problem solving.',
      highlights: [
        'Complete coverage of Physics, Chemistry & Mathematics',
        'Daily Practice Problem (DPP) sheets with classroom discussion',
        'Fortnightly NTA-pattern Computer Based Tests (CBT)',
        'Personal mentor assigned for progress monitoring & motivation',
        'Printed study packages with 15,000+ graded practice problems',
        'Special Olympiad & KVPY enrichment modules',
      ],
      batchStarts: '15th April 2026 / 1st May 2026',
      scholarshipAvailable: 'Up to 100% via ASCAT Exam',
    },
    {
      id: 'course-jee-1yr',
      category: 'JEE',
      badge: 'Target 2027',
      title: 'APEX: 1-Year Fast-Track Target Program for JEE Main & Adv',
      targetClass: 'Class 12 Students',
      duration: '1 Year (2026 - 2027)',
      hoursPerWeek: '20 Hours Intensive Classroom + NTA Mock Tests',
      description:
        'Targeted for 12th appearing students aiming for top percentiles in JEE Main (Session 1 & 2) and selection in premier IITs with integrated CBSE/State Board preparation.',
      highlights: [
        'Rapid Class 11th foundational revision alongside Class 12th',
        'Rigorous past 15 years NTA JEE Main and JEE Advanced analysis',
        'Argon Test Series access with authentic NTA exam engine',
        'Weekly rank predictor and individual weakness remediation',
        'Formula handbooks and mind-maps for rapid revision',
      ],
      batchStarts: '25th April 2026',
      scholarshipAvailable: 'Up to 75% via ASCAT Exam',
    },
    {
      id: 'course-jee-repeater',
      category: 'JEE',
      badge: 'Super 30 Batch',
      title: 'CONQUEROR: Dropper & Repeater Rank Accelerator for JEE',
      targetClass: '12th Passed Aspirants (Gap Year)',
      duration: '10 Months Intensive',
      hoursPerWeek: '24+ Hours Structured Problem Solving & Tests',
      description:
        'Specially formulated for dedicated repeaters seeking to convert their knowledge into top 99.8+ percentiles. Strictly limited to small batch sizes with individual faculty guidance.',
      highlights: [
        'Zero-theory waste: Focus on conceptual shortcuts & time-management',
        'Full syllabus completed before Session 1 (January)',
        '30+ Full Syllabus All-India CBT Mocks with AI percentile predictor',
        'Direct 1-on-1 daily cabin doubt clearance with Senior IITian faculty',
        'Special problem-solving sessions on trick questions & numerical traps',
      ],
      batchStarts: '10th June 2026',
      scholarshipAvailable: 'Merit-based fee concession available',
    },
    {
      id: 'course-neet-2yr',
      category: 'NEET',
      badge: 'Medical Excellence',
      title: 'PULSE: 2-Year Comprehensive Medical Program for NEET-UG',
      targetClass: 'Class 11 Students (Moving to Class 12)',
      duration: '2 Years (2026 - 2028)',
      hoursPerWeek: '18 Hours Classroom + NCERT Line-by-Line Labs',
      description:
        'Precision NEET preparation designed to secure 680+ marks for admission in top government medical colleges including AIIMS New Delhi, JIPMER, and GMC Guwahati.',
      highlights: [
        'Line-by-line NCERT Biology mastery with 3,000+ diagrammatic questions',
        'Strong numerical focus on NEET Physics to turn weakness into strength',
        'Organic & Inorganic Chemistry high-yield memory retention techniques',
        'OMR sheet + Computer Based Test practice for maximum exam speed',
        'Special botany and zoology specimen review workshops',
      ],
      batchStarts: '20th April 2026',
      scholarshipAvailable: 'Up to 100% via ASCAT Exam',
    },
    {
      id: 'course-neet-repeater',
      category: 'NEET',
      badge: 'Target 700+',
      title: 'MED-APEX: Repeater / Dropper Target Batch for NEET-UG',
      targetClass: '12th Passed Medical Aspirants',
      duration: '10 Months Intensive',
      hoursPerWeek: '26 Hours Classroom & Rigorous Test Series',
      description:
        'A high-intensity program designed for students wanting to bridge the 500-to-680+ mark gap. Focuses rigorously on negative marking reduction and NCERT precision.',
      highlights: [
        'Daily timed 45-question speed tests matching real NEET pressure',
        'Negative marking reduction strategy & question-skipping discipline',
        'Complete revision of Class 11 and 12 NCERT 4 times before exam',
        'Full-length 720-mark mock tests every Sunday with live analysis',
      ],
      batchStarts: '5th June 2026',
      scholarshipAvailable: 'Scholarships for 500+ NEET scorers',
    },
    {
      id: 'course-foundation',
      category: 'FOUNDATION',
      badge: 'Early Edge',
      title: 'IGNITE: Foundation Program for Classes 9 & 10',
      targetClass: 'Class 9th & 10th School Students',
      duration: '1 or 2 Years Integrated',
      hoursPerWeek: '10-12 Hours Weekend & Evening Batches',
      description:
        'Builds rock-solid scientific intuition, logical reasoning, and competitive temperament early so students glide effortlessly into JEE/NEET preparation in Class 11.',
      highlights: [
        'Deep conceptual understanding of Science and Mathematics',
        'Preparation for Olympiads (NSEJS, NSO, IMO), NTSE, and School Boards',
        'Mental ability and logical deduction enhancement sessions',
        'Interactive experiments and visual animations for abstract concepts',
      ],
      batchStarts: '1st May 2026',
      scholarshipAvailable: 'Up to 50% on School Marks',
    },
  ];

  const filteredCourses =
    selectedExamFilter === 'ALL'
      ? COURSES
      : COURSES.filter((c) => c.category === selectedExamFilter);

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Page Header */}
        <div className="text-center max-w-3xl mx-auto mb-12">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-indigo-500/10 border border-indigo-500/20 text-indigo-300 text-xs font-semibold mb-3">
            <GraduationCap className="w-4 h-4 text-indigo-400" />
            <span>Classroom & Digital Programs • Guwahati Campus</span>
          </div>
          <h1 className="text-3xl sm:text-4xl lg:text-5xl font-black text-white tracking-tight">
            Academic Programs & Batches
          </h1>
          <p className="mt-3 text-slate-300 text-sm sm:text-base leading-relaxed">
            Meticulously planned courses designed by Assam's senior-most IITian & Doctor faculty. Small batch sizes, daily doubt resolution, and authentic NTA CBT testing.
          </p>

          {/* Filter Pills */}
          <div className="flex flex-wrap items-center justify-center gap-2 mt-8">
            {[
              { id: 'ALL', label: 'All Programs' },
              { id: 'JEE', label: 'JEE (Main & Advanced)' },
              { id: 'NEET', label: 'NEET-UG (Medical)' },
              { id: 'FOUNDATION', label: 'Foundation (Class 9-10)' },
            ].map((f) => (
              <button
                key={f.id}
                onClick={() => setSelectedExamFilter(f.id as any)}
                className={`px-4 py-2 rounded-xl text-xs font-bold transition-all ${
                  selectedExamFilter === f.id
                    ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-600/30'
                    : 'bg-slate-900 border border-slate-800 text-slate-400 hover:text-white hover:bg-slate-800'
                }`}
              >
                {f.label}
              </button>
            ))}
          </div>
        </div>

        {/* Courses Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-16">
          {filteredCourses.map((course) => (
            <div
              key={course.id}
              className="bg-slate-900/90 border border-slate-800 rounded-3xl p-6 sm:p-8 flex flex-col justify-between hover:border-slate-700 transition-all shadow-xl hover:shadow-2xl hover:shadow-indigo-950/20"
            >
              <div>
                <div className="flex items-center justify-between mb-4">
                  <span
                    className={`text-xs font-black uppercase tracking-wider px-3 py-1 rounded-full ${
                      course.category === 'NEET'
                        ? 'bg-emerald-500/15 text-emerald-300 border border-emerald-500/30'
                        : course.category === 'FOUNDATION'
                        ? 'bg-amber-500/15 text-amber-300 border border-amber-500/30'
                        : 'bg-indigo-500/15 text-indigo-300 border border-indigo-500/30'
                    }`}
                  >
                    {course.category}
                  </span>
                  <span className="text-xs font-semibold px-2.5 py-1 rounded-lg bg-amber-500/15 border border-amber-500/30 text-amber-300">
                    {course.badge}
                  </span>
                </div>

                <h3 className="text-xl sm:text-2xl font-black text-white leading-snug mb-3">
                  {course.title}
                </h3>

                <p className="text-sm text-slate-300 leading-relaxed mb-6">
                  {course.description}
                </p>

                {/* Details Badges */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mb-6 p-4 rounded-2xl bg-slate-950/70 border border-slate-800/80 text-xs text-slate-300">
                  <div className="flex items-center gap-2">
                    <Users className="w-4 h-4 text-indigo-400 shrink-0" />
                    <span>Target: <strong>{course.targetClass}</strong></span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Calendar className="w-4 h-4 text-emerald-400 shrink-0" />
                    <span>Duration: <strong>{course.duration}</strong></span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Clock className="w-4 h-4 text-amber-400 shrink-0" />
                    <span>Hours: <strong>{course.hoursPerWeek}</strong></span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Award className="w-4 h-4 text-rose-400 shrink-0" />
                    <span>Scholarship: <strong>{course.scholarshipAvailable}</strong></span>
                  </div>
                </div>

                {/* Key Highlights */}
                <div className="space-y-2.5 mb-6">
                  <p className="text-xs font-bold text-slate-200 uppercase tracking-wider">
                    Program Curriculum Highlights:
                  </p>
                  {course.highlights.map((h, i) => (
                    <div key={i} className="flex items-start gap-2.5 text-xs text-slate-300">
                      <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                      <span>{h}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Bottom Actions */}
              <div className="pt-6 border-t border-slate-800 flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-4">
                <div>
                  <span className="text-[11px] text-slate-400 block">Upcoming Batch Starts:</span>
                  <span className="text-xs font-bold text-emerald-400">{course.batchStarts}</span>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={() => setCurrentView('admissions')}
                    className="flex-1 sm:flex-none px-4 py-2.5 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-bold text-xs shadow-md transition-all flex items-center justify-center gap-2"
                  >
                    <span>Apply / Inquire</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>

                  <button
                    onClick={() => onOpenAuth('student')}
                    className="flex-1 sm:flex-none px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold text-xs border border-slate-700 transition-all flex items-center justify-center gap-2"
                  >
                    <BookOpen className="w-3.5 h-3.5 text-indigo-400" />
                    <span>Test Portal</span>
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Institute Methodology Banner */}
        <div className="bg-gradient-to-br from-indigo-950/60 via-slate-900 to-slate-900 border border-indigo-500/30 rounded-3xl p-8 sm:p-10 mb-12">
          <div className="max-w-3xl">
            <span className="text-xs font-bold text-indigo-400 uppercase tracking-widest">
              The Argon Advantage
            </span>
            <h2 className="text-2xl sm:text-3xl font-black text-white mt-1 mb-4">
              Why Parents & Top Rankers Choose Argon Coaching Guwahati
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-6">
              <div className="bg-slate-950/60 p-4 rounded-2xl border border-slate-800">
                <div className="w-8 h-8 rounded-lg bg-indigo-500/20 text-indigo-400 flex items-center justify-center font-bold mb-3">
                  01
                </div>
                <h4 className="font-bold text-sm text-white mb-1">Max 35 Students / Batch</h4>
                <p className="text-xs text-slate-400">
                  No 200-student crowded factory halls. Every student is known by name and receives customized mentoring.
                </p>
              </div>

              <div className="bg-slate-950/60 p-4 rounded-2xl border border-slate-800">
                <div className="w-8 h-8 rounded-lg bg-emerald-500/20 text-emerald-400 flex items-center justify-center font-bold mb-3">
                  02
                </div>
                <h4 className="font-bold text-sm text-white mb-1">Daily Dedicated Doubt Lab</h4>
                <p className="text-xs text-slate-400">
                  Full-time faculty stay back at the Guwahati center until 7:30 PM to resolve every single question in person.
                </p>
              </div>

              <div className="bg-slate-950/60 p-4 rounded-2xl border border-slate-800">
                <div className="w-8 h-8 rounded-lg bg-amber-500/20 text-amber-400 flex items-center justify-center font-bold mb-3">
                  03
                </div>
                <h4 className="font-bold text-sm text-white mb-1">Authentic NTA CBT Software</h4>
                <p className="text-xs text-slate-400">
                  Students practice in the real NTA interface used in actual JEE and NEET exams, eliminating computer anxiety.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
