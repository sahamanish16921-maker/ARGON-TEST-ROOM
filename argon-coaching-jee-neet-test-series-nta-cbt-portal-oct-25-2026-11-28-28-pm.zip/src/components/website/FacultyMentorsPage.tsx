import React from 'react';
import { useApp } from '../../context/AppContext.tsx';
import { INITIAL_FACULTY_PROFILES } from '../../data/seedData.ts';
import {
  Award,
  BookOpen,
  GraduationCap,
  Sparkles,
  CheckCircle2,
  Phone,
  ArrowRight,
  MapPin,
  HeartHandshake,
  Clock,
  Mail,
} from 'lucide-react';

interface FacultyMentorsPageProps {
  onOpenAuth: (defaultTab: 'faculty' | 'student') => void;
}

export const FacultyMentorsPage: React.FC<FacultyMentorsPageProps> = ({ onOpenAuth }) => {
  const { setCurrentView, facultyProfiles } = useApp();

  const displayFaculty =
    facultyProfiles && facultyProfiles.length > 0
      ? facultyProfiles
      : INITIAL_FACULTY_PROFILES;

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto mb-14">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-amber-500/10 border border-amber-500/20 text-amber-300 text-xs font-semibold mb-3">
            <Award className="w-4 h-4 text-amber-400" />
            <span>Guwahati's Most Qualified Academic Mentors</span>
          </div>
          <h1 className="text-3xl sm:text-4xl lg:text-5xl font-black text-white tracking-tight">
            Meet Your Expert Mentors
          </h1>
          <p className="mt-3 text-slate-300 text-sm sm:text-base leading-relaxed">
            At Argon Coaching, classes are taken exclusively by seasoned IITian, Ph.D., and Doctor educators—never temporary tutors or fresh college trainees.
          </p>
        </div>

        {/* Faculty Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-16">
          {displayFaculty.map((faculty) => (
            <div
              key={faculty.id}
              className="bg-slate-900/90 border border-slate-800 rounded-3xl p-6 sm:p-8 hover:border-slate-700 transition-all shadow-xl flex flex-col justify-between"
            >
              <div>
                <div className="flex flex-col sm:flex-row items-start sm:items-center gap-4 mb-5">
                  <img
                    src={faculty.avatar}
                    alt={faculty.name}
                    className="w-20 h-20 rounded-2xl object-cover border-2 border-slate-700 shadow-md shrink-0 bg-slate-800"
                  />
                  <div>
                    <h3 className="text-xl font-bold text-white">{faculty.name}</h3>
                    <p className="text-xs font-bold text-amber-400 mt-0.5">{faculty.role}</p>
                    <p className="text-[11px] text-slate-400 mt-1 font-medium">{faculty.qualification}</p>
                    {faculty.department && (
                      <span className="inline-block mt-1 px-2 py-0.5 rounded text-[10px] font-bold bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
                        {faculty.department} Department
                      </span>
                    )}
                  </div>
                </div>

                <p className="text-xs sm:text-sm text-slate-300 leading-relaxed mb-4">
                  {faculty.bio}
                </p>

                {/* Quote */}
                {faculty.quote && (
                  <div className="p-3.5 rounded-xl bg-slate-950/80 border-l-4 border-amber-500 mb-5 text-xs italic text-slate-300">
                    {faculty.quote}
                  </div>
                )}

                {/* Specialties & Track Record */}
                <div className="space-y-3 mb-4">
                  {faculty.subjects && faculty.subjects.length > 0 && (
                    <div>
                      <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block mb-1.5">
                        Core Subject Focus:
                      </span>
                      <div className="flex flex-wrap gap-1.5">
                        {faculty.subjects.map((sub, i) => (
                          <span
                            key={i}
                            className="px-2.5 py-1 rounded-md bg-slate-800 text-[11px] text-indigo-300 border border-slate-700/60"
                          >
                            {sub}
                          </span>
                        ))}
                      </div>
                    </div>
                  )}

                  {faculty.trackRecord && (
                    <div className="p-3 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-xs text-emerald-300 flex items-center gap-2">
                      <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                      <span>Track Record: <strong>{faculty.trackRecord}</strong></span>
                    </div>
                  )}

                  {faculty.availableTimings && (
                    <div className="p-3 rounded-xl bg-amber-500/10 border border-amber-500/20 text-xs text-amber-300 flex items-center gap-2 font-mono">
                      <Clock className="w-4 h-4 text-amber-400 shrink-0" />
                      <span>Doubt Clearance: <strong>{faculty.availableTimings}</strong></span>
                    </div>
                  )}
                </div>
              </div>

              <div className="pt-4 border-t border-slate-800 flex items-center justify-between">
                <span className="text-[11px] text-slate-400">Available daily for 1-on-1 doubts at Guwahati center</span>
                <button
                  onClick={() => setCurrentView('admissions')}
                  className="px-3 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs transition-colors flex items-center gap-1.5"
                >
                  <span>Book Demo Class</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          ))}
        </div>

        {/* Mentorship Philosophy */}
        <div className="bg-slate-900 border border-slate-800 rounded-3xl p-8 sm:p-10 mb-12">
          <div className="max-w-3xl mx-auto text-center">
            <span className="text-xs font-bold text-indigo-400 uppercase tracking-widest">
              Argon Coaching Educational Promise
            </span>
            <h2 className="text-2xl sm:text-3xl font-black text-white mt-1 mb-4">
              "We Don't Just Teach; We Mentor Until You Cross The Finish Line"
            </h2>
            <p className="text-sm text-slate-300 leading-relaxed mb-6">
              Preparing for JEE & NEET can be emotionally demanding. Our teachers act as academic mentors, guiding study routines, exam-day temperament, and continuous error corrections through detailed CBT analytics.
            </p>
            <div className="flex flex-wrap items-center justify-center gap-4">
              <button
                onClick={() => setCurrentView('admissions')}
                className="px-6 py-3 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 text-slate-950 font-bold text-xs shadow-lg transition-all"
              >
                Schedule Counseling Session with Faculty
              </button>
              <a
                href="tel:06000730250"
                className="px-5 py-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold text-xs border border-slate-700 transition-all flex items-center gap-2"
              >
                <Phone className="w-4 h-4 text-amber-400" />
                <span>Call Center: 060007 30250</span>
              </a>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
