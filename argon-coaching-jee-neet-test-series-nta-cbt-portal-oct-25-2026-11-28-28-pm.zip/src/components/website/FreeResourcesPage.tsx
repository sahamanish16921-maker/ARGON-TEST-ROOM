import React, { useState } from 'react';
import { useApp } from '../../context/AppContext.tsx';
import {
  BookOpen,
  FileText,
  Download,
  CheckCircle2,
  Sparkles,
  ArrowRight,
  ExternalLink,
  GraduationCap,
} from 'lucide-react';

export const FreeResourcesPage: React.FC = () => {
  const { setCurrentView, materials } = useApp();
  const [activeCategory, setActiveCategory] = useState<'ALL' | 'JEE' | 'NEET' | 'FORMULAS'>('ALL');

  const combinedResources = [
    ...(materials || []).map((m) => ({
      id: m.id,
      category: m.category,
      type: m.type,
      title: m.title,
      description: m.description,
      downloads: 'Live from Faculty',
      size: m.size || '3.5 MB',
      isHot: m.isHot || false,
    })),
    {
      id: 'res-pyq-jee',
      category: 'JEE',
      type: 'Solved Papers',
      title: 'JEE Main (2020-2025) Official NTA Question Papers with Explanations',
      description: 'Chapter-wise compilation of all shifts question papers with step-by-step video solutions and sectional cutoff analysis.',
      downloads: '32,000+ Downloads',
      size: '15.4 MB',
      isHot: true,
    },
    {
      id: 'res-pyq-neet',
      category: 'NEET',
      type: 'Solved Papers',
      title: 'NEET-UG Past 10 Years Question Papers with NCERT Reference Citations',
      description: 'Each question tagged with the exact NCERT textbook page number to verify authenticity and revision depth.',
      downloads: '28,900+ Downloads',
      size: '12.1 MB',
      isHot: true,
    },
  ];

  const filtered =
    activeCategory === 'ALL'
      ? combinedResources
      : combinedResources.filter((r) => r.category === activeCategory);

  const [downloadNotice, setDownloadNotice] = useState<string | null>(null);

  const handleDownload = (title: string) => {
    setDownloadNotice(`Downloading "${title}"... In production, verified students can access the full Google Drive resource library.`);
    setTimeout(() => {
      setDownloadNotice(null);
    }, 4500);
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto mb-14">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-indigo-500/10 border border-indigo-500/20 text-indigo-300 text-xs font-semibold mb-3">
            <BookOpen className="w-4 h-4 text-indigo-400" />
            <span>Open Access Study Library • For Aspirants Worldwide</span>
          </div>
          <h1 className="text-3xl sm:text-4xl lg:text-5xl font-black text-white tracking-tight">
            Free Study Material & PYQs
          </h1>
          <p className="mt-3 text-slate-300 text-sm sm:text-base leading-relaxed">
            Curated by Argon Coaching's senior subject heads to assist students with quick revision formula sheets, high-yield mindmaps, and past 5 years official papers.
          </p>

          {/* Filter Pills */}
          <div className="flex flex-wrap items-center justify-center gap-2 mt-8">
            {[
              { id: 'ALL', label: 'All Resources' },
              { id: 'JEE', label: 'JEE Main & Advanced' },
              { id: 'NEET', label: 'NEET Biology & Medical' },
              { id: 'FORMULAS', label: 'Formula Handbooks' },
            ].map((f) => (
              <button
                key={f.id}
                onClick={() => setActiveCategory(f.id as any)}
                className={`px-4 py-2 rounded-xl text-xs font-bold transition-all ${
                  activeCategory === f.id
                    ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-600/30'
                    : 'bg-slate-900 border border-slate-800 text-slate-400 hover:text-white'
                }`}
              >
                {f.label}
              </button>
            ))}
          </div>
        </div>

        {downloadNotice && (
          <div className="mb-8 p-4 rounded-2xl bg-indigo-500/20 border border-indigo-500/40 text-indigo-300 text-xs flex items-center justify-between max-w-2xl mx-auto animate-fadeIn">
            <div className="flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
              <span>{downloadNotice}</span>
            </div>
          </div>
        )}

        {/* Resources Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-16">
          {filtered.map((item) => (
            <div
              key={item.id}
              className="bg-slate-900 border border-slate-800 rounded-3xl p-6 hover:border-slate-700 transition-all shadow-xl flex flex-col justify-between group"
            >
              <div>
                <div className="flex items-center justify-between mb-3">
                  <span className="text-[10px] font-bold px-2.5 py-0.5 rounded-full uppercase tracking-wider bg-slate-800 text-slate-300 border border-slate-700">
                    {item.type}
                  </span>
                  {item.isHot && (
                    <span className="text-[10px] font-black text-amber-300 bg-amber-500/15 border border-amber-500/30 px-2 py-0.5 rounded flex items-center gap-1">
                      <Sparkles className="w-3 h-3 text-amber-400" />
                      Popular
                    </span>
                  )}
                </div>

                <h3 className="font-bold text-base text-white group-hover:text-amber-300 transition-colors leading-snug mb-2">
                  {item.title}
                </h3>

                <p className="text-xs text-slate-400 leading-relaxed mb-6">
                  {item.description}
                </p>
              </div>

              <div className="pt-4 border-t border-slate-800 flex items-center justify-between">
                <div>
                  <span className="text-[11px] text-slate-500 block">{item.downloads}</span>
                  <span className="text-[10px] text-slate-400 font-mono">PDF • {item.size}</span>
                </div>

                <button
                  onClick={() => handleDownload(item.title)}
                  className="px-3.5 py-1.5 rounded-xl bg-slate-800 hover:bg-indigo-600 text-white font-bold text-xs border border-slate-700 hover:border-indigo-500 transition-all flex items-center gap-1.5"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Download</span>
                </button>
              </div>
            </div>
          ))}
        </div>

        {/* Online Test Portal Callout */}
        <div className="bg-slate-900 border border-slate-800 rounded-3xl p-8 sm:p-10 flex flex-col md:flex-row items-center justify-between gap-6 shadow-2xl">
          <div>
            <h3 className="text-xl sm:text-2xl font-black text-white">
              Ready to test your preparation on computer?
            </h3>
            <p className="text-xs sm:text-sm text-slate-400 mt-1 max-w-xl">
              Access Argon’s authentic National Testing Agency (NTA) computer-based mock tests with live countdown timers, question palettes, and instant percentiles.
            </p>
          </div>

          <button
            onClick={() => setCurrentView('test-series')}
            className="px-6 py-3 rounded-xl bg-gradient-to-r from-indigo-600 to-indigo-700 hover:from-indigo-500 text-white font-black text-xs shadow-lg shadow-indigo-600/30 transition-all flex items-center gap-2 shrink-0"
          >
            <GraduationCap className="w-4 h-4" />
            <span>Launch CBT Test Series Portal</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
