import React, { useState } from 'react';
import { useApp } from '../../context/AppContext.tsx';
import {
  BookOpen,
  CheckCircle2,
  Play,
  QrCode,
  Sparkles,
  ArrowRight,
  ShieldCheck,
  GraduationCap,
  Clock,
  FileText,
} from 'lucide-react';

interface PublicTestSeriesPageProps {
  onOpenAuth: (defaultTab: 'faculty' | 'student') => void;
}

export const PublicTestSeriesPage: React.FC<PublicTestSeriesPageProps> = ({ onOpenAuth }) => {
  const { testSeries, tests, role, currentUser, setCurrentView, startExam } = useApp();
  const [selectedFilter, setSelectedFilter] = useState<'ALL' | 'JEE Main' | 'JEE Advanced' | 'NEET'>('ALL');

  const filteredSeries =
    selectedFilter === 'ALL'
      ? testSeries
      : testSeries.filter((s) => s.targetExam === selectedFilter);

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto mb-14">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-indigo-500/10 border border-indigo-500/20 text-indigo-300 text-xs font-semibold mb-3">
            <GraduationCap className="w-4 h-4 text-indigo-400" />
            <span>NTA-Pattern Computer Based Test Series</span>
          </div>
          <h1 className="text-3xl sm:text-4xl lg:text-5xl font-black text-white tracking-tight">
            Online Mock Test Series Portal
          </h1>
          <p className="mt-3 text-slate-300 text-sm sm:text-base leading-relaxed">
            Practice in the exact NTA exam simulation interface. Real-time timer countdown, authentic 5-state question palette, positive/negative marking rules, and instant diagnostic scorecards.
          </p>

          {/* Exam Filters */}
          <div className="flex flex-wrap items-center justify-center gap-2 mt-8">
            {[
              { id: 'ALL', label: 'All Series' },
              { id: 'JEE Main', label: 'JEE Main Mocks' },
              { id: 'JEE Advanced', label: 'JEE Advanced Apex' },
              { id: 'NEET', label: 'NEET-UG Mastery' },
            ].map((f) => (
              <button
                key={f.id}
                onClick={() => setSelectedFilter(f.id as any)}
                className={`px-4 py-2 rounded-xl text-xs font-bold transition-all ${
                  selectedFilter === f.id
                    ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-600/30'
                    : 'bg-slate-900 border border-slate-800 text-slate-400 hover:text-white'
                }`}
              >
                {f.label}
              </button>
            ))}
          </div>
        </div>

        {/* Series Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mb-16">
          {filteredSeries.map((series) => {
            const seriesTests = tests.filter((t) => t.seriesId === series.id);
            const isEnrolled = currentUser?.enrolledSeriesIds?.includes(series.id);

            return (
              <div
                key={series.id}
                className="bg-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-7 flex flex-col justify-between hover:border-slate-700 transition-all shadow-xl hover:shadow-2xl hover:shadow-indigo-950/20 group"
              >
                <div>
                  <div className="flex items-center justify-between mb-4">
                    <span
                      className={`text-xs font-bold px-3 py-1 rounded-full uppercase tracking-wider ${
                        series.targetExam === 'NEET'
                          ? 'bg-emerald-500/15 text-emerald-300 border border-emerald-500/30'
                          : series.targetExam === 'JEE Advanced'
                          ? 'bg-amber-500/15 text-amber-300 border border-amber-500/30'
                          : 'bg-indigo-500/15 text-indigo-300 border border-indigo-500/30'
                      }`}
                    >
                      {series.targetExam}
                    </span>

                    {series.badge && (
                      <span className="text-[11px] font-semibold text-rose-300 bg-rose-500/10 px-2.5 py-0.5 rounded-lg border border-rose-500/20">
                        {series.badge}
                      </span>
                    )}
                  </div>

                  <h3 className="text-xl font-bold text-white group-hover:text-amber-300 transition-colors leading-snug mb-2">
                    {series.title}
                  </h3>

                  <p className="text-xs text-slate-400 leading-relaxed mb-6">
                    {series.description}
                  </p>

                  {/* Highlights */}
                  <div className="space-y-2 mb-6 p-4 rounded-2xl bg-slate-950 border border-slate-800/80">
                    <p className="text-[11px] font-bold text-slate-300 uppercase tracking-wider">
                      Included In This Series:
                    </p>
                    {series.features.map((feat, idx) => (
                      <div key={idx} className="flex items-start gap-2 text-xs text-slate-300">
                        <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                        <span className="leading-snug">{feat}</span>
                      </div>
                    ))}
                  </div>

                  {/* Test count & syllabus breakdown */}
                  <div className="flex items-center gap-3 text-xs text-slate-400 mb-6">
                    <div className="flex items-center gap-1.5">
                      <FileText className="w-4 h-4 text-indigo-400" />
                      <span>{seriesTests.length || series.testsCount || 1} Tests Available</span>
                    </div>
                    <span>•</span>
                    <div className="flex items-center gap-1.5">
                      <Clock className="w-4 h-4 text-amber-400" />
                      <span>180 Mins Duration</span>
                    </div>
                  </div>
                </div>

                <div className="pt-6 border-t border-slate-800 flex items-center justify-between">
                  <div>
                    <div className="flex items-baseline gap-1.5">
                      <span className="text-2xl font-black text-white">
                        {series.price === 0 ? 'FREE' : `₹ ${series.price}`}
                      </span>
                      {series.originalPrice && (
                        <span className="text-xs text-slate-500 line-through">
                          ₹ {series.originalPrice}
                        </span>
                      )}
                    </div>
                    <span className="text-[10px] text-slate-500">Instant UPI Unlock</span>
                  </div>

                  {isEnrolled ? (
                    <button
                      onClick={() => {
                        if (seriesTests.length > 0) {
                          startExam(seriesTests[0].id);
                        } else {
                          setCurrentView('student-dashboard');
                        }
                      }}
                      className="px-4 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs shadow-md transition-all flex items-center gap-1.5"
                    >
                      <Play className="w-3.5 h-3.5" />
                      <span>Launch Test</span>
                    </button>
                  ) : (
                    <button
                      onClick={() => {
                        if (role === 'student') {
                          setCurrentView('student-dashboard');
                        } else {
                          onOpenAuth('student');
                        }
                      }}
                      className={`px-4 py-2.5 rounded-xl font-bold text-xs shadow-md transition-all flex items-center gap-1.5 ${
                        series.price === 0
                          ? 'bg-emerald-600 hover:bg-emerald-500 text-white'
                          : 'bg-indigo-600 hover:bg-indigo-500 text-white'
                      }`}
                    >
                      <span>{series.price === 0 ? 'Access Free' : 'Enroll / Unlock'}</span>
                      <ArrowRight className="w-3.5 h-3.5" />
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>

        {/* NTA Exam Simulation Feature Showcase */}
        <div className="bg-slate-900 border border-slate-800 rounded-3xl p-8 sm:p-10 mb-12">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
            <div>
              <span className="text-xs font-bold text-emerald-400 uppercase tracking-widest">
                Real Testing Experience
              </span>
              <h2 className="text-2xl sm:text-3xl font-black text-white mt-1 mb-4">
                Exact Replica of the NTA Computer-Based Interface
              </h2>
              <p className="text-sm text-slate-300 leading-relaxed mb-6">
                Never enter the exam hall feeling nervous about computer mechanics. Argon's test engine faithfully replicates every single button, color code, and feature of the official NTA testing software.
              </p>
              <div className="space-y-3">
                <div className="flex items-center gap-2.5 text-xs text-slate-300">
                  <div className="w-3 h-3 rounded-full bg-emerald-500"></div>
                  <span><strong>Answered (Green)</strong>: Evaluated for positive & negative marking</span>
                </div>
                <div className="flex items-center gap-2.5 text-xs text-slate-300">
                  <div className="w-3 h-3 rounded-full bg-rose-500"></div>
                  <span><strong>Not Answered (Red)</strong>: Visited but no option chosen</span>
                </div>
                <div className="flex items-center gap-2.5 text-xs text-slate-300">
                  <div className="w-3 h-3 rounded-full bg-purple-500"></div>
                  <span><strong>Marked for Review (Purple)</strong>: Bookmarked for second look</span>
                </div>
                <div className="flex items-center gap-2.5 text-xs text-slate-300">
                  <div className="w-3 h-3 rounded-full bg-slate-600"></div>
                  <span><strong>Not Visited (Grey)</strong>: Unopened questions</span>
                </div>
              </div>
            </div>

            <div className="p-6 rounded-2xl bg-slate-950 border border-slate-800 text-center shadow-2xl">
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-500/20 text-emerald-400 text-xs font-bold mb-4">
                <span>Free Trial Test Available</span>
              </div>
              <h4 className="text-lg font-black text-white mb-2">Try a Live 180-Minute Mock Test Now</h4>
              <p className="text-xs text-slate-400 mb-6">
                Log in as a student to immediately attempt full-length questions with zero cost.
              </p>
              <button
                onClick={() => {
                  if (role === 'student') setCurrentView('student-dashboard');
                  else onOpenAuth('student');
                }}
                className="w-full py-3 px-6 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 text-slate-950 font-black text-xs shadow-lg transition-all flex items-center justify-center gap-2"
              >
                <Play className="w-4 h-4" />
                <span>Launch Free Student CBT Simulator</span>
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
