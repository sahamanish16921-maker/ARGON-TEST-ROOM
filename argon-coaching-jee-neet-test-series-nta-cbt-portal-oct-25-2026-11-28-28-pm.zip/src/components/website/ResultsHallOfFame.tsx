import React, { useState } from 'react';
import { useApp } from '../../context/AppContext.tsx';
import {
  Trophy,
  Medal,
  Star,
  Quote,
  CheckCircle2,
  ArrowRight,
  TrendingUp,
  Building,
  GraduationCap,
} from 'lucide-react';

export const ResultsHallOfFame: React.FC = () => {
  const { setCurrentView } = useApp();
  const [examTab, setExamTab] = useState<'ALL' | 'JEE' | 'NEET'>('ALL');

  const TOP_RANKERS = [
    {
      id: 'ranker-1',
      name: 'Rohan Talukdar',
      exam: 'JEE Advanced 2024',
      rank: 'AIR 142',
      percentile: '99.94%ile',
      college: 'IIT Bombay - Computer Science',
      photo: 'https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?auto=format&fit=crop&w=300&q=80',
      testimonial:
        'Argon Coaching’s NTA CBT simulator was the game-changer for me. Solving tests in the exact authentic exam interface kept me calm on the real day. Manish Sir’s mechanics modules made difficult problems intuitive.',
      hometown: 'Guwahati, Assam',
    },
    {
      id: 'ranker-2',
      name: 'Ananya Baruah',
      exam: 'NEET-UG 2024',
      rank: 'AIR 310',
      percentile: 'Score: 705 / 720',
      college: 'AIIMS New Delhi',
      photo: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?auto=format&fit=crop&w=300&q=80',
      testimonial:
        'Dr. Snigdha Ma’am’s line-by-line NCERT Biology tests made sure I scored 355/360 in Biology alone. The daily doubt clearance at Rukmini Gaon center never let any question linger unanswered.',
      hometown: 'Jorhat, Assam',
    },
    {
      id: 'ranker-3',
      name: 'Debasish Sarma',
      exam: 'JEE Main 2024',
      rank: 'AIR 289',
      percentile: '99.91%ile',
      college: 'IIT Kharagpur - Electronics',
      photo: 'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?auto=format&fit=crop&w=300&q=80',
      testimonial:
        'The small batch size at Argon was critical. In other institutes with 150 students per class, I felt lost. At Argon, teachers noticed whenever my marks dipped and proactively gave me personalized problem sets.',
      hometown: 'Dibrugarh, Assam',
    },
    {
      id: 'ranker-4',
      name: 'Meenakshi Kalita',
      exam: 'NEET-UG 2024',
      rank: 'AIR 645',
      percentile: 'Score: 685 / 720',
      college: 'Gauhati Medical College (GMCH)',
      photo: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=300&q=80',
      testimonial:
        'Physics was always my biggest fear. Dr. Barman and the faculty helped me break it down into high-yield formula clusters. The instant error analysis after every mock test saved me 40+ marks in negative marking!',
      hometown: 'Nalbari, Assam',
    },
    {
      id: 'ranker-5',
      name: 'Kashyap Deka',
      exam: 'JEE Advanced 2024',
      rank: 'AIR 480',
      percentile: '99.78%ile',
      college: 'IIT Guwahati - Data Science & AI',
      photo: 'https://images.unsplash.com/photo-1522075469751-3a6694fb2f61?auto=format&fit=crop&w=300&q=80',
      testimonial:
        'Joining Argon Coaching in Class 11 was the best decision my parents made. Having mentors who are IITians themselves gave me the right study blueprint.',
      hometown: 'Silchar, Assam',
    },
    {
      id: 'ranker-6',
      name: 'Priyanka Das',
      exam: 'NEET-UG 2024',
      rank: 'AIR 890',
      percentile: 'Score: 678 / 720',
      college: 'Assam Medical College (AMCH Dibrugarh)',
      photo: 'https://images.unsplash.com/photo-1524504388940-b1c1722653e1?auto=format&fit=crop&w=300&q=80',
      testimonial:
        'Argon Test Series matched the real NEET standard precisely. Not unnecessarily obscure, but strictly following the NTA NCERT curriculum.',
      hometown: 'Tezpur, Assam',
    },
  ];

  const filteredRankers =
    examTab === 'ALL'
      ? TOP_RANKERS
      : TOP_RANKERS.filter((r) => r.exam.includes(examTab));

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Page Header */}
        <div className="text-center max-w-3xl mx-auto mb-14">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-emerald-500/10 border border-emerald-500/20 text-emerald-300 text-xs font-semibold mb-3">
            <Trophy className="w-4 h-4 text-amber-400" />
            <span>Hall of Fame • Proven Track Record</span>
          </div>
          <h1 className="text-3xl sm:text-4xl lg:text-5xl font-black text-white tracking-tight">
            Our Rankers & Selections
          </h1>
          <p className="mt-3 text-slate-300 text-sm sm:text-base leading-relaxed">
            Consistently producing Assam and Northeast's top competitive ranks through systematic conceptual training and authentic computer-based testing.
          </p>

          {/* Quick Metrics Bar */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-8">
            <div className="bg-slate-900 border border-slate-800 p-4 rounded-2xl">
              <p className="text-2xl sm:text-3xl font-black text-amber-400">48+</p>
              <p className="text-xs text-slate-400 mt-1">Selections in IITs & NITs (2024)</p>
            </div>
            <div className="bg-slate-900 border border-slate-800 p-4 rounded-2xl">
              <p className="text-2xl sm:text-3xl font-black text-emerald-400">72+</p>
              <p className="text-xs text-slate-400 mt-1">Selections in Govt Medical Colleges</p>
            </div>
            <div className="bg-slate-900 border border-slate-800 p-4 rounded-2xl">
              <p className="text-2xl sm:text-3xl font-black text-indigo-400">99.94%</p>
              <p className="text-xs text-slate-400 mt-1">Highest JEE Percentile</p>
            </div>
            <div className="bg-slate-900 border border-slate-800 p-4 rounded-2xl">
              <p className="text-2xl sm:text-3xl font-black text-rose-400">705/720</p>
              <p className="text-xs text-slate-400 mt-1">Highest NEET-UG Score</p>
            </div>
          </div>

          {/* Filter Pills */}
          <div className="flex items-center justify-center gap-2 mt-8">
            {[
              { id: 'ALL', label: 'All Rankers' },
              { id: 'JEE', label: 'JEE (Main & Advanced)' },
              { id: 'NEET', label: 'NEET-UG (Medical)' },
            ].map((t) => (
              <button
                key={t.id}
                onClick={() => setExamTab(t.id as any)}
                className={`px-4 py-2 rounded-xl text-xs font-bold transition-all ${
                  examTab === t.id
                    ? 'bg-amber-500 text-slate-950 shadow-lg shadow-amber-500/20'
                    : 'bg-slate-900 border border-slate-800 text-slate-400 hover:text-white'
                }`}
              >
                {t.label}
              </button>
            ))}
          </div>
        </div>

        {/* Rankers Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-16">
          {filteredRankers.map((ranker) => (
            <div
              key={ranker.id}
              className="bg-slate-900 border border-slate-800 rounded-3xl p-6 hover:border-slate-700 transition-all shadow-xl flex flex-col justify-between group"
            >
              <div>
                <div className="flex items-center gap-4 mb-4">
                  <img
                    src={ranker.photo}
                    alt={ranker.name}
                    className="w-16 h-16 rounded-2xl object-cover border-2 border-slate-700 shadow-md group-hover:scale-105 transition-transform"
                  />
                  <div>
                    <h3 className="font-bold text-lg text-white">{ranker.name}</h3>
                    <p className="text-xs text-slate-400">{ranker.hometown}</p>
                    <span className="inline-block mt-1 text-[11px] font-black text-amber-400 bg-amber-500/15 border border-amber-500/30 px-2 py-0.5 rounded">
                      {ranker.rank} • {ranker.percentile}
                    </span>
                  </div>
                </div>

                <div className="p-3 rounded-xl bg-slate-950 border border-slate-800/80 mb-4 flex items-center gap-2 text-xs text-indigo-300 font-semibold">
                  <Building className="w-4 h-4 text-indigo-400 shrink-0" />
                  <span className="truncate">{ranker.college}</span>
                </div>

                <div className="relative pl-6 text-xs text-slate-300 leading-relaxed italic mb-4">
                  <Quote className="w-4 h-4 text-slate-600 absolute left-0 top-0" />
                  "{ranker.testimonial}"
                </div>
              </div>

              <div className="pt-3 border-t border-slate-800/80 text-[11px] text-slate-400 flex items-center justify-between">
                <span>Argon Classroom Student</span>
                <span className="text-emerald-400 font-bold">{ranker.exam}</span>
              </div>
            </div>
          ))}
        </div>

        {/* Call to Action Card */}
        <div className="bg-gradient-to-r from-amber-500/20 via-slate-900 to-indigo-950/40 border border-amber-500/30 rounded-3xl p-8 sm:p-12 text-center max-w-4xl mx-auto shadow-2xl">
          <Trophy className="w-12 h-12 text-amber-400 mx-auto mb-4" />
          <h2 className="text-2xl sm:text-3xl font-black text-white mb-2">
            Be The Next AIR Ranker from Assam
          </h2>
          <p className="text-xs sm:text-sm text-slate-300 max-w-xl mx-auto mb-6 leading-relaxed">
            Admissions are open for 2026-27 batches. Take the Argon Scholarship Test (ASCAT) for up to 100% scholarship on tuition fees.
          </p>
          <div className="flex flex-wrap items-center justify-center gap-3">
            <button
              onClick={() => setCurrentView('admissions')}
              className="px-6 py-3 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 text-slate-950 font-bold text-xs shadow-lg transition-all flex items-center gap-2"
            >
              <span>Apply for ASCAT Scholarship</span>
              <ArrowRight className="w-4 h-4" />
            </button>
            <button
              onClick={() => setCurrentView('courses')}
              className="px-6 py-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold text-xs border border-slate-700 transition-all"
            >
              Explore Batches & Timings
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
