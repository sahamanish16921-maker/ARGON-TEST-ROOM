import React from 'react';
import { useApp } from '../../context/AppContext.tsx';
import { ArgonLogo } from '../ArgonLogo.tsx';
import {
  MapPin,
  Phone,
  Mail,
  Globe,
  Clock,
  ArrowRight,
  ShieldCheck,
  GraduationCap,
  Award,
} from 'lucide-react';

interface WebsiteFooterProps {
  onOpenAuth: (defaultTab: 'faculty' | 'student') => void;
}

export const WebsiteFooter: React.FC<WebsiteFooterProps> = ({ onOpenAuth }) => {
  const { setCurrentView } = useApp();

  return (
    <footer className="border-t border-slate-800 bg-slate-950 text-slate-400 text-xs">
      {/* Top Banner with Quick Actions */}
      <div className="border-b border-slate-800/80 bg-slate-900/50 py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="flex items-center gap-4">
            <ArgonLogo size="md" theme="dark" showText={true} />
            <div className="hidden sm:block border-l border-slate-800 pl-4">
              <p className="font-bold text-white text-xs">Argon Coaching Academy</p>
              <p className="text-[11px] text-slate-400">Premier JEE & NEET Institute • Guwahati, Assam</p>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            <a
              href="tel:06000730250"
              className="px-4 py-2 rounded-xl bg-amber-500/15 border border-amber-500/30 text-amber-300 font-bold text-xs hover:bg-amber-500/25 transition-colors flex items-center gap-2"
            >
              <Phone className="w-3.5 h-3.5 text-amber-400" />
              <span>Admissions: 060007 30250</span>
            </a>

            <button
              onClick={() => onOpenAuth('student')}
              className="px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs shadow-md transition-colors flex items-center gap-1.5"
            >
              <GraduationCap className="w-3.5 h-3.5" />
              <span>Student CBT Portal</span>
            </button>

            <button
              onClick={() => onOpenAuth('faculty')}
              className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 font-bold text-xs transition-colors flex items-center gap-1.5"
            >
              <ShieldCheck className="w-3.5 h-3.5 text-amber-400" />
              <span>Faculty Login</span>
            </button>
          </div>
        </div>
      </div>

      {/* Main Footer Links */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-8">
          {/* Col 1: Institute About */}
          <div className="lg:col-span-2 space-y-4">
            <p className="text-slate-300 leading-relaxed text-xs">
              Argon Coaching is dedicated to transforming competitive exam preparation in Assam and the Northeast. Founded by IITian and medical alumni, we offer classroom coaching, small batch mentorship, and authentic NTA-pattern Computer Based Tests.
            </p>

            <div className="space-y-2 pt-2">
              <div className="flex items-start gap-2.5 text-slate-300">
                <MapPin className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
                <span>HouseNo. 1A, Chinaki path, GS Rd, Rukmini Gaon, Guwahati, Assam 781006</span>
              </div>
              <div className="flex items-center gap-2.5 text-slate-300">
                <Phone className="w-4 h-4 text-amber-400 shrink-0" />
                <a href="tel:06000730250" className="hover:text-amber-300 font-mono font-bold">
                  060007 30250
                </a>
              </div>
              <div className="flex items-center gap-2.5 text-slate-300">
                <Globe className="w-4 h-4 text-indigo-400 shrink-0" />
                <a
                  href="https://www.argoncoaching.com"
                  target="_blank"
                  rel="noreferrer"
                  className="hover:text-indigo-300"
                >
                  www.argoncoaching.com
                </a>
              </div>
            </div>
          </div>

          {/* Col 2: Academic Programs */}
          <div>
            <h4 className="font-bold text-white uppercase tracking-wider text-xs mb-3">Courses & Batches</h4>
            <ul className="space-y-2">
              <li>
                <button
                  onClick={() => setCurrentView('courses')}
                  className="hover:text-amber-300 transition-colors text-left"
                >
                  2-Yr JEE (Main + Adv)
                </button>
              </li>
              <li>
                <button
                  onClick={() => setCurrentView('courses')}
                  className="hover:text-amber-300 transition-colors text-left"
                >
                  1-Yr JEE Target Batch
                </button>
              </li>
              <li>
                <button
                  onClick={() => setCurrentView('courses')}
                  className="hover:text-amber-300 transition-colors text-left"
                >
                  2-Yr NEET-UG Medical
                </button>
              </li>
              <li>
                <button
                  onClick={() => setCurrentView('courses')}
                  className="hover:text-amber-300 transition-colors text-left"
                >
                  Dropper Super 30 JEE
                </button>
              </li>
              <li>
                <button
                  onClick={() => setCurrentView('courses')}
                  className="hover:text-amber-300 transition-colors text-left"
                >
                  NEET Rank Booster
                </button>
              </li>
              <li>
                <button
                  onClick={() => setCurrentView('courses')}
                  className="hover:text-amber-300 transition-colors text-left"
                >
                  Foundation (Class 9-10)
                </button>
              </li>
            </ul>
          </div>

          {/* Col 3: Testing & Resources */}
          <div>
            <h4 className="font-bold text-white uppercase tracking-wider text-xs mb-3">Testing & Study</h4>
            <ul className="space-y-2">
              <li>
                <button
                  onClick={() => setCurrentView('test-series')}
                  className="hover:text-amber-300 transition-colors text-left"
                >
                  Online CBT Mock Series
                </button>
              </li>
              <li>
                <button
                  onClick={() => setCurrentView('free-resources')}
                  className="hover:text-amber-300 transition-colors text-left"
                >
                  JEE Formula Handbooks
                </button>
              </li>
              <li>
                <button
                  onClick={() => setCurrentView('free-resources')}
                  className="hover:text-amber-300 transition-colors text-left"
                >
                  NCERT Biology Mindmaps
                </button>
              </li>
              <li>
                <button
                  onClick={() => setCurrentView('free-resources')}
                  className="hover:text-amber-300 transition-colors text-left"
                >
                  Previous Years Papers (PYQs)
                </button>
              </li>
              <li>
                <button
                  onClick={() => onOpenAuth('student')}
                  className="text-indigo-400 hover:text-indigo-300 font-bold text-left flex items-center gap-1"
                >
                  <span>Student CBT Login</span>
                  <ArrowRight className="w-3 h-3" />
                </button>
              </li>
            </ul>
          </div>

          {/* Col 4: Institute Links */}
          <div>
            <h4 className="font-bold text-white uppercase tracking-wider text-xs mb-3">Institute Info</h4>
            <ul className="space-y-2">
              <li>
                <button
                  onClick={() => setCurrentView('faculty-mentors')}
                  className="hover:text-amber-300 transition-colors text-left"
                >
                  Senior IITian Faculty
                </button>
              </li>
              <li>
                <button
                  onClick={() => setCurrentView('results')}
                  className="hover:text-amber-300 transition-colors text-left"
                >
                  Selections & Hall of Fame
                </button>
              </li>
              <li>
                <button
                  onClick={() => setCurrentView('admissions')}
                  className="hover:text-amber-300 transition-colors text-left"
                >
                  ASCAT Scholarship Test
                </button>
              </li>
              <li>
                <button
                  onClick={() => setCurrentView('admissions')}
                  className="hover:text-amber-300 transition-colors text-left"
                >
                  Book Campus Visit
                </button>
              </li>
              <li>
                <button
                  onClick={() => onOpenAuth('faculty')}
                  className="hover:text-amber-400 font-bold transition-colors text-left flex items-center gap-1"
                >
                  <ShieldCheck className="w-3 h-3 text-amber-400" />
                  <span>Faculty Portal Login</span>
                </button>
              </li>
            </ul>
          </div>
        </div>
      </div>

      {/* Copyright Bar */}
      <div className="border-t border-slate-800/80 py-6 text-center text-[11px] text-slate-500">
        <div className="max-w-7xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-2">
          <p>© 2026 Argon Coaching Academy. All Rights Reserved. • Guwahati, Assam 781006</p>
          <p className="text-slate-400">
            Official NTA Simulation Software Engine • Cloud Powered with Instant Grading
          </p>
        </div>
      </div>
    </footer>
  );
};
