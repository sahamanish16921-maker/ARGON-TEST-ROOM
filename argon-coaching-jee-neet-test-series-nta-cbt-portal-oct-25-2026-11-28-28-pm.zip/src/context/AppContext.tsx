import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import type {
  User,
  TestSeries,
  Test,
  StudentTestAttempt,
  Question,
  ExamType,
  UserRole,
  PaymentVerificationRequest,
  SubjectSection,
  WebsiteView,
  Notice,
  StudyMaterial,
  FacultyProfile,
} from '../types/index.ts';
import {
  supabase,
  initSupabaseRealtime,
  broadcastViaSupabase,
  testSupabaseConnection,
  supabaseUpsert,
  supabaseFetchTable,
  supabaseDeleteRow,
  loginWithGoogleViaSupabase,
  logoutUserViaSupabase,
  SupabaseBroadcastMessage,
} from '../lib/supabase.ts';
import {
  INITIAL_TEST_SERIES,
  INITIAL_TESTS,
  INITIAL_STUDENT_ATTEMPTS,
  FACULTY_USER,
  DEMO_STUDENT_USERS,
  INSTITUTION_UPI_QR,
  INITIAL_VERIFICATION_REQUESTS,
  INITIAL_NOTICES,
  INITIAL_MATERIALS,
  INITIAL_FACULTY_PROFILES,
} from '../data/seedData.ts';

export interface InstituteUpiSettings {
  upiId: string;
  merchantName: string;
  qrUrl: string;
  note: string;
}

interface AppContextType {
  currentUser: User | null;
  role: UserRole;
  currentView: WebsiteView;
  testSeries: TestSeries[];
  tests: Test[];
  attempts: StudentTestAttempt[];
  students: User[];
  verificationRequests: PaymentVerificationRequest[];
  notices: Notice[];
  materials: StudyMaterial[];
  facultyProfiles: FacultyProfile[];
  instituteUpi: InstituteUpiSettings;
  activeTestId: string | null;
  activeAttemptId: string | null;

  // Auth & View
  setCurrentView: (view: WebsiteView) => void;
  loginAsFaculty: (password: string) => boolean;
  loginAsFacultyAsync: (password: string) => Promise<{
    success: boolean;
    message?: string;
    code?: string;
    activeDevices?: any[];
  }>;
  revokeFacultyDevice: (targetDeviceId: string) => Promise<void>;
  activeFacultyDevices: {
    deviceId: string;
    deviceName: string;
    browser: string;
    ip: string;
    loggedInAt: string;
    lastActiveAt: string;
  }[];
  currentDeviceId: string;
  loginAsDemoStudent: (studentIndex?: number) => void;
  loginStudentByNameAndRoll: (name: string, rollNo: string) => { success: boolean; message?: string };
  registerOrLoginStudent: (studentData: {
    name: string;
    email: string;
    phone?: string;
    targetExam: ExamType;
    rollNo?: string;
  }) => Promise<void>;
  updateStudentPhone: (studentId: string, phone: string) => void;
  logout: () => void;
  signInWithGoogle: () => Promise<void>;
  isSupabaseConnected: boolean;
  isFirebaseConnected: boolean; // Backwards-compatible alias for existing components
  isOnline: boolean;
  connectionStatus: 'connected' | 'connecting' | 'offline';
  lastSyncTime: string;
  refreshFromServer: () => Promise<void>;

  // Faculty actions
  registerStudentByAdmin: (studentData: {
    name: string;
    rollNo: string;
    phone: string;
    targetExam: ExamType;
    email?: string;
    enrolledSeriesIds?: string[];
  }) => Promise<User>;
  updateStudentByAdmin: (id: string, updates: Partial<User>) => Promise<void>;
  deleteStudentByAdmin: (id: string) => Promise<void>;

  createTestSeries: (series: Omit<TestSeries, 'id'>) => Promise<string>;
  updateTestSeries: (id: string, updates: Partial<TestSeries>) => Promise<void>;
  deleteTestSeries: (id: string) => Promise<void>;

  createTest: (test: Omit<Test, 'id' | 'createdAt'>) => Promise<string>;
  updateTest: (id: string, updates: Partial<Test>) => Promise<void>;
  deleteTest: (id: string) => Promise<void>;
  toggleTestLock: (testId: string) => Promise<void>;
  updateTestSubjectOrder: (testId: string, order: SubjectSection[]) => Promise<void>;
  updateTestSchedule: (
    testId: string,
    startTime?: string,
    endTime?: string,
    isScheduled?: boolean
  ) => Promise<void>;

  addQuestion: (testId: string, question: Omit<Question, 'id'>) => Promise<void>;
  updateQuestion: (
    testId: string,
    questionId: string,
    question: Partial<Question>
  ) => Promise<void>;
  deleteQuestion: (testId: string, questionId: string) => Promise<void>;
  batchAddQuestions: (testId: string, questions: Question[]) => Promise<void>;
  updateQuickAnswerKey: (
    testId: string,
    questionId: string,
    newAnswer: string
  ) => Promise<void>;

  updateInstituteUpi: (settings: Partial<InstituteUpiSettings>) => Promise<void>;

  // Dedicated Permanent Cloud Sync
  saveTestToCloud: (testId: string) => Promise<{ success: boolean; message: string }>;

  // Notices & Materials
  createNotice: (notice: Omit<Notice, 'id' | 'createdAt'>) => Promise<string>;
  deleteNotice: (id: string) => Promise<void>;
  createMaterial: (material: Omit<StudyMaterial, 'id' | 'uploadedAt'>) => Promise<string>;
  deleteMaterial: (id: string) => Promise<void>;

  // Faculty Bios & Mentors (Live Synced to Students & Website)
  createFacultyProfile: (profile: Omit<FacultyProfile, 'id' | 'updatedAt'>) => Promise<string>;
  updateFacultyProfile: (id: string, updates: Partial<FacultyProfile>) => Promise<void>;
  deleteFacultyProfile: (id: string) => Promise<void>;

  // Student actions & Verification Request Flow
  sendVerificationRequest: (seriesId: string, upiTxnId: string) => Promise<{ success: boolean; message: string }>;
  approveVerificationRequest: (requestId: string) => Promise<void>;
  rejectVerificationRequest: (requestId: string, reason?: string) => Promise<void>;
  createDirectVerificationRequest: (data: {
    studentId: string;
    studentName: string;
    studentRoll: string;
    studentPhone: string;
    seriesId: string;
    upiTxnId: string;
  }) => Promise<void>;
  enrollInSeries: (seriesId: string, txnId?: string) => Promise<void>;
  startExam: (testId: string) => void;
  submitExam: (attempt: StudentTestAttempt) => Promise<void>;
  viewResult: (attemptId: string) => void;
  exitExamOrResult: () => void;
  resetAllDataToDefault: () => Promise<void>;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

// Storage keys
const AUTH_STORAGE_KEY = 'argon_user_session';
const STORAGE_KEY_TESTS = 'argon_tests';
const STORAGE_KEY_SERIES = 'argon_test_series';
const STORAGE_KEY_UPI = 'argon_institute_upi';
const STORAGE_KEY_STUDENTS = 'argon_students';
const STORAGE_KEY_SUBMISSIONS = 'argon_submissions';
const STORAGE_KEY_VERIFICATIONS = 'argon_verifications';
const STORAGE_KEY_NOTICES = 'argon_notices';
const STORAGE_KEY_MATERIALS = 'argon_materials';
const STORAGE_KEY_FACULTY = 'argon_faculty_profiles';

function loadLocalCache<T>(key: string, fallback: T): T {
  try {
    const saved = localStorage.getItem(key);
    if (!saved) return fallback;
    const parsed = JSON.parse(saved);
    if (Array.isArray(fallback) && !Array.isArray(parsed)) return fallback;
    return parsed;
  } catch {
    return fallback;
  }
}

function saveLocalCache<T>(key: string, data: T): void {
  try {
    localStorage.setItem(key, JSON.stringify(data));
  } catch (err) {
    console.warn(`LocalStorage write error for ${key}:`, err);
  }
}

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({
  children,
}) => {
  // Session User
  const [currentUser, setCurrentUser] = useState<User | null>(() => {
    return loadLocalCache<User | null>(AUTH_STORAGE_KEY, null);
  });

  // Core App State: Initialized with localStorage cache so NO data vanishes on refresh!
  const [testSeries, setTestSeries] = useState<TestSeries[]>(() =>
    loadLocalCache<TestSeries[]>(STORAGE_KEY_SERIES, INITIAL_TEST_SERIES)
  );
  const [tests, setTests] = useState<Test[]>(() =>
    loadLocalCache<Test[]>(STORAGE_KEY_TESTS, INITIAL_TESTS)
  );
  const [attempts, setAttempts] = useState<StudentTestAttempt[]>(() =>
    loadLocalCache<StudentTestAttempt[]>(STORAGE_KEY_SUBMISSIONS, INITIAL_STUDENT_ATTEMPTS)
  );
  const [students, setStudents] = useState<User[]>(() =>
    loadLocalCache<User[]>(STORAGE_KEY_STUDENTS, DEMO_STUDENT_USERS)
  );
  const [verificationRequests, setVerificationRequests] = useState<PaymentVerificationRequest[]>(() =>
    loadLocalCache<PaymentVerificationRequest[]>(STORAGE_KEY_VERIFICATIONS, INITIAL_VERIFICATION_REQUESTS)
  );
  const [notices, setNotices] = useState<Notice[]>(() =>
    loadLocalCache<Notice[]>(STORAGE_KEY_NOTICES, INITIAL_NOTICES)
  );
  const [materials, setMaterials] = useState<StudyMaterial[]>(() =>
    loadLocalCache<StudyMaterial[]>(STORAGE_KEY_MATERIALS, INITIAL_MATERIALS)
  );
  const [facultyProfiles, setFacultyProfiles] = useState<FacultyProfile[]>(() =>
    loadLocalCache<FacultyProfile[]>(STORAGE_KEY_FACULTY, INITIAL_FACULTY_PROFILES)
  );

  const [instituteUpi, setInstituteUpi] = useState<InstituteUpiSettings>(() =>
    loadLocalCache<InstituteUpiSettings>(STORAGE_KEY_UPI, {
      upiId: 'argoncoaching@icici',
      merchantName: 'ARGON COACHING ACADEMY ASSAM',
      qrUrl: INSTITUTION_UPI_QR,
      note: 'Scan via any UPI App (GPay / PhonePe / Paytm / BHIM) to unlock test series',
    })
  );

  const [currentView, setCurrentView] = useState<WebsiteView>(() => {
    if (currentUser?.role === 'faculty') return 'faculty-dashboard';
    if (currentUser?.role === 'student') return 'student-dashboard';
    return 'home';
  });

  const [activeTestId, setActiveTestId] = useState<string | null>(null);
  const [activeAttemptId, setActiveAttemptId] = useState<string | null>(null);

  // Device identifier for max-2 device restriction
  const [currentDeviceId] = useState<string>(() => {
    try {
      let id = localStorage.getItem('argon_device_id');
      if (!id) {
        id = 'dev-' + Math.random().toString(36).substring(2, 9) + '-' + Date.now();
        localStorage.setItem('argon_device_id', id);
      }
      return id;
    } catch {
      return 'dev-browser-' + Date.now();
    }
  });

  const [activeFacultyDevices, setActiveFacultyDevices] = useState<any[]>([]);
  const [isSupabaseConnected, setIsSupabaseConnected] = useState<boolean>(true);
  const [isOnline, setIsOnline] = useState<boolean>(() =>
    typeof navigator !== 'undefined' ? navigator.onLine : true
  );
  const [connectionStatus, setConnectionStatus] = useState<
    'connected' | 'connecting' | 'offline'
  >('connected');
  const [lastSyncTime, setLastSyncTime] = useState<string>(() =>
    new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })
  );

  // Keep session user cached for page reloads
  useEffect(() => {
    if (currentUser) {
      saveLocalCache(AUTH_STORAGE_KEY, currentUser);
    } else {
      try {
        localStorage.removeItem(AUTH_STORAGE_KEY);
      } catch {}
    }
  }, [currentUser]);

  // Sync state to backend server persistent file (data/app_state.json)
  const syncToServer = useCallback(async (payload: Record<string, any>) => {
    try {
      await fetch('/api/sync', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });
    } catch (err) {
      console.warn('Sync to server error:', err);
    }
  }, []);

  // Full Refresh from Server: Restores tests, series, upi, students, attempts, notices, materials, and faculty
  const refreshFromServer = useCallback(async () => {
    try {
      const res = await fetch('/api/state');
      if (!res.ok) return;
      const json = await res.json();
      if (json.success && json.data) {
        const d = json.data;

        if (Array.isArray(d.tests) && d.tests.length > 0) {
          setTests(d.tests);
          saveLocalCache(STORAGE_KEY_TESTS, d.tests);
        }
        if (Array.isArray(d.testSeries) && d.testSeries.length > 0) {
          setTestSeries(d.testSeries);
          saveLocalCache(STORAGE_KEY_SERIES, d.testSeries);
        }
        if (d.instituteUpi && d.instituteUpi.upiId) {
          setInstituteUpi(d.instituteUpi);
          saveLocalCache(STORAGE_KEY_UPI, d.instituteUpi);
        }
        if (Array.isArray(d.students) && d.students.length > 0) {
          setStudents(d.students);
          saveLocalCache(STORAGE_KEY_STUDENTS, d.students);
        }
        if (Array.isArray(d.attempts) && d.attempts.length > 0) {
          setAttempts(d.attempts);
          saveLocalCache(STORAGE_KEY_SUBMISSIONS, d.attempts);
        }
        if (Array.isArray(d.verificationRequests)) {
          setVerificationRequests(d.verificationRequests);
          saveLocalCache(STORAGE_KEY_VERIFICATIONS, d.verificationRequests);
        }
        if (Array.isArray(d.notices)) {
          setNotices(d.notices);
          saveLocalCache(STORAGE_KEY_NOTICES, d.notices);
        }
        if (Array.isArray(d.materials)) {
          setMaterials(d.materials);
          saveLocalCache(STORAGE_KEY_MATERIALS, d.materials);
        }
        if (Array.isArray(d.facultyProfiles)) {
          setFacultyProfiles(d.facultyProfiles);
          saveLocalCache(STORAGE_KEY_FACULTY, d.facultyProfiles);
        }

        setLastSyncTime(
          new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })
        );
      }
    } catch (err) {
      console.warn('Error refreshing state from server:', err);
    }
  }, []);

  // Validate Supabase Connection on Boot
  useEffect(() => {
    testSupabaseConnection().then((connected) => {
      setIsSupabaseConnected(connected);
    });

    // Also attempt to read Supabase tables if created in Supabase Dashboard
    const loadFromSupabaseTables = async () => {
      try {
        const remoteTests = await supabaseFetchTable<Test>('tests');
        if (remoteTests && remoteTests.length > 0) {
          setTests(remoteTests);
          saveLocalCache(STORAGE_KEY_TESTS, remoteTests);
        }
        const remoteSeries = await supabaseFetchTable<TestSeries>('test_series');
        if (remoteSeries && remoteSeries.length > 0) {
          setTestSeries(remoteSeries);
          saveLocalCache(STORAGE_KEY_SERIES, remoteSeries);
        }
        const remoteUpi = await supabaseFetchTable<InstituteUpiSettings>('institute_upi');
        if (remoteUpi && remoteUpi.length > 0 && remoteUpi[0].upiId) {
          setInstituteUpi(remoteUpi[0]);
          saveLocalCache(STORAGE_KEY_UPI, remoteUpi[0]);
        }
      } catch (e) {
        console.warn('Supabase tables query note:', e);
      }
    };
    loadFromSupabaseTables();
  }, []);

  // =========================================================================
  // LIVE SUPABASE REALTIME SUBSCRIPTION
  // Instant (<50ms) push broadcast synchronization across Faculty & Student devices
  // =========================================================================
  useEffect(() => {
    const handleSupabaseBroadcast = (msg: SupabaseBroadcastMessage) => {
      setLastSyncTime(
        new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })
      );

      switch (msg.type) {
        case 'TEST_CREATED':
        case 'TEST_UPDATED':
        case 'QUESTION_SAVED': {
          const updatedTest = msg.data as Test;
          if (updatedTest && updatedTest.id) {
            setTests((prev) => {
              const exists = prev.some((t) => t.id === updatedTest.id);
              const next = exists
                ? prev.map((t) => (t.id === updatedTest.id ? updatedTest : t))
                : [updatedTest, ...prev];
              saveLocalCache(STORAGE_KEY_TESTS, next);
              return next;
            });
          }
          break;
        }
        case 'TEST_DELETED': {
          const deletedId = msg.data?.id || msg.data;
          if (deletedId) {
            setTests((prev) => {
              const next = prev.filter((t) => t.id !== deletedId);
              saveLocalCache(STORAGE_KEY_TESTS, next);
              return next;
            });
          }
          break;
        }
        case 'SERIES_CREATED':
        case 'SERIES_UPDATED': {
          const updatedSeries = msg.data as TestSeries;
          if (updatedSeries && updatedSeries.id) {
            setTestSeries((prev) => {
              const exists = prev.some((s) => s.id === updatedSeries.id);
              const next = exists
                ? prev.map((s) => (s.id === updatedSeries.id ? updatedSeries : s))
                : [updatedSeries, ...prev];
              saveLocalCache(STORAGE_KEY_SERIES, next);
              return next;
            });
          }
          break;
        }
        case 'SERIES_DELETED': {
          const deletedId = msg.data?.id || msg.data;
          if (deletedId) {
            setTestSeries((prev) => {
              const next = prev.filter((s) => s.id !== deletedId);
              saveLocalCache(STORAGE_KEY_SERIES, next);
              return next;
            });
          }
          break;
        }
        case 'UPI_UPDATED': {
          const updatedUpi = msg.data;
          if (updatedUpi && updatedUpi.upiId) {
            setInstituteUpi(updatedUpi);
            saveLocalCache(STORAGE_KEY_UPI, updatedUpi);
          }
          break;
        }
        case 'ATTEMPT_SUBMITTED': {
          const newAttempt = msg.data as StudentTestAttempt;
          if (newAttempt && newAttempt.id) {
            setAttempts((prev) => {
              const next = [newAttempt, ...prev.filter((a) => a.id !== newAttempt.id)];
              saveLocalCache(STORAGE_KEY_SUBMISSIONS, next);
              return next;
            });
          }
          break;
        }
        case 'FACULTY_UPDATED': {
          if (Array.isArray(msg.data)) {
            setFacultyProfiles(msg.data);
            saveLocalCache(STORAGE_KEY_FACULTY, msg.data);
          } else if (msg.data && msg.data.id) {
            setFacultyProfiles((prev) => {
              const exists = prev.some((f) => f.id === msg.data.id);
              const next = exists
                ? prev.map((f) => (f.id === msg.data.id ? msg.data : f))
                : [msg.data, ...prev];
              saveLocalCache(STORAGE_KEY_FACULTY, next);
              return next;
            });
          }
          break;
        }
        case 'NOTICE_UPDATED': {
          if (Array.isArray(msg.data)) {
            setNotices(msg.data);
            saveLocalCache(STORAGE_KEY_NOTICES, msg.data);
          }
          break;
        }
        case 'MATERIAL_UPDATED': {
          if (Array.isArray(msg.data)) {
            setMaterials(msg.data);
            saveLocalCache(STORAGE_KEY_MATERIALS, msg.data);
          }
          break;
        }
        case 'FULL_STATE_SYNC': {
          if (msg.data) {
            if (msg.data.tests) {
              setTests(msg.data.tests);
              saveLocalCache(STORAGE_KEY_TESTS, msg.data.tests);
            }
            if (msg.data.testSeries) {
              setTestSeries(msg.data.testSeries);
              saveLocalCache(STORAGE_KEY_SERIES, msg.data.testSeries);
            }
            if (msg.data.instituteUpi) {
              setInstituteUpi(msg.data.instituteUpi);
              saveLocalCache(STORAGE_KEY_UPI, msg.data.instituteUpi);
            }
          }
          break;
        }
      }
    };

    const unsubscribeRealtime = initSupabaseRealtime(currentDeviceId, handleSupabaseBroadcast);

    // Initial server refresh on mount to ensure parity
    refreshFromServer();

    return () => {
      unsubscribeRealtime();
    };
  }, [currentDeviceId, refreshFromServer]);

  // Real-time Push Stream (SSE) fallback for heartbeat & connection status
  useEffect(() => {
    let eventSource: EventSource | null = null;
    let isCancelled = false;

    const connectSSE = () => {
      try {
        eventSource = new EventSource('/api/realtime/stream');
        eventSource.onopen = () => {
          if (!isCancelled) {
            setConnectionStatus('connected');
            setIsOnline(true);
          }
        };

        eventSource.onmessage = (event) => {
          if (isCancelled || !event.data) return;
          try {
            const payload = JSON.parse(event.data);
            if (payload.type === 'STATE_UPDATED' && payload.data) {
              const { tests: sTests, testSeries: sSeries, instituteUpi: sUpi, notices: sNotices, materials: sMaterials, facultyProfiles: sFaculty } = payload.data;
              if (sTests) {
                setTests(sTests);
                saveLocalCache(STORAGE_KEY_TESTS, sTests);
              }
              if (sSeries) {
                setTestSeries(sSeries);
                saveLocalCache(STORAGE_KEY_SERIES, sSeries);
              }
              if (sUpi) {
                setInstituteUpi(sUpi);
                saveLocalCache(STORAGE_KEY_UPI, sUpi);
              }
              if (sNotices) {
                setNotices(sNotices);
                saveLocalCache(STORAGE_KEY_NOTICES, sNotices);
              }
              if (sMaterials) {
                setMaterials(sMaterials);
                saveLocalCache(STORAGE_KEY_MATERIALS, sMaterials);
              }
              if (sFaculty) {
                setFacultyProfiles(sFaculty);
                saveLocalCache(STORAGE_KEY_FACULTY, sFaculty);
              }

              setLastSyncTime(
                new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })
              );
              setConnectionStatus('connected');
              setIsOnline(true);
            }
          } catch {}
        };

        eventSource.onerror = () => {
          if (!isCancelled) {
            setConnectionStatus(typeof navigator !== 'undefined' && navigator.onLine ? 'connecting' : 'offline');
          }
        };
      } catch {
        setConnectionStatus('offline');
      }
    };

    connectSSE();

    const handleOnline = () => {
      setIsOnline(true);
      setConnectionStatus('connected');
      refreshFromServer();
    };

    const handleOffline = () => {
      setIsOnline(false);
      setConnectionStatus('offline');
    };

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    // Cross-tab broadcast channel
    let bc: BroadcastChannel | null = null;
    try {
      bc = new BroadcastChannel('argon_cross_tab_sync');
      bc.onmessage = (event) => {
        if (event.data?.type === 'SYNC_ALL' && event.data?.payload) {
          const { sSeries, sTests, sStudents, sAttempts, sVerifications, sUpi } = event.data.payload;
          if (sSeries && Array.isArray(sSeries)) {
            setTestSeries(sSeries);
            saveLocalCache(STORAGE_KEY_SERIES, sSeries);
          }
          if (sTests && Array.isArray(sTests)) {
            setTests(sTests);
            saveLocalCache(STORAGE_KEY_TESTS, sTests);
          }
          if (sStudents && Array.isArray(sStudents)) {
            setStudents(sStudents);
            saveLocalCache(STORAGE_KEY_STUDENTS, sStudents);
          }
          if (sAttempts && Array.isArray(sAttempts)) {
            setAttempts(sAttempts);
            saveLocalCache(STORAGE_KEY_SUBMISSIONS, sAttempts);
          }
          if (sVerifications && Array.isArray(sVerifications)) {
            setVerificationRequests(sVerifications);
            saveLocalCache(STORAGE_KEY_VERIFICATIONS, sVerifications);
          }
          if (sUpi) {
            setInstituteUpi(sUpi);
            saveLocalCache(STORAGE_KEY_UPI, sUpi);
          }
        }
      };
    } catch {}

    return () => {
      isCancelled = true;
      if (eventSource) eventSource.close();
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
      try {
        bc?.close();
      } catch {}
    };
  }, [refreshFromServer]);

  const role: UserRole = currentUser ? currentUser.role : 'guest';

  // =========================================================================
  // AUTHENTICATION METHODS
  // =========================================================================

  const loginAsFaculty = (password: string): boolean => {
    if (password === 'ADMIN123@') {
      setCurrentUser(FACULTY_USER);
      saveLocalCache(AUTH_STORAGE_KEY, FACULTY_USER);
      setCurrentView('faculty-dashboard');
      return true;
    }
    return false;
  };

  const loginAsFacultyAsync = async (
    password: string
  ): Promise<{
    success: boolean;
    message?: string;
    code?: string;
    activeDevices?: any[];
  }> => {
    try {
      const res = await fetch('/api/faculty/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          password,
          deviceId: currentDeviceId,
          deviceName: navigator.userAgent.includes('Mobile')
            ? 'Faculty Mobile Terminal'
            : 'Faculty Admin Station',
          browser: navigator.userAgent.split(' ')[0] || 'Desktop Browser',
        }),
      });

      const data = await res.json();
      if (res.ok && data.success) {
        if (data.activeDevices) setActiveFacultyDevices(data.activeDevices);
        setCurrentUser(FACULTY_USER);
        saveLocalCache(AUTH_STORAGE_KEY, FACULTY_USER);
        setCurrentView('faculty-dashboard');
        return { success: true, activeDevices: data.activeDevices };
      } else {
        if (data.activeDevices) setActiveFacultyDevices(data.activeDevices);
        return {
          success: false,
          message:
            data.message ||
            'Faculty authentication failed. Note that only maximum 2 devices are allowed.',
          code: data.code,
          activeDevices: data.activeDevices || [],
        };
      }
    } catch {
      if (password === 'ADMIN123@') {
        setCurrentUser(FACULTY_USER);
        saveLocalCache(AUTH_STORAGE_KEY, FACULTY_USER);
        setCurrentView('faculty-dashboard');
        return { success: true };
      }
      return { success: false, message: 'Incorrect administrator password. Please try again.' };
    }
  };

  const revokeFacultyDevice = async (targetDeviceId: string) => {
    try {
      const res = await fetch('/api/faculty/revoke-device', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ targetDeviceId }),
      });
      const data = await res.json();
      if (data.activeDevices) {
        setActiveFacultyDevices(data.activeDevices);
      } else {
        setActiveFacultyDevices((prev) => prev.filter((d) => d.deviceId !== targetDeviceId));
      }
    } catch {
      setActiveFacultyDevices((prev) => prev.filter((d) => d.deviceId !== targetDeviceId));
    }
  };

  const loginAsDemoStudent = (studentIndex = 0) => {
    const student = students[studentIndex] || DEMO_STUDENT_USERS[studentIndex] || DEMO_STUDENT_USERS[0];
    setCurrentUser(student);
    saveLocalCache(AUTH_STORAGE_KEY, student);
    setCurrentView('student-dashboard');
  };

  const loginStudentByNameAndRoll = (name: string, rollNo: string): { success: boolean; message?: string } => {
    const cleanName = name.trim().toLowerCase();
    const cleanRoll = rollNo.trim().toUpperCase();

    const found = students.find(
      (s) =>
        s.rollNo?.trim().toUpperCase() === cleanRoll &&
        (cleanName.length === 0 || s.name.trim().toLowerCase() === cleanName || s.name.trim().toLowerCase().includes(cleanName))
    );

    if (found) {
      setCurrentUser(found);
      saveLocalCache(AUTH_STORAGE_KEY, found);
      setCurrentView('student-dashboard');
      return { success: true };
    }

    return {
      success: false,
      message: `No registered student found with Roll No "${rollNo}". Please check the spelling or ask Faculty/Admin to register your Name & Roll Number.`
    };
  };

  const registerOrLoginStudent = async (data: {
    name: string;
    email: string;
    phone?: string;
    targetExam: ExamType;
    rollNo?: string;
  }) => {
    const roll = data.rollNo?.trim() || `ARG-${data.targetExam.substring(0, 3).toUpperCase()}-${Math.floor(1000 + Math.random() * 9000)}`;
    const newStudent: User = {
      id: `student-${Date.now()}`,
      name: data.name,
      email: data.email,
      phone: data.phone || '+91 98000 00000',
      role: 'student',
      targetExam: data.targetExam,
      rollNo: roll,
      enrolledSeriesIds: ['series-jee-main-free'],
      avatar: `https://api.dicebear.com/7.x/initials/svg?seed=${encodeURIComponent(data.name)}`,
      registeredAt: new Date().toISOString(),
    };

    const nextStudents = [newStudent, ...students];
    setStudents(nextStudents);
    saveLocalCache(STORAGE_KEY_STUDENTS, nextStudents);
    setCurrentUser(newStudent);
    saveLocalCache(AUTH_STORAGE_KEY, newStudent);
    setCurrentView('student-dashboard');

    // Sync to Supabase & server
    supabaseUpsert('students', newStudent);
    syncToServer({ students: nextStudents });
  };

  const registerStudentByAdmin = async (data: {
    name: string;
    rollNo: string;
    phone: string;
    targetExam: ExamType;
    email?: string;
    enrolledSeriesIds?: string[];
  }): Promise<User> => {
    const newStudent: User = {
      id: `student-admin-${Date.now()}`,
      name: data.name.trim(),
      rollNo: data.rollNo.trim(),
      phone: data.phone.trim(),
      email: data.email?.trim() || `${data.name.trim().toLowerCase().replace(/\s+/g, '.')}@argon.edu`,
      targetExam: data.targetExam,
      role: 'student',
      avatar: `https://api.dicebear.com/7.x/initials/svg?seed=${encodeURIComponent(data.name)}`,
      enrolledSeriesIds: data.enrolledSeriesIds || ['series-jee-main-free'],
      registeredAt: new Date().toISOString(),
    };

    const nextStudents = [newStudent, ...students];
    setStudents(nextStudents);
    saveLocalCache(STORAGE_KEY_STUDENTS, nextStudents);

    supabaseUpsert('students', newStudent);
    syncToServer({ students: nextStudents });
    return newStudent;
  };

  const updateStudentByAdmin = async (id: string, updates: Partial<User>) => {
    const nextStudents = students.map((s) => (s.id === id ? { ...s, ...updates } : s));
    setStudents(nextStudents);
    saveLocalCache(STORAGE_KEY_STUDENTS, nextStudents);

    if (currentUser?.id === id) {
      const updatedUser = { ...currentUser, ...updates };
      setCurrentUser(updatedUser);
      saveLocalCache(AUTH_STORAGE_KEY, updatedUser);
    }

    const target = nextStudents.find((s) => s.id === id);
    if (target) supabaseUpsert('students', target);
    syncToServer({ students: nextStudents });
  };

  const deleteStudentByAdmin = async (id: string) => {
    const nextStudents = students.filter((s) => s.id !== id);
    setStudents(nextStudents);
    saveLocalCache(STORAGE_KEY_STUDENTS, nextStudents);

    supabaseDeleteRow('students', id);
    syncToServer({ students: nextStudents });
  };

  const updateStudentPhone = (studentId: string, phone: string) => {
    updateStudentByAdmin(studentId, { phone });
  };

  const logout = async () => {
    try {
      await logoutUserViaSupabase();
    } catch {}
    if (currentUser?.role === 'faculty') {
      try {
        fetch('/api/faculty/logout', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ deviceId: currentDeviceId }),
        });
      } catch {}
    }
    setCurrentUser(null);
    setCurrentView('home');
    setActiveTestId(null);
    setActiveAttemptId(null);
    try {
      localStorage.removeItem(AUTH_STORAGE_KEY);
    } catch {}
  };

  const signInWithGoogle = async () => {
    try {
      await loginWithGoogleViaSupabase();
    } catch {
      // Demo fallback login as student if popup/redirect is prevented by iframe
      loginAsDemoStudent(0);
    }
  };

  // =========================================================================
  // FACULTY ACTIONS: TEST SERIES & TESTS (SAVED LIVE TO SUPABASE)
  // =========================================================================

  const createTestSeries = async (seriesData: Omit<TestSeries, 'id'>): Promise<string> => {
    const id = `series-${Date.now()}`;
    const newSeries: TestSeries = {
      ...seriesData,
      id,
      upiId: seriesData.upiId || instituteUpi.upiId,
      upiQrUrl: seriesData.upiQrUrl || instituteUpi.qrUrl,
      testsCount: 0,
      enrolledCount: 0,
    };
    const nextSeries = [newSeries, ...testSeries];
    setTestSeries(nextSeries);
    saveLocalCache(STORAGE_KEY_SERIES, nextSeries);

    // Save to Supabase Cloud, server sync, and broadcast to student devices
    supabaseUpsert('test_series', newSeries);
    syncToServer({ testSeries: nextSeries });
    broadcastViaSupabase('SERIES_CREATED', newSeries, currentDeviceId);

    return id;
  };

  const updateTestSeries = async (id: string, updates: Partial<TestSeries>) => {
    const nextSeries = testSeries.map((s) => (s.id === id ? { ...s, ...updates } : s));
    setTestSeries(nextSeries);
    saveLocalCache(STORAGE_KEY_SERIES, nextSeries);

    const target = nextSeries.find((s) => s.id === id);
    if (target) {
      supabaseUpsert('test_series', target);
      broadcastViaSupabase('SERIES_UPDATED', target, currentDeviceId);
    }
    syncToServer({ testSeries: nextSeries });
  };

  const deleteTestSeries = async (id: string) => {
    const nextSeries = testSeries.filter((s) => s.id !== id);
    const nextTests = tests.filter((t) => t.seriesId !== id);
    setTestSeries(nextSeries);
    setTests(nextTests);
    saveLocalCache(STORAGE_KEY_SERIES, nextSeries);
    saveLocalCache(STORAGE_KEY_TESTS, nextTests);

    supabaseDeleteRow('test_series', id);
    broadcastViaSupabase('SERIES_DELETED', { id }, currentDeviceId);
    syncToServer({ testSeries: nextSeries, tests: nextTests });
  };

  const createTest = async (testData: Omit<Test, 'id' | 'createdAt'>): Promise<string> => {
    const id = `test-${Date.now()}`;
    const newTest: Test = {
      ...testData,
      id,
      createdAt: new Date().toISOString(),
      isPublished: true,
    };
    const nextTests = [newTest, ...tests];
    setTests(nextTests);
    saveLocalCache(STORAGE_KEY_TESTS, nextTests);

    // Increment series test count
    const nextSeries = testSeries.map((s) =>
      s.id === testData.seriesId
        ? { ...s, testsCount: (s.testsCount || 0) + 1 }
        : s
    );
    setTestSeries(nextSeries);
    saveLocalCache(STORAGE_KEY_SERIES, nextSeries);

    // Save to Supabase Cloud, server, and broadcast
    supabaseUpsert('tests', newTest);
    const targetSeries = nextSeries.find((s) => s.id === testData.seriesId);
    if (targetSeries) supabaseUpsert('test_series', targetSeries);

    syncToServer({ tests: nextTests, testSeries: nextSeries });
    broadcastViaSupabase('TEST_CREATED', newTest, currentDeviceId);

    return id;
  };

  const updateTest = async (id: string, updates: Partial<Test>) => {
    const nextTests = tests.map((t) => (t.id === id ? { ...t, ...updates } : t));
    setTests(nextTests);
    saveLocalCache(STORAGE_KEY_TESTS, nextTests);

    const target = nextTests.find((t) => t.id === id);
    if (target) {
      supabaseUpsert('tests', target);
      broadcastViaSupabase('TEST_UPDATED', target, currentDeviceId);
    }
    syncToServer({ tests: nextTests });
  };

  const deleteTest = async (id: string) => {
    const targetTest = tests.find((t) => t.id === id);
    const nextTests = tests.filter((t) => t.id !== id);
    setTests(nextTests);
    saveLocalCache(STORAGE_KEY_TESTS, nextTests);

    let nextSeries = testSeries;
    if (targetTest) {
      nextSeries = testSeries.map((s) =>
        s.id === targetTest.seriesId
          ? { ...s, testsCount: Math.max(0, (s.testsCount || 1) - 1) }
          : s
      );
      setTestSeries(nextSeries);
      saveLocalCache(STORAGE_KEY_SERIES, nextSeries);
    }

    supabaseDeleteRow('tests', id);
    broadcastViaSupabase('TEST_DELETED', { id }, currentDeviceId);
    syncToServer({ tests: nextTests, testSeries: nextSeries });
  };

  const toggleTestLock = async (testId: string) => {
    const current = tests.find((t) => t.id === testId);
    const nextLocked = current ? !current.isLockedByFaculty : true;
    await updateTest(testId, { isLockedByFaculty: nextLocked });
  };

  const updateTestSubjectOrder = async (testId: string, order: SubjectSection[]) => {
    await updateTest(testId, { subjectOrder: order });
  };

  const updateTestSchedule = async (
    testId: string,
    startTime?: string,
    endTime?: string,
    isScheduled?: boolean
  ) => {
    const scheduledFlag = isScheduled !== undefined ? isScheduled : !!startTime;
    const updates: Partial<Test> = {
      isScheduled: scheduledFlag,
    };
    if (startTime !== undefined) updates.scheduledStartTime = startTime;
    if (endTime !== undefined) updates.scheduledEndTime = endTime;

    await updateTest(testId, updates);
  };

  // =========================================================================
  // AUTOMATIC TEST-SAVING LOGIC (TEST QUESTIONS AUTO-SAVE IMMEDIATELY TO SUPABASE)
  // Ensures test questions, options, solution images, and answers persist forever!
  // =========================================================================

  const addQuestion = async (testId: string, qData: Omit<Question, 'id'>) => {
    const newQuestion: Question = {
      ...qData,
      id: `q-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
    };

    const targetTest = tests.find((t) => t.id === testId);
    const existingQuestions = targetTest?.questions || [];
    const updatedQuestions = [...existingQuestions, newQuestion];
    const newTotalMarks = updatedQuestions.reduce(
      (sum, q) => sum + (q.positiveMarks || 4),
      0
    );

    const updatedTest: Test = {
      ...(targetTest || {
        id: testId,
        title: 'New Test',
        seriesId: testSeries[0]?.id || 'series-jee-main-2026',
        examType: 'JEE Main' as ExamType,
        durationMinutes: 180,
        totalMarks: newTotalMarks,
        description: 'Mock practice test paper with questions and detailed solutions',
        sections: ['Physics', 'Chemistry', 'Mathematics'] as SubjectSection[],
        questions: [],
        createdAt: new Date().toISOString(),
        isPublished: true,
      }),
      questions: updatedQuestions,
      totalMarks: newTotalMarks,
    };

    const nextTests = tests.map((t) => (t.id === testId ? updatedTest : t));
    if (!tests.some((t) => t.id === testId)) {
      nextTests.unshift(updatedTest);
    }
    setTests(nextTests);

    // 1. Instant local persistence (prevents vanishing on refresh)
    saveLocalCache(STORAGE_KEY_TESTS, nextTests);

    // 2. Server persistence
    syncToServer({ tests: nextTests });

    // 3. Supabase Cloud table upsert
    supabaseUpsert('tests', updatedTest);

    // 4. Supabase Realtime broadcast to student devices
    broadcastViaSupabase('QUESTION_SAVED', updatedTest, currentDeviceId);

    setLastSyncTime(
      new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })
    );
  };

  const updateQuestion = async (
    testId: string,
    questionId: string,
    qUpdates: Partial<Question>
  ) => {
    const targetTest = tests.find((t) => t.id === testId);
    if (!targetTest) return;

    const updatedQuestions = targetTest.questions.map((q) =>
      q.id === questionId ? { ...q, ...qUpdates } : q
    );
    const newTotalMarks = updatedQuestions.reduce(
      (sum, q) => sum + (q.positiveMarks || 4),
      0
    );

    const updatedTest: Test = {
      ...targetTest,
      questions: updatedQuestions,
      totalMarks: newTotalMarks,
    };

    const nextTests = tests.map((t) => (t.id === testId ? updatedTest : t));
    setTests(nextTests);

    // Instant local cache + server + Supabase + Realtime push
    saveLocalCache(STORAGE_KEY_TESTS, nextTests);
    syncToServer({ tests: nextTests });
    supabaseUpsert('tests', updatedTest);
    broadcastViaSupabase('QUESTION_SAVED', updatedTest, currentDeviceId);

    setLastSyncTime(
      new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })
    );
  };

  const deleteQuestion = async (testId: string, questionId: string) => {
    const targetTest = tests.find((t) => t.id === testId);
    if (!targetTest) return;

    const updatedQuestions = targetTest.questions.filter((q) => q.id !== questionId);
    const newTotalMarks = updatedQuestions.reduce(
      (sum, q) => sum + (q.positiveMarks || 4),
      0
    );

    const updatedTest: Test = {
      ...targetTest,
      questions: updatedQuestions,
      totalMarks: newTotalMarks,
    };

    const nextTests = tests.map((t) => (t.id === testId ? updatedTest : t));
    setTests(nextTests);

    saveLocalCache(STORAGE_KEY_TESTS, nextTests);
    syncToServer({ tests: nextTests });
    supabaseUpsert('tests', updatedTest);
    broadcastViaSupabase('QUESTION_SAVED', updatedTest, currentDeviceId);

    setLastSyncTime(
      new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })
    );
  };

  const batchAddQuestions = async (testId: string, newQuestions: Question[]) => {
    const targetTest = tests.find((t) => t.id === testId);
    const existingQuestions = targetTest?.questions || [];
    const updatedQuestions = [...existingQuestions, ...newQuestions];
    const newTotalMarks = updatedQuestions.reduce(
      (sum, q) => sum + (q.positiveMarks || 4),
      0
    );

    const updatedTest: Test = {
      ...(targetTest || {
        id: testId,
        title: 'Imported Test',
        seriesId: testSeries[0]?.id || 'series-jee-main-2026',
        examType: 'JEE Main' as ExamType,
        durationMinutes: 180,
        totalMarks: newTotalMarks,
        description: 'Mock practice test paper with questions and detailed solutions',
        sections: ['Physics', 'Chemistry', 'Mathematics'] as SubjectSection[],
        questions: [],
        createdAt: new Date().toISOString(),
        isPublished: true,
      }),
      questions: updatedQuestions,
      totalMarks: newTotalMarks,
    };

    const nextTests = tests.map((t) => (t.id === testId ? updatedTest : t));
    if (!tests.some((t) => t.id === testId)) {
      nextTests.unshift(updatedTest);
    }
    setTests(nextTests);

    saveLocalCache(STORAGE_KEY_TESTS, nextTests);
    syncToServer({ tests: nextTests });
    supabaseUpsert('tests', updatedTest);
    broadcastViaSupabase('QUESTION_SAVED', updatedTest, currentDeviceId);

    setLastSyncTime(
      new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })
    );
  };

  const updateQuickAnswerKey = async (
    testId: string,
    questionId: string,
    newAnswer: string
  ) => {
    await updateQuestion(testId, questionId, { correctAnswer: newAnswer });
  };

  // Dedicated Permanent Supabase Cloud Test & Answer Key Sync
  const saveTestToCloud = async (testId: string): Promise<{ success: boolean; message: string }> => {
    const targetTest = tests.find((t) => t.id === testId);
    if (!targetTest) {
      return { success: false, message: 'Test not found' };
    }

    try {
      // 1. Commit to local cache
      saveLocalCache(STORAGE_KEY_TESTS, tests);

      // 2. Commit to server storage
      await syncToServer({ tests });

      // 3. Commit to Supabase Cloud
      await supabaseUpsert('tests', targetTest);

      // 4. Update series test count
      const targetSeries = testSeries.find((s) => s.id === targetTest.seriesId);
      if (targetSeries) {
        const seriesTests = tests.filter((t) => t.seriesId === targetSeries.id);
        const updatedSeries = { ...targetSeries, testsCount: seriesTests.length };
        await supabaseUpsert('test_series', updatedSeries);
      }

      // 5. Broadcast to student devices via Supabase Realtime
      await broadcastViaSupabase('TEST_UPDATED', targetTest, currentDeviceId);

      setLastSyncTime(
        new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })
      );

      return {
        success: true,
        message: `Test "${targetTest.title}" with ${targetTest.questions.length} questions permanently saved to Supabase Cloud.`,
      };
    } catch (err: any) {
      console.error('Supabase saveTestToCloud error:', err);
      return {
        success: false,
        message: err?.message || 'Failed to save test to Supabase Cloud',
      };
    }
  };

  // Update Institute UPI & QR Code (Auto-saves to Supabase + local cache + server)
  const updateInstituteUpi = async (settings: Partial<InstituteUpiSettings>) => {
    const nextUpi: InstituteUpiSettings = {
      ...instituteUpi,
      ...settings,
    };
    setInstituteUpi(nextUpi);

    // Save to local cache so UPI QR never vanishes on refresh
    saveLocalCache(STORAGE_KEY_UPI, nextUpi);

    // Save to server
    syncToServer({ instituteUpi: nextUpi });

    // Save to Supabase Cloud
    supabaseUpsert('institute_upi', nextUpi);

    // Broadcast live over Supabase Realtime so all student devices get it instantly
    broadcastViaSupabase('UPI_UPDATED', nextUpi, currentDeviceId);

    setLastSyncTime(
      new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })
    );
  };

  // =========================================================================
  // NOTICES & STUDY MATERIALS (LIVE SYNCHRONIZATION VIA SUPABASE)
  // =========================================================================

  const createNotice = async (noticeData: Omit<Notice, 'id' | 'createdAt'>): Promise<string> => {
    const id = `notice-${Date.now()}`;
    const newNotice: Notice = {
      ...noticeData,
      id,
      createdAt: new Date().toISOString(),
    };
    const nextNotices = [newNotice, ...notices];
    setNotices(nextNotices);
    saveLocalCache(STORAGE_KEY_NOTICES, nextNotices);

    supabaseUpsert('notices', newNotice);
    syncToServer({ notices: nextNotices });
    broadcastViaSupabase('NOTICE_UPDATED', nextNotices, currentDeviceId);

    return id;
  };

  const deleteNotice = async (id: string) => {
    const nextNotices = notices.filter((n) => n.id !== id);
    setNotices(nextNotices);
    saveLocalCache(STORAGE_KEY_NOTICES, nextNotices);

    supabaseDeleteRow('notices', id);
    syncToServer({ notices: nextNotices });
    broadcastViaSupabase('NOTICE_UPDATED', nextNotices, currentDeviceId);
  };

  const createMaterial = async (matData: Omit<StudyMaterial, 'id' | 'uploadedAt'>): Promise<string> => {
    const id = `mat-${Date.now()}`;
    const newMat: StudyMaterial = {
      ...matData,
      id,
      uploadedAt: new Date().toISOString(),
    };
    const nextMaterials = [newMat, ...materials];
    setMaterials(nextMaterials);
    saveLocalCache(STORAGE_KEY_MATERIALS, nextMaterials);

    supabaseUpsert('materials', newMat);
    syncToServer({ materials: nextMaterials });
    broadcastViaSupabase('MATERIAL_UPDATED', nextMaterials, currentDeviceId);

    return id;
  };

  const deleteMaterial = async (id: string) => {
    const nextMaterials = materials.filter((m) => m.id !== id);
    setMaterials(nextMaterials);
    saveLocalCache(STORAGE_KEY_MATERIALS, nextMaterials);

    supabaseDeleteRow('materials', id);
    syncToServer({ materials: nextMaterials });
    broadcastViaSupabase('MATERIAL_UPDATED', nextMaterials, currentDeviceId);
  };

  // =========================================================================
  // FACULTY BIOS & MENTORS (LIVE SYNCHRONIZATION VIA SUPABASE)
  // =========================================================================

  const createFacultyProfile = async (
    profileData: Omit<FacultyProfile, 'id' | 'updatedAt'>
  ): Promise<string> => {
    const id = `faculty-${Date.now()}-${Math.floor(Math.random() * 1000)}`;
    const newProfile: FacultyProfile = {
      ...profileData,
      id,
      updatedAt: new Date().toISOString(),
    };
    const nextFaculty = [newProfile, ...facultyProfiles];
    setFacultyProfiles(nextFaculty);
    saveLocalCache(STORAGE_KEY_FACULTY, nextFaculty);

    supabaseUpsert('faculty_profiles', newProfile);
    syncToServer({ facultyProfiles: nextFaculty });
    broadcastViaSupabase('FACULTY_UPDATED', newProfile, currentDeviceId);

    setLastSyncTime(
      new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })
    );
    return id;
  };

  const updateFacultyProfile = async (id: string, updates: Partial<FacultyProfile>) => {
    const updatedWithTime = {
      ...updates,
      updatedAt: new Date().toISOString(),
    };
    const nextFaculty = facultyProfiles.map((f) => (f.id === id ? { ...f, ...updatedWithTime } : f));
    setFacultyProfiles(nextFaculty);
    saveLocalCache(STORAGE_KEY_FACULTY, nextFaculty);

    const target = nextFaculty.find((f) => f.id === id);
    if (target) {
      supabaseUpsert('faculty_profiles', target);
      broadcastViaSupabase('FACULTY_UPDATED', target, currentDeviceId);
    }
    syncToServer({ facultyProfiles: nextFaculty });

    setLastSyncTime(
      new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })
    );
  };

  const deleteFacultyProfile = async (id: string) => {
    const nextFaculty = facultyProfiles.filter((f) => f.id !== id);
    setFacultyProfiles(nextFaculty);
    saveLocalCache(STORAGE_KEY_FACULTY, nextFaculty);

    supabaseDeleteRow('faculty_profiles', id);
    syncToServer({ facultyProfiles: nextFaculty });
    broadcastViaSupabase('FACULTY_UPDATED', nextFaculty, currentDeviceId);
  };

  // =========================================================================
  // STUDENT ENROLLMENTS & VERIFICATION REQUESTS (LIVE SYNCHRONIZATION)
  // =========================================================================

  const sendVerificationRequest = async (
    seriesId: string,
    upiTxnId: string
  ): Promise<{ success: boolean; message: string }> => {
    if (!currentUser) {
      return { success: false, message: 'Please log in to submit a verification request.' };
    }
    const series = testSeries.find((s) => s.id === seriesId);
    if (!series) {
      return { success: false, message: 'Test series not found.' };
    }

    const newReq: PaymentVerificationRequest = {
      id: `verify-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      studentId: currentUser.id,
      studentName: currentUser.name,
      studentRoll: currentUser.rollNo || 'ARG-STUDENT',
      studentPhone: currentUser.phone || '+91 98765 43210',
      seriesId: series.id,
      seriesTitle: series.title,
      seriesPrice: series.price,
      upiTxnId: upiTxnId.trim() || `UPI-TXN-${Date.now()}`,
      requestedAt: new Date().toISOString(),
      status: 'pending',
    };

    const nextVerifications = [newReq, ...verificationRequests];
    setVerificationRequests(nextVerifications);
    saveLocalCache(STORAGE_KEY_VERIFICATIONS, nextVerifications);

    supabaseUpsert('verification_requests', newReq);
    syncToServer({ verificationRequests: nextVerifications });

    return {
      success: true,
      message: `Verification request sent to Faculty! Waiting for faculty approval to unlock "${series.title}".`,
    };
  };

  const approveVerificationRequest = async (requestId: string) => {
    const targetReq = verificationRequests.find((r) => r.id === requestId);
    if (!targetReq) return;

    const reviewedAt = new Date().toISOString();
    const reviewedBy = 'Admin / Faculty';

    const nextVerifications = verificationRequests.map((r) =>
      r.id === requestId
        ? {
            ...r,
            status: 'approved' as const,
            reviewedAt,
            reviewedBy,
          }
        : r
    );
    setVerificationRequests(nextVerifications);
    saveLocalCache(STORAGE_KEY_VERIFICATIONS, nextVerifications);

    const approvedReq = nextVerifications.find((r) => r.id === requestId);
    if (approvedReq) supabaseUpsert('verification_requests', approvedReq);

    // Grant access to student: update student's enrolledSeriesIds
    const nextStudents = students.map((st) => {
      if (st.id === targetReq.studentId || st.rollNo === targetReq.studentRoll) {
        const list = st.enrolledSeriesIds || [];
        if (!list.includes(targetReq.seriesId)) {
          const updated = { ...st, enrolledSeriesIds: [...list, targetReq.seriesId] };
          supabaseUpsert('students', updated);
          return updated;
        }
      }
      return st;
    });
    setStudents(nextStudents);
    saveLocalCache(STORAGE_KEY_STUDENTS, nextStudents);

    if (
      currentUser &&
      (currentUser.id === targetReq.studentId || currentUser.rollNo === targetReq.studentRoll)
    ) {
      const curList = currentUser.enrolledSeriesIds || [];
      if (!curList.includes(targetReq.seriesId)) {
        const updatedCur = { ...currentUser, enrolledSeriesIds: [...curList, targetReq.seriesId] };
        setCurrentUser(updatedCur);
        saveLocalCache(AUTH_STORAGE_KEY, updatedCur);
      }
    }

    // Increment test series enrolled count in state and Supabase
    const nextSeries = testSeries.map((s) => {
      if (s.id === targetReq.seriesId) {
        const newCount = (s.enrolledCount || 0) + 1;
        const updatedS = { ...s, enrolledCount: newCount };
        supabaseUpsert('test_series', updatedS);
        return updatedS;
      }
      return s;
    });
    setTestSeries(nextSeries);
    saveLocalCache(STORAGE_KEY_SERIES, nextSeries);

    syncToServer({
      verificationRequests: nextVerifications,
      students: nextStudents,
      testSeries: nextSeries,
    });
  };

  const rejectVerificationRequest = async (requestId: string, reason?: string) => {
    const targetReq = verificationRequests.find((r) => r.id === requestId);
    if (!targetReq) return;

    const reviewedAt = new Date().toISOString();
    const reviewedBy = 'Admin / Faculty';
    const rejectionReason = reason || 'UPI transaction reference could not be verified by institute accounts.';

    const nextVerifications = verificationRequests.map((r) =>
      r.id === requestId
        ? {
            ...r,
            status: 'rejected' as const,
            reviewedAt,
            reviewedBy,
            rejectionReason,
          }
        : r
    );
    setVerificationRequests(nextVerifications);
    saveLocalCache(STORAGE_KEY_VERIFICATIONS, nextVerifications);

    const rejectedReq = nextVerifications.find((r) => r.id === requestId);
    if (rejectedReq) supabaseUpsert('verification_requests', rejectedReq);

    syncToServer({ verificationRequests: nextVerifications });
  };

  const createDirectVerificationRequest = async (data: {
    studentId: string;
    studentName: string;
    studentRoll: string;
    studentPhone: string;
    seriesId: string;
    upiTxnId: string;
  }) => {
    const series = testSeries.find((s) => s.id === data.seriesId);
    const newReq: PaymentVerificationRequest = {
      id: `verify-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      studentId: data.studentId,
      studentName: data.studentName,
      studentRoll: data.studentRoll,
      studentPhone: data.studentPhone,
      seriesId: data.seriesId,
      seriesTitle: series?.title || 'Test Series',
      seriesPrice: series?.price || 499,
      upiTxnId: data.upiTxnId.trim() || `UPI-TXN-${Date.now()}`,
      requestedAt: new Date().toISOString(),
      status: 'pending',
    };
    const nextVerifications = [newReq, ...verificationRequests];
    setVerificationRequests(nextVerifications);
    saveLocalCache(STORAGE_KEY_VERIFICATIONS, nextVerifications);

    supabaseUpsert('verification_requests', newReq);
    syncToServer({ verificationRequests: nextVerifications });
  };

  const enrollInSeries = async (seriesId: string, txnId?: string) => {
    if (!currentUser) return;
    const series = testSeries.find((s) => s.id === seriesId);
    if (series && series.price > 0) {
      await sendVerificationRequest(seriesId, txnId || `UPI-TXN-${Date.now()}`);
      return;
    }

    const currentList = currentUser.enrolledSeriesIds || [];
    if (!currentList.includes(seriesId)) {
      const updatedUser = {
        ...currentUser,
        enrolledSeriesIds: [...currentList, seriesId],
      };
      setCurrentUser(updatedUser);
      saveLocalCache(AUTH_STORAGE_KEY, updatedUser);

      const nextStudents = students.map((s) => (s.id === currentUser.id ? updatedUser : s));
      setStudents(nextStudents);
      saveLocalCache(STORAGE_KEY_STUDENTS, nextStudents);
      supabaseUpsert('students', updatedUser);

      const nextSeries = testSeries.map((s) =>
        s.id === seriesId
          ? { ...s, enrolledCount: (s.enrolledCount || 0) + 1 }
          : s
      );
      setTestSeries(nextSeries);
      saveLocalCache(STORAGE_KEY_SERIES, nextSeries);

      syncToServer({ students: nextStudents, testSeries: nextSeries });
    }
  };

  const startExam = (testId: string) => {
    setActiveTestId(testId);
    setCurrentView('nta-exam');
  };

  // Student Test Submission (Saves immediately to Supabase + local cache + server + Realtime push)
  const submitExam = async (attempt: StudentTestAttempt) => {
    const nextAttempts = [attempt, ...attempts];
    setAttempts(nextAttempts);
    saveLocalCache(STORAGE_KEY_SUBMISSIONS, nextAttempts);

    setActiveAttemptId(attempt.id);
    setCurrentView('result-view');

    // Persist to Supabase and push to all connected Faculty stations
    supabaseUpsert('submissions', attempt);
    syncToServer({ attempts: nextAttempts });
    broadcastViaSupabase('ATTEMPT_SUBMITTED', attempt, currentDeviceId);
  };

  const viewResult = (attemptId: string) => {
    setActiveAttemptId(attemptId);
    setCurrentView('result-view');
  };

  const exitExamOrResult = () => {
    if (currentUser?.role === 'faculty') {
      setCurrentView('faculty-dashboard');
    } else {
      setCurrentView('student-dashboard');
    }
  };

  const resetAllDataToDefault = async () => {
    setTestSeries(INITIAL_TEST_SERIES);
    setTests(INITIAL_TESTS);
    setAttempts(INITIAL_STUDENT_ATTEMPTS);
    setStudents(DEMO_STUDENT_USERS);
    setVerificationRequests(INITIAL_VERIFICATION_REQUESTS);
    setNotices(INITIAL_NOTICES);
    setMaterials(INITIAL_MATERIALS);
    setFacultyProfiles(INITIAL_FACULTY_PROFILES);
    setInstituteUpi({
      upiId: 'argoncoaching@icici',
      merchantName: 'ARGON COACHING ACADEMY ASSAM',
      qrUrl: INSTITUTION_UPI_QR,
      note: 'Scan via any UPI App to unlock test series',
    });
    setCurrentUser(null);
    setCurrentView('home');

    saveLocalCache(STORAGE_KEY_TESTS, INITIAL_TESTS);
    saveLocalCache(STORAGE_KEY_SERIES, INITIAL_TEST_SERIES);
    saveLocalCache(STORAGE_KEY_SUBMISSIONS, INITIAL_STUDENT_ATTEMPTS);
    saveLocalCache(STORAGE_KEY_STUDENTS, DEMO_STUDENT_USERS);
    saveLocalCache(STORAGE_KEY_VERIFICATIONS, INITIAL_VERIFICATION_REQUESTS);
    saveLocalCache(STORAGE_KEY_NOTICES, INITIAL_NOTICES);
    saveLocalCache(STORAGE_KEY_MATERIALS, INITIAL_MATERIALS);
    saveLocalCache(STORAGE_KEY_FACULTY, INITIAL_FACULTY_PROFILES);
    saveLocalCache(STORAGE_KEY_UPI, {
      upiId: 'argoncoaching@icici',
      merchantName: 'ARGON COACHING ACADEMY ASSAM',
      qrUrl: INSTITUTION_UPI_QR,
      note: 'Scan via any UPI App to unlock test series',
    });

    syncToServer({
      tests: INITIAL_TESTS,
      testSeries: INITIAL_TEST_SERIES,
      attempts: INITIAL_STUDENT_ATTEMPTS,
      students: DEMO_STUDENT_USERS,
      verificationRequests: INITIAL_VERIFICATION_REQUESTS,
      notices: INITIAL_NOTICES,
      materials: INITIAL_MATERIALS,
      facultyProfiles: INITIAL_FACULTY_PROFILES,
      instituteUpi: {
        upiId: 'argoncoaching@icici',
        merchantName: 'ARGON COACHING ACADEMY ASSAM',
        qrUrl: INSTITUTION_UPI_QR,
        note: 'Scan via any UPI App to unlock test series',
      },
    });

    broadcastViaSupabase(
      'FULL_STATE_SYNC',
      {
        tests: INITIAL_TESTS,
        testSeries: INITIAL_TEST_SERIES,
        instituteUpi: {
          upiId: 'argoncoaching@icici',
          merchantName: 'ARGON COACHING ACADEMY ASSAM',
          qrUrl: INSTITUTION_UPI_QR,
          note: 'Scan via any UPI App to unlock test series',
        },
      },
      currentDeviceId
    );
  };

  return (
    <AppContext.Provider
      value={{
        currentUser,
        role,
        currentView,
        testSeries,
        tests,
        attempts,
        students,
        verificationRequests,
        notices,
        materials,
        facultyProfiles,
        instituteUpi,
        activeTestId,
        activeAttemptId,
        isSupabaseConnected,
        isFirebaseConnected: isSupabaseConnected, // Alias so existing components retain live indicator
        isOnline,
        connectionStatus,
        lastSyncTime,
        refreshFromServer,
        signInWithGoogle,
        setCurrentView,
        loginAsFaculty,
        loginAsFacultyAsync,
        revokeFacultyDevice,
        activeFacultyDevices,
        currentDeviceId,
        loginAsDemoStudent,
        loginStudentByNameAndRoll,
        registerOrLoginStudent,
        updateStudentPhone,
        registerStudentByAdmin,
        updateStudentByAdmin,
        deleteStudentByAdmin,
        logout,
        createTestSeries,
        updateTestSeries,
        deleteTestSeries,
        createTest,
        updateTest,
        deleteTest,
        toggleTestLock,
        updateTestSubjectOrder,
        updateTestSchedule,
        addQuestion,
        updateQuestion,
        deleteQuestion,
        batchAddQuestions,
        updateQuickAnswerKey,
        saveTestToCloud,
        updateInstituteUpi,
        createNotice,
        deleteNotice,
        createMaterial,
        deleteMaterial,
        createFacultyProfile,
        updateFacultyProfile,
        deleteFacultyProfile,
        sendVerificationRequest,
        approveVerificationRequest,
        rejectVerificationRequest,
        createDirectVerificationRequest,
        enrollInSeries,
        startExam,
        submitExam,
        viewResult,
        exitExamOrResult,
        resetAllDataToDefault,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
