import type {
  TestSeries,
  Test,
  Question,
  User,
  StudentTestAttempt,
  PaymentVerificationRequest,
  Notice,
  StudyMaterial,
  FacultyProfile,
} from '../types/index.ts';

// High quality scientific diagrams as inline SVG data URLs
export const DIAGRAM_OPTICS = `data:image/svg+xml;utf8,${encodeURIComponent(`
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 400 240" width="100%" height="100%">
  <rect width="400" height="240" fill="#f8fafc" rx="8" stroke="#cbd5e1" stroke-width="1.5"/>
  <text x="20" y="30" font-family="sans-serif" font-size="13" font-weight="bold" fill="#1e293b">Ray Optics: Refraction at Prism Interface (A = 60°)</text>
  <!-- Prism -->
  <polygon points="200,60 120,200 280,200" fill="#e0f2fe" stroke="#0284c7" stroke-width="2.5" />
  <text x="195" y="52" font-family="sans-serif" font-size="12" font-weight="bold" fill="#0369a1">A</text>
  <!-- Incident Ray -->
  <line x1="50" y1="170" x2="155" y2="138" stroke="#dc2626" stroke-width="2.5" />
  <!-- Arrow -->
  <polygon points="105,150 115,152 108,158" fill="#dc2626" />
  <!-- Refracted Ray inside -->
  <line x1="155" y1="138" x2="245" y2="138" stroke="#dc2626" stroke-width="2.5" stroke-dasharray="2,2"/>
  <!-- Emergent Ray -->
  <line x1="245" y1="138" x2="350" y2="175" stroke="#dc2626" stroke-width="2.5" />
  <polygon points="295,153 305,159 298,163" fill="#dc2626" />
  <!-- Normal 1 -->
  <line x1="130" y1="95" x2="180" y2="185" stroke="#64748b" stroke-width="1.5" stroke-dasharray="4,4"/>
  <!-- Normal 2 -->
  <line x1="270" y1="95" x2="220" y2="185" stroke="#64748b" stroke-width="1.5" stroke-dasharray="4,4"/>
  <!-- Angle Labels -->
  <text x="100" y="145" font-family="sans-serif" font-size="12" fill="#b91c1c">i</text>
  <text x="285" y="150" font-family="sans-serif" font-size="12" fill="#b91c1c">e</text>
  <text x="170" y="130" font-family="sans-serif" font-size="11" fill="#475569">r₁</text>
  <text x="222" y="130" font-family="sans-serif" font-size="11" fill="#475569">r₂</text>
  <text x="200" y="222" font-family="sans-serif" font-size="11" text-anchor="middle" fill="#64748b">Prism Angle A = r₁ + r₂ ; Minimum Deviation δm = 30°</text>
</svg>
`)}`;

export const DIAGRAM_CIRCUIT = `data:image/svg+xml;utf8,${encodeURIComponent(`
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 400 240" width="100%" height="100%">
  <rect width="400" height="240" fill="#f8fafc" rx="8" stroke="#cbd5e1" stroke-width="1.5"/>
  <text x="20" y="28" font-family="sans-serif" font-size="13" font-weight="bold" fill="#1e293b">Wheatstone Bridge Circuit Network</text>
  <!-- Diamond bridge -->
  <line x1="200" y1="50" x2="120" y2="130" stroke="#0f172a" stroke-width="2"/>
  <line x1="200" y1="50" x2="280" y2="130" stroke="#0f172a" stroke-width="2"/>
  <line x1="120" y1="130" x2="200" y2="210" stroke="#0f172a" stroke-width="2"/>
  <line x1="280" y1="130" x2="200" y2="210" stroke="#0f172a" stroke-width="2"/>
  <!-- Resistor 1: P = 4Ω -->
  <rect x="145" y="80" width="30" height="15" fill="#fef08a" stroke="#ca8a04" stroke-width="1.5" transform="rotate(-45 160 87)"/>
  <text x="135" y="75" font-family="sans-serif" font-size="11" font-weight="bold" fill="#854d0e">P = 4 Ω</text>
  <!-- Resistor 2: Q = 8Ω -->
  <rect x="225" y="80" width="30" height="15" fill="#fef08a" stroke="#ca8a04" stroke-width="1.5" transform="rotate(45 240 87)"/>
  <text x="245" y="75" font-family="sans-serif" font-size="11" font-weight="bold" fill="#854d0e">Q = 8 Ω</text>
  <!-- Resistor 3: R = 6Ω -->
  <rect x="145" y="160" width="30" height="15" fill="#fef08a" stroke="#ca8a04" stroke-width="1.5" transform="rotate(45 160 167)"/>
  <text x="135" y="195" font-family="sans-serif" font-size="11" font-weight="bold" fill="#854d0e">R = 6 Ω</text>
  <!-- Resistor 4: S = ? -->
  <rect x="225" y="160" width="30" height="15" fill="#fef08a" stroke="#ca8a04" stroke-width="1.5" transform="rotate(-45 240 167)"/>
  <text x="250" y="195" font-family="sans-serif" font-size="11" font-weight="bold" fill="#dc2626">S = ?</text>
  <!-- Galvanometer center -->
  <line x1="120" y1="130" x2="280" y2="130" stroke="#2563eb" stroke-width="1.5" stroke-dasharray="3,3"/>
  <circle cx="200" cy="130" r="14" fill="#dbeafe" stroke="#2563eb" stroke-width="2"/>
  <text x="195" y="135" font-family="sans-serif" font-size="13" font-weight="bold" fill="#1d4ed8">G</text>
  <text x="200" y="160" font-family="sans-serif" font-size="11" text-anchor="middle" fill="#2563eb">Ig = 0 (Null deflection)</text>
</svg>
`)}`;

export const DIAGRAM_GENETICS = `data:image/svg+xml;utf8,${encodeURIComponent(`
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 400 240" width="100%" height="100%">
  <rect width="400" height="240" fill="#f8fafc" rx="8" stroke="#cbd5e1" stroke-width="1.5"/>
  <text x="20" y="30" font-family="sans-serif" font-size="13" font-weight="bold" fill="#1e293b">Pedigree Chart: Autosomal Recessive Inheritance</text>
  <!-- Generation I -->
  <rect x="100" y="60" width="30" height="30" fill="#ffffff" stroke="#0f172a" stroke-width="2"/>
  <line x1="130" y1="75" x2="210" y2="75" stroke="#0f172a" stroke-width="2"/>
  <circle cx="225" cy="75" r="15" fill="#ffffff" stroke="#0f172a" stroke-width="2"/>
  <!-- Connection to Gen II -->
  <line x1="170" y1="75" x2="170" y2="120" stroke="#0f172a" stroke-width="2"/>
  <line x1="80" y1="120" x2="260" y2="120" stroke="#0f172a" stroke-width="2"/>
  <!-- Offsprings -->
  <!-- 1. Normal son -->
  <line x1="80" y1="120" x2="80" y2="150" stroke="#0f172a" stroke-width="2"/>
  <rect x="65" y="150" width="30" height="30" fill="#ffffff" stroke="#0f172a" stroke-width="2"/>
  <!-- 2. Affected daughter (Filled circle) -->
  <line x1="170" y1="120" x2="170" y2="150" stroke="#0f172a" stroke-width="2"/>
  <circle cx="170" cy="165" r="15" fill="#dc2626" stroke="#b91c1c" stroke-width="2"/>
  <text x="164" y="170" font-family="sans-serif" font-size="12" font-weight="bold" fill="#ffffff">*</text>
  <!-- 3. Normal daughter -->
  <line x1="260" y1="120" x2="260" y2="150" stroke="#0f172a" stroke-width="2"/>
  <circle cx="260" cy="165" r="15" fill="#ffffff" stroke="#0f172a" stroke-width="2"/>
  <!-- Labels -->
  <text x="30" y="78" font-family="sans-serif" font-size="12" font-weight="bold" fill="#475569">I</text>
  <text x="30" y="168" font-family="sans-serif" font-size="12" font-weight="bold" fill="#475569">II</text>
  <text x="200" y="215" font-family="sans-serif" font-size="11" text-anchor="middle" fill="#047857">Parents: Unaffected Heterozygotes (Aa x Aa) → Affected Child (aa)</text>
</svg>
`)}`;

export const INSTITUTION_UPI_QR = `data:image/svg+xml;utf8,${encodeURIComponent(`
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 300 300" width="100%" height="100%">
  <rect width="300" height="300" fill="#ffffff" rx="16" stroke="#e2e8f0" stroke-width="2"/>
  <!-- Stylized High-Tech QR Pattern -->
  <rect x="25" y="25" width="70" height="70" fill="none" stroke="#1e3a8a" stroke-width="8" rx="8"/>
  <rect x="42" y="42" width="36" height="36" fill="#1e3a8a" rx="4"/>
  <rect x="205" y="25" width="70" height="70" fill="none" stroke="#1e3a8a" stroke-width="8" rx="8"/>
  <rect x="222" y="42" width="36" height="36" fill="#1e3a8a" rx="4"/>
  <rect x="25" y="205" width="70" height="70" fill="none" stroke="#1e3a8a" stroke-width="8" rx="8"/>
  <rect x="42" y="222" width="36" height="36" fill="#1e3a8a" rx="4"/>
  <!-- Simulated QR Matrix Dots -->
  <g fill="#1e293b">
    <rect x="110" y="30" width="16" height="16" rx="2"/>
    <rect x="140" y="30" width="16" height="16" rx="2"/>
    <rect x="170" y="30" width="16" height="16" rx="2"/>
    <rect x="110" y="60" width="16" height="16" rx="2"/>
    <rect x="150" y="60" width="16" height="16" rx="2"/>
    <rect x="180" y="60" width="16" height="16" rx="2"/>
    <rect x="110" y="90" width="16" height="16" rx="2"/>
    <rect x="140" y="90" width="16" height="16" rx="2"/>
    <rect x="30" y="110" width="16" height="16" rx="2"/>
    <rect x="60" y="110" width="16" height="16" rx="2"/>
    <rect x="90" y="110" width="16" height="16" rx="2"/>
    <rect x="120" y="110" width="16" height="16" rx="2"/>
    <rect x="150" y="110" width="16" height="16" rx="2"/>
    <rect x="180" y="110" width="16" height="16" rx="2"/>
    <rect x="210" y="110" width="16" height="16" rx="2"/>
    <rect x="240" y="110" width="16" height="16" rx="2"/>
    <rect x="30" y="140" width="16" height="16" rx="2"/>
    <rect x="70" y="140" width="16" height="16" rx="2"/>
    <rect x="220" y="140" width="16" height="16" rx="2"/>
    <rect x="250" y="140" width="16" height="16" rx="2"/>
    <rect x="110" y="170" width="16" height="16" rx="2"/>
    <rect x="140" y="170" width="16" height="16" rx="2"/>
    <rect x="170" y="170" width="16" height="16" rx="2"/>
    <rect x="210" y="170" width="16" height="16" rx="2"/>
    <rect x="110" y="200" width="16" height="16" rx="2"/>
    <rect x="150" y="200" width="16" height="16" rx="2"/>
    <rect x="180" y="200" width="16" height="16" rx="2"/>
    <rect x="210" y="200" width="16" height="16" rx="2"/>
    <rect x="240" y="200" width="16" height="16" rx="2"/>
    <rect x="120" y="230" width="16" height="16" rx="2"/>
    <rect x="150" y="230" width="16" height="16" rx="2"/>
    <rect x="180" y="230" width="16" height="16" rx="2"/>
    <rect x="220" y="230" width="16" height="16" rx="2"/>
    <rect x="250" y="230" width="16" height="16" rx="2"/>
  </g>
  <!-- Center Institute Brand Badge -->
  <circle cx="150" cy="150" r="30" fill="#1e3a8a" stroke="#ffffff" stroke-width="4"/>
  <text x="150" y="156" font-family="sans-serif" font-size="14" font-weight="900" fill="#ffffff" text-anchor="middle">ARGON</text>
</svg>
`)}`;

export const INITIAL_TEST_SERIES: TestSeries[] = [
  {
    id: 'series-jee-adv-2026',
    title: 'JEE Advanced Apex All-India Mock Series 2026',
    category: 'JEE Advanced Mock',
    targetExam: 'JEE Advanced',
    price: 999,
    originalPrice: 2499,
    description:
      'Engineered by ex-IITians and Assam senior faculty. Rigorous multi-concept questions with exact NTA Computer Based Test layout and deep analytics.',
    features: [
      'Authentic NTA CBT interface with section navigation',
      'High-yield Physics, Chemistry & Math questions',
      'Step-by-step graphical & formula explanations',
      'Instant percentile & AIR predictor algorithm',
    ],
    upiId: 'argoncoaching@icici',
    upiQrUrl: INSTITUTION_UPI_QR,
    paymentNote:
      'Scan using PhonePe / Google Pay / Paytm. Enter UTR reference number to unlock all 10 tests instantly.',
    badge: 'Assam Top Ranked',
    testsCount: 6,
    enrolledCount: 1420,
  },
  {
    id: 'series-neet-weekly-phys',
    title: 'NEET Physics Weekly Mastery Series',
    category: 'NEET Physics Weekly',
    targetExam: 'NEET',
    price: 499,
    originalPrice: 1299,
    description:
      'Score 170+ in NEET Physics! Chapter-wise targeted tests covering Mechanics, Ray & Wave Optics, Electrodynamics and Modern Physics with NCERT alignment.',
    features: [
      'NCERT Line-by-line & High-frequency PYQ Patterns',
      'Ray Optics & Circuit Diagrams in HD resolution',
      'Dedicated time-management speed drills',
      '+4 / -1 instant marking evaluation',
    ],
    upiId: 'argoncoaching@icici',
    upiQrUrl: INSTITUTION_UPI_QR,
    paymentNote:
      'Payment verified within seconds via Argon automated payment gateway.',
    badge: 'High Yield',
    testsCount: 8,
    enrolledCount: 2310,
  },
  {
    id: 'series-jee-main-free',
    title: 'JEE Main 2026 All-India Free Diagnostic Test Series',
    category: 'JEE Main Mock',
    targetExam: 'JEE Main',
    price: 0,
    originalPrice: 799,
    description:
      'Open to all students pan-India. Benchmark your preparation against thousands of competitors with real NTA-pattern question papers and difficulty grading.',
    features: [
      '100% Free - Instant 1-Click Enrollment',
      'Full 3-Hour Simulation (Physics, Chemistry, Maths)',
      'Single Correct MCQ + Numerical Value Types',
      'Sectional cut-off & detailed error analysis',
    ],
    upiId: 'argoncoaching@icici',
    upiQrUrl: INSTITUTION_UPI_QR,
    paymentNote: 'Free access sponsored by Argon Alumni Foundation.',
    badge: '100% Free',
    testsCount: 4,
    enrolledCount: 5640,
  },
  {
    id: 'series-neet-bio-360',
    title: 'NEET Biology 360/360 Booster Sprint',
    category: 'NEET Biology Booster',
    targetExam: 'NEET',
    price: 399,
    originalPrice: 999,
    description:
      'Comprehensive Zoology & Botany mock tests covering Genetics, Cell Biology, Human Physiology, and Ecology with strict NCERT fidelity.',
    features: [
      'NCERT Statement & Assertion-Reason Questions',
      'High-resolution Pedigree Charts & Anatomical Diagrams',
      'Immediate answer key breakdown',
      'Mobile & Desktop responsive NTA CBT test player',
    ],
    upiId: 'argoncoaching@icici',
    upiQrUrl: INSTITUTION_UPI_QR,
    paymentNote: 'Scan the UPI QR code to access all chapter tests.',
    badge: 'Most Popular',
    testsCount: 12,
    enrolledCount: 3180,
  },
];

export const INITIAL_TESTS: Test[] = [
  {
    id: 'test-jee-adv-101',
    seriesId: 'series-jee-adv-2026',
    title: 'JEE Advanced Apex Mock Test 01 - Paper 1',
    examType: 'JEE Advanced',
    durationMinutes: 60,
    totalMarks: 36,
    description:
      'Comprehensive Full Syllabus Paper 1 covering advanced mechanics, coordination chemistry, optics, and calculus.',
    sections: ['Physics', 'Chemistry', 'Mathematics'],
    subjectOrder: ['Physics', 'Chemistry', 'Mathematics'],
    isLockedByFaculty: false,
    isScheduled: false,
    isPublished: true,
    createdAt: '2026-03-15T09:00:00Z',
    questions: [
      {
        id: 'q-jee-adv-p1',
        section: 'Physics',
        type: 'mcq',
        text: 'A glass prism with refracting angle A = 60° produces an angle of minimum deviation δm = 30° in air. What is the refractive index (μ) of the glass prism material?',
        imageUrl: DIAGRAM_OPTICS,
        options: [
          { key: 'A', text: '√2 ≈ 1.414' },
          { key: 'B', text: '1.500' },
          { key: 'C', text: '√3 ≈ 1.732' },
          { key: 'D', text: '4/3 ≈ 1.333' },
        ],
        correctAnswer: 'A',
        positiveMarks: 4,
        negativeMarks: 1,
        explanation:
          'By the prism formula: μ = sin((A + δm)/2) / sin(A/2). Here A = 60°, δm = 30°. Therefore μ = sin(90°/2) / sin(60°/2) = sin(45°) / sin(30°) = (1/√2) / (1/2) = 2/√2 = √2 ≈ 1.414. Hence Option A is correct.',
      },
      {
        id: 'q-jee-adv-p2',
        section: 'Physics',
        type: 'numerical',
        text: 'In the given Wheatstone bridge network, galvanometer current Ig is zero (null condition). If P = 4 Ω, Q = 8 Ω, and R = 6 Ω, calculate the value of unknown resistance S (in Ohms).',
        imageUrl: DIAGRAM_CIRCUIT,
        options: [],
        correctAnswer: '12',
        positiveMarks: 4,
        negativeMarks: 0,
        explanation:
          'For a balanced Wheatstone bridge with zero galvanometer deflection: P / Q = R / S. Thus S = (Q * R) / P = (8 * 6) / 4 = 48 / 4 = 12 Ω.',
      },
      {
        id: 'q-jee-adv-p3',
        section: 'Physics',
        type: 'mcq',
        text: 'A particle moves along x-axis such that its position is given by x(t) = 2t³ - 9t² + 12t + 5 (in meters). At what time t (in seconds, for t > 0) does the particle momentarily come to rest?',
        options: [
          { key: 'A', text: 't = 1 s and t = 2 s' },
          { key: 'B', text: 't = 3 s only' },
          { key: 'C', text: 't = 1.5 s only' },
          { key: 'D', text: 't = 2 s and t = 4 s' },
        ],
        correctAnswer: 'A',
        positiveMarks: 4,
        negativeMarks: 1,
        explanation:
          'Velocity v(t) = dx/dt = 6t² - 18t + 12. For particle to come to rest, v(t) = 0 => 6(t² - 3t + 2) = 0 => 6(t - 1)(t - 2) = 0. Therefore t = 1 s and t = 2 s.',
      },
      {
        id: 'q-jee-adv-c1',
        section: 'Chemistry',
        type: 'mcq',
        text: 'Which of the following complex ions has the highest magnetic moment (in Bohr Magnetons) based on crystal field theory?',
        options: [
          { key: 'A', text: '[Fe(H₂O)₆]²⁺ (High spin d⁶)' },
          { key: 'B', text: '[Fe(CN)₆]³⁻ (Low spin d⁵)' },
          { key: 'C', text: '[Ni(CO)₄] (d¹⁰)' },
          { key: 'D', text: '[Co(NH₃)₆]³⁺ (Low spin d⁶)' },
        ],
        correctAnswer: 'A',
        positiveMarks: 4,
        negativeMarks: 1,
        explanation:
          '[Fe(H₂O)₆]²⁺ has Fe²⁺ (3d⁶). H₂O is a weak field ligand, so high spin config t₂g⁴ eg² gives n = 4 unpaired electrons. Magnetic moment μ = √(4*(4+2)) = √24 ≈ 4.9 BM, which is the highest.',
      },
      {
        id: 'q-jee-adv-c2',
        section: 'Chemistry',
        type: 'mcq',
        text: 'In the Cannizzaro reaction, benzaldehyde undergoes simultaneous oxidation and reduction in the presence of concentrated NaOH. The products obtained are:',
        options: [
          { key: 'A', text: 'Benzyl alcohol and Sodium benzoate' },
          { key: 'B', text: 'Benzophenone and Benzoic acid' },
          { key: 'C', text: 'Toluene and Phenol' },
          { key: 'D', text: 'Acetophenone and Benzyl alcohol' },
        ],
        correctAnswer: 'A',
        positiveMarks: 4,
        negativeMarks: 1,
        explanation:
          '2 C₆H₅CHO + conc. NaOH → C₆H₅CH₂OH (Benzyl alcohol) + C₆H₅COONa (Sodium benzoate). This is the classic disproportionation without α-hydrogens.',
      },
      {
        id: 'q-jee-adv-c3',
        section: 'Chemistry',
        type: 'numerical',
        text: 'For a first-order chemical reaction, the half-life is 20 minutes. What percentage of the initial reactant will remain unreacted after 60 minutes? (Enter integer value)',
        options: [],
        correctAnswer: '12.5',
        positiveMarks: 4,
        negativeMarks: 0,
        explanation:
          'Number of half lives n = 60 / 20 = 3. Remaining amount = (1/2)³ = 1/8 of initial = 12.5%.',
      },
      {
        id: 'q-jee-adv-m1',
        section: 'Mathematics',
        type: 'mcq',
        text: 'Evaluate the definite integral: I = ∫ [from 0 to π/2] (sin³(x) / (sin³(x) + cos³(x))) dx.',
        options: [
          { key: 'A', text: 'π/4' },
          { key: 'B', text: 'π/2' },
          { key: 'C', text: 'π' },
          { key: 'D', text: '1' },
        ],
        correctAnswer: 'A',
        positiveMarks: 4,
        negativeMarks: 1,
        explanation:
          'Using the King’s property ∫ [0 to a] f(x) dx = ∫ [0 to a] f(a - x) dx: 2I = ∫ [0 to π/2] 1 dx = π/2 => I = π/4.',
      },
      {
        id: 'q-jee-adv-m2',
        section: 'Mathematics',
        type: 'mcq',
        text: 'The angle between vectors a = 2i + 2j - k and b = 6i - 3j + 2k is equal to:',
        options: [
          { key: 'A', text: 'cos⁻¹(4/21)' },
          { key: 'B', text: 'cos⁻¹(8/21)' },
          { key: 'C', text: 'cos⁻¹(2/7)' },
          { key: 'D', text: 'π/2' },
        ],
        correctAnswer: 'A',
        positiveMarks: 4,
        negativeMarks: 1,
        explanation:
          'a · b = (2)(6) + (2)(-3) + (-1)(2) = 12 - 6 - 2 = 4. |a| = √(4+4+1) = 3. |b| = √(36+9+4) = 7. cos(θ) = (a · b) / (|a||b|) = 4 / 21. Hence θ = cos⁻¹(4/21).',
      },
      {
        id: 'q-jee-adv-m3',
        section: 'Mathematics',
        type: 'numerical',
        text: 'Find the slope of tangent to the parabola y² = 16x at the point (1, 4).',
        options: [],
        correctAnswer: '2',
        positiveMarks: 4,
        negativeMarks: 0,
        explanation:
          'Differentiating y² = 16x implicitly: 2y (dy/dx) = 16 => dy/dx = 8 / y. At y = 4, dy/dx = 8 / 4 = 2.',
      },
    ],
  },
  {
    id: 'test-neet-phys-201',
    seriesId: 'series-neet-weekly-phys',
    title: 'NEET Physics Weekly Test 03: Ray Optics & Current Electricity',
    examType: 'NEET',
    durationMinutes: 45,
    totalMarks: 24,
    description:
      'High-yield NEET target test with NCERT based concept testing on refraction, optical instruments, Kirchhoff laws, and potentiometers.',
    sections: ['Physics'],
    subjectOrder: ['Physics'],
    isLockedByFaculty: false,
    isScheduled: false,
    isPublished: true,
    createdAt: '2026-03-20T11:00:00Z',
    questions: [
      {
        id: 'q-neet-p1',
        section: 'Physics',
        type: 'mcq',
        text: 'The focal length of a convex lens in air is 20 cm. If the lens is immersed in water (μ_water = 4/3, μ_glass = 3/2), its focal length in water becomes:',
        options: [
          { key: 'A', text: '80 cm' },
          { key: 'B', text: '40 cm' },
          { key: 'C', text: '60 cm' },
          { key: 'D', text: '20 cm' },
        ],
        correctAnswer: 'A',
        positiveMarks: 4,
        negativeMarks: 1,
        explanation:
          'By Lens Maker’s formula: 1/f_air = (1.5 - 1)(1/R1 - 1/R2) = 0.5 K. In water: 1/f_w = ((1.5/(4/3)) - 1) K = (9/8 - 1) K = (1/8) K. Therefore f_w / f_air = 0.5 / (1/8) = 4. Hence f_w = 4 * 20 = 80 cm.',
      },
      {
        id: 'q-neet-p2',
        section: 'Physics',
        type: 'mcq',
        text: 'In the provided Wheatstone bridge circuit diagram, what condition must be satisfied across opposite arms for null deflection in galvanometer?',
        imageUrl: DIAGRAM_CIRCUIT,
        options: [
          { key: 'A', text: 'P / Q = R / S' },
          { key: 'B', text: 'P * Q = R * S' },
          { key: 'C', text: 'P + Q = R + S' },
          { key: 'D', text: 'P / R = S / Q' },
        ],
        correctAnswer: 'A',
        positiveMarks: 4,
        negativeMarks: 1,
        explanation:
          'The fundamental balance condition of a Wheatstone bridge is P/Q = R/S, resulting in equal potential at bridge nodes and zero current through the galvanometer.',
      },
      {
        id: 'q-neet-p3',
        section: 'Physics',
        type: 'mcq',
        text: 'A wire of resistance 16 Ω is stretched uniformly to double its original length. The new resistance of the wire will be:',
        options: [
          { key: 'A', text: '64 Ω' },
          { key: 'B', text: '32 Ω' },
          { key: 'C', text: '16 Ω' },
          { key: 'D', text: '8 Ω' },
        ],
        correctAnswer: 'A',
        positiveMarks: 4,
        negativeMarks: 1,
        explanation:
          'Since volume remains constant (V = A * L), when length doubles (L’ = 2L), area halves (A’ = A/2). Resistance R’ = ρ (2L)/(A/2) = 4 * (ρL/A) = 4 * 16 = 64 Ω.',
      },
      {
        id: 'q-neet-p4',
        section: 'Physics',
        type: 'mcq',
        text: 'A prism has an angle A = 60° and produces minimum deviation δm = 30° as shown. Determine the angle of incidence i.',
        imageUrl: DIAGRAM_OPTICS,
        options: [
          { key: 'A', text: '45°' },
          { key: 'B', text: '60°' },
          { key: 'C', text: '30°' },
          { key: 'D', text: '75°' },
        ],
        correctAnswer: 'A',
        positiveMarks: 4,
        negativeMarks: 1,
        explanation:
          'At minimum deviation: i = (A + δm) / 2 = (60° + 30°) / 2 = 90° / 2 = 45°.',
      },
      {
        id: 'q-neet-p5',
        section: 'Physics',
        type: 'mcq',
        text: 'Kirchhoff’s First Law (Junction Rule) is a consequence of conservation of:',
        options: [
          { key: 'A', text: 'Electric Charge' },
          { key: 'B', text: 'Energy' },
          { key: 'C', text: 'Linear Momentum' },
          { key: 'D', text: 'Angular Momentum' },
        ],
        correctAnswer: 'A',
        positiveMarks: 4,
        negativeMarks: 1,
        explanation:
          'Kirchhoff’s junction rule (∑ I = 0) is based on conservation of electric charge, while loop rule is based on conservation of energy.',
      },
      {
        id: 'q-neet-p6',
        section: 'Physics',
        type: 'mcq',
        text: 'The de-Broglie wavelength of an electron accelerated through a potential difference of 100 Volts is approximately:',
        options: [
          { key: 'A', text: '1.227 Å' },
          { key: 'B', text: '0.123 Å' },
          { key: 'C', text: '12.27 Å' },
          { key: 'D', text: '0.012 Å' },
        ],
        correctAnswer: 'A',
        positiveMarks: 4,
        negativeMarks: 1,
        explanation:
          'λ = 12.27 / √V Å = 12.27 / √100 = 12.27 / 10 = 1.227 Å (0.1227 nm).',
      },
    ],
  },
  {
    id: 'test-jee-main-free-01',
    seriesId: 'series-jee-main-free',
    title: 'JEE Main 2026 Free Diagnostic All-India Mock 01',
    examType: 'JEE Main',
    durationMinutes: 45,
    totalMarks: 24,
    description:
      'National open diagnostic test with high-precision percentile estimation and instant answer key validation.',
    sections: ['Physics', 'Chemistry', 'Mathematics'],
    subjectOrder: ['Mathematics', 'Physics', 'Chemistry'],
    isLockedByFaculty: false,
    isScheduled: false,
    isPublished: true,
    createdAt: '2026-03-22T10:00:00Z',
    questions: [
      {
        id: 'q-jm-p1',
        section: 'Physics',
        type: 'mcq',
        text: 'A body of mass 2 kg is dropped from a height of 20 m above ground. What is its kinetic energy just before hitting the ground? (Take g = 10 m/s²)',
        options: [
          { key: 'A', text: '400 Joules' },
          { key: 'B', text: '200 Joules' },
          { key: 'C', text: '800 Joules' },
          { key: 'D', text: '100 Joules' },
        ],
        correctAnswer: 'A',
        positiveMarks: 4,
        negativeMarks: 1,
        explanation:
          'By conservation of mechanical energy: KE = Potential Energy = m * g * h = 2 * 10 * 20 = 400 J.',
      },
      {
        id: 'q-jm-p2',
        section: 'Physics',
        type: 'mcq',
        text: 'Two identical spheres carrying charges +10 μC and -6 μC are brought into contact and separated to the same distance. The new force between them will be:',
        options: [
          { key: 'A', text: 'Repulsive' },
          { key: 'B', text: 'Attractive' },
          { key: 'C', text: 'Zero' },
          { key: 'D', text: 'Infinite' },
        ],
        correctAnswer: 'A',
        positiveMarks: 4,
        negativeMarks: 1,
        explanation:
          'Upon contact, total charge (+10 - 6 = +4 μC) divides equally into +2 μC on each sphere. Since both charges are now positive (+2 μC and +2 μC), they exert a repulsive electrostatic force.',
      },
      {
        id: 'q-jm-c1',
        section: 'Chemistry',
        type: 'mcq',
        text: 'Which one among the following has the highest electronegativity according to the Pauling scale?',
        options: [
          { key: 'A', text: 'Fluorine (F)' },
          { key: 'B', text: 'Oxygen (O)' },
          { key: 'C', text: 'Chlorine (Cl)' },
          { key: 'D', text: 'Nitrogen (N)' },
        ],
        correctAnswer: 'A',
        positiveMarks: 4,
        negativeMarks: 1,
        explanation:
          'Fluorine is the most electronegative element in the periodic table with a Pauling value of 4.0.',
      },
      {
        id: 'q-jm-c2',
        section: 'Chemistry',
        type: 'numerical',
        text: 'How many moles of helium gas occupy a volume of 44.8 Liters at Standard Temperature and Pressure (STP)?',
        options: [],
        correctAnswer: '2',
        positiveMarks: 4,
        negativeMarks: 0,
        explanation:
          'At STP, 1 mole of any ideal gas occupies 22.4 L. Moles = 44.8 / 22.4 = 2 moles.',
      },
      {
        id: 'q-jm-m1',
        section: 'Mathematics',
        type: 'mcq',
        text: 'If matrix A has order 3x3 and det(A) = 5, then the value of det(2A) is:',
        options: [
          { key: 'A', text: '40' },
          { key: 'B', text: '10' },
          { key: 'C', text: '25' },
          { key: 'D', text: '125' },
        ],
        correctAnswer: 'A',
        positiveMarks: 4,
        negativeMarks: 1,
        explanation:
          'For an n x n matrix: det(k*A) = k^n * det(A). Here n = 3 and k = 2, so det(2A) = 2³ * 5 = 8 * 5 = 40.',
      },
      {
        id: 'q-jm-m2',
        section: 'Mathematics',
        type: 'mcq',
        text: 'Find the limit as x approaches 0 of (sin(5x) / x):',
        options: [
          { key: 'A', text: '5' },
          { key: 'B', text: '1' },
          { key: 'C', text: '0' },
          { key: 'D', text: 'Does not exist' },
        ],
        correctAnswer: 'A',
        positiveMarks: 4,
        negativeMarks: 1,
        explanation:
          'lim [x->0] (sin(5x)/x) = 5 * lim [x->0] (sin(5x)/5x) = 5 * 1 = 5.',
      },
    ],
  },
  {
    id: 'test-neet-bio-301',
    seriesId: 'series-neet-bio-360',
    title: 'NEET Biology 360 Sprint Test 01: Genetics & Molecular Basis',
    examType: 'NEET',
    durationMinutes: 40,
    totalMarks: 20,
    description:
      'Pedigree charts, Mendel’s laws, Central Dogma, and gene regulation tested through high-probability NEET questions.',
    sections: ['Biology'],
    isPublished: true,
    createdAt: '2026-03-24T12:00:00Z',
    questions: [
      {
        id: 'q-bio-g1',
        section: 'Biology',
        type: 'mcq',
        text: 'Examine the pedigree chart shown below. What is the most probable pattern of inheritance exhibited by this family tree?',
        imageUrl: DIAGRAM_GENETICS,
        options: [
          { key: 'A', text: 'Autosomal Recessive (e.g., Cystic fibrosis, Sickle cell anemia)' },
          { key: 'B', text: 'Autosomal Dominant (e.g., Huntington disease)' },
          { key: 'C', text: 'Y-linked Inheritance' },
          { key: 'D', text: 'Mitochondrial Cytoplasmic Inheritance' },
        ],
        correctAnswer: 'A',
        positiveMarks: 4,
        negativeMarks: 1,
        explanation:
          'In this pedigree, two unaffected parents produce an affected female offspring. This skip of generation is characteristic of an Autosomal Recessive trait where both parents are heterozygous carriers (Aa x Aa → aa).',
      },
      {
        id: 'q-bio-g2',
        section: 'Biology',
        type: 'mcq',
        text: 'During protein translation in prokaryotes, which codon serves as the universal initiation codon coding for Methionine?',
        options: [
          { key: 'A', text: 'AUG' },
          { key: 'B', text: 'UAA' },
          { key: 'C', text: 'UAG' },
          { key: 'D', text: 'UGA' },
        ],
        correctAnswer: 'A',
        positiveMarks: 4,
        negativeMarks: 1,
        explanation:
          'AUG has dual function: it acts as the initiation codon and codes for Methionine (Formyl-methionine in prokaryotes). UAA, UAG, and UGA are stop codons.',
      },
      {
        id: 'q-bio-g3',
        section: 'Biology',
        type: 'mcq',
        text: 'In the lac operon of E. coli, the repressor protein binds specifically to which region to inhibit transcription?',
        options: [
          { key: 'A', text: 'Operator region (O)' },
          { key: 'B', text: 'Promoter region (P)' },
          { key: 'C', text: 'Structural gene Z' },
          { key: 'D', text: 'Terminator gene' },
        ],
        correctAnswer: 'A',
        positiveMarks: 4,
        negativeMarks: 1,
        explanation:
          'The lac repressor protein synthesized by the i gene binds to the operator region (O), preventing RNA polymerase from transcribing the operon.',
      },
      {
        id: 'q-bio-g4',
        section: 'Biology',
        type: 'mcq',
        text: 'According to Chargaff’s rule for double-stranded DNA, if Adenine constitutes 30% of the nitrogenous bases, the percentage of Cytosine is:',
        options: [
          { key: 'A', text: '20%' },
          { key: 'B', text: '30%' },
          { key: 'C', text: '40%' },
          { key: 'D', text: '15%' },
        ],
        correctAnswer: 'A',
        positiveMarks: 4,
        negativeMarks: 1,
        explanation:
          'A = T = 30%. Thus (A + T) = 60%. Remaining G + C = 100% - 60% = 40%. Since G = C, Cytosine = 40% / 2 = 20%.',
      },
      {
        id: 'q-bio-g5',
        section: 'Biology',
        type: 'mcq',
        text: 'Which cellular organelle is known as the "protein factory" of the eukaryotic cell?',
        options: [
          { key: 'A', text: 'Ribosome' },
          { key: 'B', text: 'Golgi Apparatus' },
          { key: 'C', text: 'Lysosome' },
          { key: 'D', text: 'Centrosome' },
        ],
        correctAnswer: 'A',
        positiveMarks: 4,
        negativeMarks: 1,
        explanation:
          'Ribosomes facilitate mRNA translation into polypeptide chains and are called the protein factories of the cell.',
      },
    ],
  },
];

export const INITIAL_STUDENT_ATTEMPTS: StudentTestAttempt[] = [
  {
    id: 'attempt-demo-1',
    testId: 'test-jee-adv-101',
    testTitle: 'JEE Advanced Apex Mock Test 01 - Paper 1',
    seriesId: 'series-jee-adv-2026',
    studentId: 'student-aryan-01',
    studentName: 'Aryan Sharma',
    studentRoll: 'ARG-JEE-2026-042',
    submittedAt: '2026-03-25T14:32:00Z',
    timeSpentSeconds: 2420,
    score: 30,
    maxScore: 36,
    correctCount: 8,
    incorrectCount: 1,
    unattemptedCount: 0,
    accuracy: 89,
    percentile: 98.4,
    responses: {
      'q-jee-adv-p1': { selectedOption: 'A', state: 'answered', timeSpentSeconds: 180 },
      'q-jee-adv-p2': { selectedOption: '12', state: 'answered', timeSpentSeconds: 150 },
      'q-jee-adv-p3': { selectedOption: 'A', state: 'answered', timeSpentSeconds: 210 },
      'q-jee-adv-c1': { selectedOption: 'A', state: 'answered', timeSpentSeconds: 90 },
      'q-jee-adv-c2': { selectedOption: 'A', state: 'answered', timeSpentSeconds: 75 },
      'q-jee-adv-c3': { selectedOption: '12.5', state: 'answered_and_marked', timeSpentSeconds: 140 },
      'q-jee-adv-m1': { selectedOption: 'A', state: 'answered', timeSpentSeconds: 260 },
      'q-jee-adv-m2': { selectedOption: 'B', state: 'answered', timeSpentSeconds: 300 }, // wrong
      'q-jee-adv-m3': { selectedOption: '2', state: 'answered', timeSpentSeconds: 180 },
    },
    sectionScores: {
      Physics: { score: 12, maxScore: 12, correct: 3, incorrect: 0, unattempted: 0 },
      Chemistry: { score: 12, maxScore: 12, correct: 3, incorrect: 0, unattempted: 0 },
      Mathematics: { score: 6, maxScore: 12, correct: 2, incorrect: 1, unattempted: 0 },
      Biology: { score: 0, maxScore: 0, correct: 0, incorrect: 0, unattempted: 0 },
    },
  },
  {
    id: 'attempt-demo-2',
    testId: 'test-neet-phys-201',
    testTitle: 'NEET Physics Weekly Test 03: Ray Optics & Current Electricity',
    seriesId: 'series-neet-weekly-phys',
    studentId: 'student-priya-02',
    studentName: 'Priya Patel',
    studentRoll: 'ARG-NEET-2026-108',
    submittedAt: '2026-03-26T16:15:00Z',
    timeSpentSeconds: 1850,
    score: 20,
    maxScore: 24,
    correctCount: 5,
    incorrectCount: 1,
    unattemptedCount: 0,
    accuracy: 83,
    percentile: 96.2,
    responses: {
      'q-neet-p1': { selectedOption: 'A', state: 'answered', timeSpentSeconds: 240 },
      'q-neet-p2': { selectedOption: 'A', state: 'answered', timeSpentSeconds: 120 },
      'q-neet-p3': { selectedOption: 'A', state: 'answered', timeSpentSeconds: 180 },
      'q-neet-p4': { selectedOption: 'A', state: 'answered', timeSpentSeconds: 150 },
      'q-neet-p5': { selectedOption: 'A', state: 'answered', timeSpentSeconds: 90 },
      'q-neet-p6': { selectedOption: 'B', state: 'answered', timeSpentSeconds: 160 }, // wrong
    },
    sectionScores: {
      Physics: { score: 20, maxScore: 24, correct: 5, incorrect: 1, unattempted: 0 },
      Chemistry: { score: 0, maxScore: 0, correct: 0, incorrect: 0, unattempted: 0 },
      Mathematics: { score: 0, maxScore: 0, correct: 0, incorrect: 0, unattempted: 0 },
      Biology: { score: 0, maxScore: 0, correct: 0, incorrect: 0, unattempted: 0 },
    },
  },
];

export const DEMO_STUDENT_USERS: User[] = [
  {
    id: 'student-aryan-01',
    name: 'Aryan Sharma',
    email: 'aryan.sharma@argon.edu',
    phone: '+91 98290 12345',
    role: 'student',
    rollNo: 'ARG-JEE-2026-042',
    targetExam: 'JEE Advanced',
    avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=150&q=80',
    enrolledSeriesIds: ['series-jee-adv-2026', 'series-jee-main-free'],
    registeredAt: '2026-01-10T10:00:00Z',
  },
  {
    id: 'student-priya-02',
    name: 'Priya Patel',
    email: 'priya.patel@argon.edu',
    phone: '+91 94140 67890',
    role: 'student',
    rollNo: 'ARG-NEET-2026-108',
    targetExam: 'NEET',
    avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=150&q=80',
    enrolledSeriesIds: ['series-neet-weekly-phys', 'series-neet-bio-360', 'series-jee-main-free'],
    registeredAt: '2026-01-12T11:30:00Z',
  },
];

export const FACULTY_USER: User = {
  id: 'faculty-hpd-01',
  name: 'Dr. H. P. Deshmukh',
  email: 'faculty@argon.edu',
  role: 'faculty',
  avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=150&q=80',
  enrolledSeriesIds: [],
};

export const INITIAL_VERIFICATION_REQUESTS: PaymentVerificationRequest[] = [
  {
    id: 'req-verify-101',
    studentId: 'student-aryan-01',
    studentName: 'Aryan Sharma',
    studentRoll: 'ARG-JEE-2026-042',
    studentPhone: '+91 98290 12345',
    seriesId: 'series-jee-adv-2026',
    seriesTitle: 'JEE Advanced Apex All-India Mock Series 2026',
    seriesPrice: 999,
    upiTxnId: 'UPI-REF-409823451299',
    requestedAt: new Date(Date.now() - 3600000 * 3).toISOString(),
    status: 'pending',
  },
  {
    id: 'req-verify-102',
    studentId: 'student-priya-02',
    studentName: 'Priya Patel',
    studentRoll: 'ARG-NEET-2026-108',
    studentPhone: '+91 94140 67890',
    seriesId: 'series-neet-weekly-phys',
    seriesTitle: 'NEET Physics Weekly Mastery Series',
    seriesPrice: 499,
    upiTxnId: 'GPAY-UTR-8912347101',
    requestedAt: new Date(Date.now() - 3600000 * 20).toISOString(),
    status: 'approved',
    reviewedAt: new Date(Date.now() - 3600000 * 18).toISOString(),
    reviewedBy: 'Admin / Faculty',
  },
];

export const INITIAL_NOTICES: Notice[] = [
  {
    id: 'notice-1',
    title: 'NTA JEE Main 2026 Shift-1 CBT Mock Examination Schedule',
    content: 'All enrolled JEE aspirants must report to their respective CBT portals 15 minutes before the scheduled time. Ensure stable internet and clear browser cache.',
    targetExam: 'JEE Main',
    priority: 'urgent',
    createdAt: new Date(Date.now() - 3600000 * 2).toISOString(),
    author: 'Dr. H. P. Deshmukh (Academic Director)',
  },
  {
    id: 'notice-2',
    title: 'NEET-UG 2026 High-Yield NCERT Biology Mock Discussion',
    content: 'Live question-by-question analysis of NCERT line-by-line traps will be held this Sunday at 5:00 PM on the institute portal.',
    targetExam: 'NEET',
    priority: 'normal',
    createdAt: new Date(Date.now() - 3600000 * 12).toISOString(),
    author: 'Prof. Ananya Sen (HOD Biology)',
  },
];

export const INITIAL_MATERIALS: StudyMaterial[] = [
  {
    id: 'res-jee-phys',
    category: 'JEE',
    type: 'PDF Formula Sheet',
    title: 'Complete JEE Physics Formula Handbook & Derivations',
    description: 'Comprehensive 42-page handbook covering all mechanics, optics, thermodynamics, and electrodynamics equations with high-yield shortcut tricks.',
    size: '4.8 MB',
    isHot: true,
    uploadedAt: new Date(Date.now() - 3600000 * 24 * 5).toISOString(),
  },
  {
    id: 'res-neet-bio',
    category: 'NEET',
    type: 'NCERT Mindmap',
    title: 'NCERT Line-by-Line Biology High-Yield Mindmaps (Class 11 & 12)',
    description: 'Visual flowcharts of Human Physiology, Genetics & Evolution, Biotechnology, and Ecology highlighting common NTA trap statements.',
    size: '8.2 MB',
    isHot: true,
    uploadedAt: new Date(Date.now() - 3600000 * 24 * 4).toISOString(),
  },
  {
    id: 'res-chem-rxn',
    category: 'FORMULAS',
    type: 'Reaction Roadmap',
    title: 'Complete Organic Chemistry Reaction Mechanisms & Name Reactions',
    description: 'All Named Reactions from Aldehydes, Ketones, Amines, and Hydrocarbons with reagents, catalysts, and stereochemistry notes.',
    size: '3.6 MB',
    isHot: false,
    uploadedAt: new Date(Date.now() - 3600000 * 24 * 3).toISOString(),
  },
  {
    id: 'res-jee-maths',
    category: 'JEE',
    type: 'Calculus Cheat Sheet',
    title: 'JEE Advanced Calculus & Coordinate Geometry Short Notes',
    description: 'Definite integration properties, standard area under curves, tangent equations, conic section locus formulas formulated by Prof. Bhattacharya.',
    size: '2.9 MB',
    isHot: false,
    uploadedAt: new Date(Date.now() - 3600000 * 24 * 2).toISOString(),
  },
];

export const INITIAL_FACULTY_PROFILES: FacultyProfile[] = [
  {
    id: 'faculty-manish-saha',
    name: 'Er. Manish Saha',
    role: 'Head of Physics & Academic Director',
    department: 'Physics',
    qualification: 'B.Tech - IIT Guwahati | 12+ Yrs Experience',
    avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=400&q=80',
    bio: 'Renowned for simplifying mechanics, electrodynamics, and modern physics through visual models and intuitive physical analogies. Has guided 450+ students into top IITs and NITs with personal doubt clearance.',
    subjects: ['Mechanics & Rotational Dynamics', 'Electromagnetism & Optics', 'Thermodynamics & Modern Physics'],
    trackRecord: 'Mentored AIR 142 (JEE Adv 2024), AIR 289 (JEE Main)',
    quote: '"Physics is not a formula memorization game; it is learning how the universe speaks in mathematical harmony."',
    email: 'sahamanish16921@gmail.com',
    phone: '+91 60007 30250',
    availableTimings: 'Mon - Sat: 9:00 AM - 7:00 PM (Guwahati Center)',
    updatedAt: new Date().toISOString(),
  },
  {
    id: 'faculty-rk-barman',
    name: 'Dr. R. K. Barman',
    role: 'Head of Chemistry (Physical & Inorganic)',
    department: 'Chemistry',
    qualification: 'Ph.D. in Chemical Sciences | Ex-Senior Faculty Kota | 15+ Yrs',
    avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=400&q=80',
    bio: 'Former senior chemistry faculty at top Kota national institutes. Expert in reaction mechanisms, coordination chemistry, and rapid shortcut calculation methods for physical chemistry in NTA tests.',
    subjects: ['Chemical Equilibrium & Kinetics', 'Coordination Chemistry', 'Organic Reaction Mechanisms'],
    trackRecord: 'Produced 100/100 percentile in JEE Main Chemistry 3 consecutive years',
    quote: '"If you master the periodic table and thermodynamics fundamentals, 90% of competitive chemistry solves itself."',
    email: 'rk.barman@argon.edu',
    phone: '+91 94350 12345',
    availableTimings: 'Mon - Fri: 10:00 AM - 5:30 PM',
    updatedAt: new Date().toISOString(),
  },
  {
    id: 'faculty-a-bhattacharya',
    name: 'Prof. A. Bhattacharya',
    role: 'Senior Faculty - Mathematics',
    department: 'Mathematics',
    qualification: 'M.Sc. Mathematics (Gold Medalist) | ISI Kolkata Mentor | 14+ Yrs',
    avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=400&q=80',
    bio: 'Master of calculus, coordinate geometry, and algebraic proofs. Renowned for breaking down fearsome JEE Advanced multi-correct problems into digestible 3-step algorithms with zero panic.',
    subjects: ['Integral & Differential Calculus', 'Coordinate Geometry', 'Vectors & 3D Geometry'],
    trackRecord: 'Trained over 85 students scoring 99.5+ percentile in JEE Mathematics',
    quote: '"In mathematics, speed comes naturally when your geometrical intuition and conceptual clarity are flawless."',
    email: 'a.bhattacharya@argon.edu',
    phone: '+91 98640 67890',
    availableTimings: 'Tue - Sun: 11:00 AM - 6:30 PM',
    updatedAt: new Date().toISOString(),
  },
  {
    id: 'faculty-snigdha-devi',
    name: 'Dr. Snigdha Devi',
    role: 'Head of Biology & Medical Mentorship',
    department: 'Biology',
    qualification: 'MBBS - AIIMS New Delhi Alumni | 10+ Yrs NEET Mentorship',
    avatar: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&w=400&q=80',
    bio: 'Pioneered the NCERT Line-by-Line Micro-Analysis method for NEET biology. Her students consistently score 340+ out of 360 in the biology section of NEET-UG.',
    subjects: ['Human Physiology & Genetics', 'Cell Biology & Biotechnology', 'Plant Physiology & Ecology'],
    trackRecord: 'Over 120 students currently studying in Government Medical Colleges across India',
    quote: '"Every mark in NEET Biology is a gateway to your medical coat. We ensure zero ambiguity in NCERT interpretation."',
    email: 'snigdha.devi@argon.edu',
    phone: '+91 97060 45678',
    availableTimings: 'Mon - Sat: 8:30 AM - 4:00 PM',
    updatedAt: new Date().toISOString(),
  },
];

