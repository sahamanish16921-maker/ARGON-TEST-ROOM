import { createClient, RealtimeChannel } from '@supabase/supabase-js';

// Supabase configuration provided by the user
export const SUPABASE_URL = 'https://onqledavnwhhsrgbhazq.supabase.co';
export const SUPABASE_PUBLISHABLE_KEY = 'sb_publishable_KvBGP17_PGeJ3WRfnkhGjg_tcKYr-zi';
export const SUPABASE_JWKS_URL = 'https://onqledavnwhhsrgbhazq.supabase.co/auth/v1/.well-known/jwks.json';

// Initialize Supabase Client with Realtime Websockets enabled
export const supabase = createClient(SUPABASE_URL, SUPABASE_PUBLISHABLE_KEY, {
  auth: {
    persistSession: true,
    autoRefreshToken: true,
    detectSessionInUrl: true,
  },
  realtime: {
    params: {
      eventsPerSecond: 20,
    },
  },
});

export type SupabaseSyncEventType =
  | 'TEST_CREATED'
  | 'TEST_UPDATED'
  | 'TEST_DELETED'
  | 'SERIES_CREATED'
  | 'SERIES_UPDATED'
  | 'SERIES_DELETED'
  | 'UPI_UPDATED'
  | 'QUESTION_SAVED'
  | 'ATTEMPT_SUBMITTED'
  | 'FACULTY_UPDATED'
  | 'NOTICE_UPDATED'
  | 'MATERIAL_UPDATED'
  | 'FULL_STATE_SYNC';

export interface SupabaseBroadcastMessage {
  type: SupabaseSyncEventType;
  deviceId: string;
  timestamp: string;
  data: any;
}

let activeChannel: RealtimeChannel | null = null;
const listeners = new Set<(msg: SupabaseBroadcastMessage) => void>();

/**
 * Initializes and subscribes to the global Supabase Realtime broadcast channel.
 * Guarantees instantaneous (<50ms) push sync between Faculty and Student apps on Device A & B.
 */
export function initSupabaseRealtime(
  deviceId: string,
  onMessage: (msg: SupabaseBroadcastMessage) => void
): () => void {
  listeners.add(onMessage);

  if (!activeChannel) {
    activeChannel = supabase.channel('argon-live-realtime', {
      config: {
        broadcast: { ack: true, self: false },
      },
    });

    activeChannel
      .on('broadcast', { event: 'argon-event' }, (eventPayload) => {
        const payload = eventPayload.payload as SupabaseBroadcastMessage;
        if (!payload || payload.deviceId === deviceId) return; // Skip own echoes
        listeners.forEach((callback) => {
          try {
            callback(payload);
          } catch (err) {
            console.error('Error handling Supabase broadcast:', err);
          }
        });
      })
      .subscribe((status) => {
        if (status === 'SUBSCRIBED') {
          console.log('[Supabase Realtime] Connected & listening for live student/faculty updates');
        }
      });
  }

  return () => {
    listeners.delete(onMessage);
    if (listeners.size === 0 && activeChannel) {
      supabase.removeChannel(activeChannel);
      activeChannel = null;
    }
  };
}

/**
 * Broadcasts an instant change to all student and faculty devices over Supabase Realtime
 */
export async function broadcastViaSupabase(
  type: SupabaseSyncEventType,
  data: any,
  deviceId: string
): Promise<void> {
  if (!activeChannel) {
    activeChannel = supabase.channel('argon-live-realtime', {
      config: { broadcast: { ack: true, self: false } },
    });
    await activeChannel.subscribe();
  }

  const payload: SupabaseBroadcastMessage = {
    type,
    deviceId,
    timestamp: new Date().toISOString(),
    data,
  };

  try {
    await activeChannel.send({
      type: 'broadcast',
      event: 'argon-event',
      payload,
    });
  } catch (err) {
    console.warn('[Supabase Realtime] Broadcast failed:', err);
  }
}

/**
 * Test connectivity with Supabase project
 */
export async function testSupabaseConnection(): Promise<boolean> {
  try {
    const { error } = await supabase.auth.getSession();
    return !error;
  } catch {
    return false;
  }
}

/**
 * Graceful table upsert helpers:
 * If the user creates the tables in Supabase Dashboard, these persist to PostgreSQL tables directly.
 */
export async function supabaseUpsert(table: string, data: any): Promise<boolean> {
  try {
    const { error } = await supabase.from(table).upsert(data);
    if (error) {
      // Table may not yet be defined in Postgres schema cache
      return false;
    }
    return true;
  } catch {
    return false;
  }
}

/**
 * Fetch all rows from a Supabase table if table exists
 */
export async function supabaseFetchTable<T = any>(table: string): Promise<T[] | null> {
  try {
    const { data, error } = await supabase.from(table).select('*');
    if (error || !data) return null;
    return data as T[];
  } catch {
    return null;
  }
}

/**
 * Delete a row by ID from a Supabase table
 */
export async function supabaseDeleteRow(table: string, id: string): Promise<boolean> {
  try {
    const { error } = await supabase.from(table).delete().eq('id', id);
    return !error;
  } catch {
    return false;
  }
}

/**
 * Sign in with Google using Supabase Auth
 */
export async function loginWithGoogleViaSupabase() {
  try {
    const { data, error } = await supabase.auth.signInWithOAuth({
      provider: 'google',
      options: {
        redirectTo: typeof window !== 'undefined' ? window.location.origin : undefined,
      },
    });
    if (error) throw error;
    return data;
  } catch (err) {
    console.warn('Supabase Google OAuth initialization:', err);
    throw err;
  }
}

/**
 * Sign out of Supabase Auth
 */
export async function logoutUserViaSupabase() {
  try {
    const { error } = await supabase.auth.signOut();
    if (error) console.warn('Supabase signOut warning:', error);
  } catch (err) {
    console.warn('Supabase signOut exception:', err);
  }
}


