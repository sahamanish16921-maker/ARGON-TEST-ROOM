export type UserRole = 'guest' | 'faculty' | 'student';

export type WebsiteView =
  | 'home'
  | 'courses'
  | 'test-series'
  | 'faculty-mentors'
  | 'results'
  | 'admissions'
  | 'free-resources'
  | 'faculty-dashboard'
  | 'student-dashboard'
  | 'nta-exam'
  | 'result-view';

export type ExamType = 'JEE Main' | 'JEE Advanced' | 'NEET';

export type SubjectSection = 'Physics' | 'Chemistry' | 'Mathematics' | 'Biology';

export type QuestionType = 'mcq' | 'numerical';

export type OptionKey = 'A' | 'B' | 'C' | 'D';

export interface QuestionOption {
  key: OptionKey;
  text: string;
  imageUrl?: string;
}

export interface Question {
  id: string;
  section: SubjectSection;
  type: QuestionType;
  text: string;
  imageUrl?: string;
  options: QuestionOption[];
  correctAnswer: OptionKey | string;
  positiveMarks: number;
  negativeMarks: number;
  explanation: string;
  explanationImageUrl?: string;
}

export interface Test {
  id: string;
  seriesId: string;
  title: string;
  examType: ExamType;
  durationMinutes: number;
  totalMarks: number;
  description: string;
  sections: SubjectSection[];
  questions: Question[];
  createdAt: string;
  isPublished: boolean;
  // Scheduling & Lock controls set by faculty
  isLockedByFaculty?: boolean;
  subjectOrder?: SubjectSection[];
  isScheduled?: boolean;
  scheduledStartTime?: string;
  scheduledEndTime?: string;
}

export interface TestSeries {
  id: string;
  title: string;
  category: string;
  targetExam: ExamType;
  price: number;
  originalPrice?: number;
  description: string;
  features: string[];
  upiId: string;
  upiQrUrl?: string;
  paymentNote?: string;
  badge?: string;
  testsCount?: number;
  enrolledCount?: number;
  thumbnailUrl?: string;
}

export type QuestionState =
  | 'not_visited'
  | 'not_answered'
  | 'answered'
  | 'marked_for_review'
  | 'answered_and_marked';

export interface QuestionResponse {
  selectedOption?: string; // 'A' | 'B' | 'C' | 'D' or numerical string
  state: QuestionState;
  timeSpentSeconds: number;
}

export interface SectionScore {
  score: number;
  maxScore: number;
  correct: number;
  incorrect: number;
  unattempted: number;
}

export interface StudentTestAttempt {
  id: string;
  testId: string;
  testTitle: string;
  seriesId: string;
  studentId: string;
  studentName: string;
  studentRoll: string;
  submittedAt: string;
  timeSpentSeconds: number;
  responses: Record<string, QuestionResponse>;
  score: number;
  maxScore: number;
  correctCount: number;
  incorrectCount: number;
  unattemptedCount: number;
  accuracy: number;
  percentile: number;
  sectionScores: Record<SubjectSection, SectionScore>;
  autoSubmitted?: boolean;
}

export interface User {
  id: string;
  name: string;
  email: string;
  role: 'faculty' | 'student';
  rollNo?: string;
  phone?: string;
  targetExam?: ExamType;
  avatar?: string;
  enrolledSeriesIds: string[];
  registeredAt?: string;
}

export type VerificationStatus = 'pending' | 'approved' | 'rejected';

export interface PaymentVerificationRequest {
  id: string;
  studentId: string;
  studentName: string;
  studentRoll: string;
  studentPhone: string;
  seriesId: string;
  seriesTitle: string;
  seriesPrice: number;
  upiTxnId: string;
  requestedAt: string;
  status: VerificationStatus;
  reviewedAt?: string;
  reviewedBy?: string;
  rejectionReason?: string;
}

export interface Notice {
  id: string;
  title: string;
  content: string;
  targetExam?: ExamType | 'All';
  priority?: 'normal' | 'urgent';
  createdAt: string;
  author?: string;
}

export interface StudyMaterial {
  id: string;
  title: string;
  category: 'JEE' | 'NEET' | 'FORMULAS' | 'ALL';
  type: string;
  description: string;
  fileUrl?: string;
  size?: string;
  isHot?: boolean;
  uploadedAt: string;
}

export interface FacultyProfile {
  id: string;
  name: string;
  role: string;
  department: string;
  qualification: string;
  avatar: string;
  bio: string;
  subjects: string[];
  trackRecord: string;
  quote: string;
  email?: string;
  phone?: string;
  availableTimings?: string;
  updatedAt?: string;
}

