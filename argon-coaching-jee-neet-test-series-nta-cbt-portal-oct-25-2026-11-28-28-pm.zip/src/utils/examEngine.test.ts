import test from 'node:test';
import assert from 'node:assert/strict';
import {
  evaluateTest,
  countPaletteStates,
  parseBatchCsv,
  parseBatchJson,
} from './examEngine.ts';
import type { Question } from '../types/index.ts';

const mockQuestions: Question[] = [
  {
    id: 'q1',
    section: 'Physics',
    type: 'mcq',
    text: 'What is acceleration due to gravity on Earth?',
    options: [
      { key: 'A', text: '9.8 m/s²' },
      { key: 'B', text: '8.9 m/s²' },
      { key: 'C', text: '10.8 m/s²' },
      { key: 'D', text: '7.8 m/s²' },
    ],
    correctAnswer: 'A',
    positiveMarks: 4,
    negativeMarks: 1,
    explanation: 'Standard g = 9.8 m/s².',
  },
  {
    id: 'q2',
    section: 'Physics',
    type: 'mcq',
    text: 'SI unit of electric current is?',
    options: [
      { key: 'A', text: 'Volt' },
      { key: 'B', text: 'Ampere' },
      { key: 'C', text: 'Ohm' },
      { key: 'D', text: 'Watt' },
    ],
    correctAnswer: 'B',
    positiveMarks: 4,
    negativeMarks: 1,
    explanation: 'Ampere is the base SI unit.',
  },
  {
    id: 'q3',
    section: 'Chemistry',
    type: 'numerical',
    text: 'pH of pure water at 25°C is:',
    options: [],
    correctAnswer: '7',
    positiveMarks: 4,
    negativeMarks: 0,
    explanation: 'Kw = 10⁻¹⁴, so [H⁺] = 10⁻⁷, pH = 7.',
  },
];

test('evaluateTest correctly calculates scores for correct, wrong, and unattempted answers', () => {
  const responses = {
    q1: { selectedOption: 'A', state: 'answered' as const, timeSpentSeconds: 30 },
    q2: { selectedOption: 'C', state: 'answered' as const, timeSpentSeconds: 40 }, // wrong (-1)
    q3: { selectedOption: '', state: 'not_visited' as const, timeSpentSeconds: 0 }, // unattempted
  };

  const result = evaluateTest(mockQuestions, responses);

  assert.equal(result.maxScore, 12);
  assert.equal(result.correctCount, 1);
  assert.equal(result.incorrectCount, 1);
  assert.equal(result.unattemptedCount, 1);
  assert.equal(result.score, 3); // +4 - 1 = 3
  assert.equal(result.accuracy, 50);
});

test('evaluateTest awards marks for answered_and_marked status (official NTA rule)', () => {
  const responses = {
    q1: { selectedOption: 'A', state: 'answered_and_marked' as const, timeSpentSeconds: 25 },
    q2: { selectedOption: 'B', state: 'answered_and_marked' as const, timeSpentSeconds: 25 },
    q3: { selectedOption: '7', state: 'answered' as const, timeSpentSeconds: 15 },
  };

  const result = evaluateTest(mockQuestions, responses);

  assert.equal(result.score, 12);
  assert.equal(result.correctCount, 3);
  assert.equal(result.incorrectCount, 0);
  assert.equal(result.unattemptedCount, 0);
  assert.equal(result.accuracy, 100);
});

test('countPaletteStates properly aggregates question counts', () => {
  const responses = {
    q1: { selectedOption: 'A', state: 'answered' as const, timeSpentSeconds: 10 },
    q2: { selectedOption: '', state: 'marked_for_review' as const, timeSpentSeconds: 15 },
  };

  const counts = countPaletteStates(mockQuestions, responses);
  assert.equal(counts.answered, 1);
  assert.equal(counts.marked_for_review, 1);
  assert.equal(counts.not_visited, 1); // q3 was not in responses
});

test('parseBatchCsv parses formatted rows and returns valid questions', () => {
  const csv = `Section,Type,Question,ImageUrl,OptionA,OptionB,OptionC,OptionD,CorrectAnswer,PositiveMarks,NegativeMarks,Explanation
Physics,mcq,"Speed of light in vacuum?",,3e8 m/s,2e8 m/s,1.5e8 m/s,4e8 m/s,A,4,1,"c ≈ 3 * 10^8 m/s"
Chemistry,mcq,"Atomic number of Carbon?",,6,12,14,8,A,4,1,"Carbon has 6 protons."`;

  const { questions, errors } = parseBatchCsv(csv);
  assert.equal(errors.length, 0);
  assert.equal(questions.length, 2);
  assert.equal(questions[0].section, 'Physics');
  assert.equal(questions[0].correctAnswer, 'A');
  assert.equal(questions[1].section, 'Chemistry');
  assert.equal(questions[1].options[0].text, '6');
});

test('parseBatchJson validates question json structures', () => {
  const json = JSON.stringify({
    questions: [
      {
        section: 'Mathematics',
        type: 'mcq',
        text: 'Derivative of sin(x) is?',
        options: [
          { key: 'A', text: 'cos(x)' },
          { key: 'B', text: '-cos(x)' },
        ],
        correctAnswer: 'A',
      },
    ],
  });

  const { questions, errors } = parseBatchJson(json);
  assert.equal(errors.length, 0);
  assert.equal(questions.length, 1);
  assert.equal(questions[0].text, 'Derivative of sin(x) is?');
  assert.equal(questions[0].options.length, 2);
});
