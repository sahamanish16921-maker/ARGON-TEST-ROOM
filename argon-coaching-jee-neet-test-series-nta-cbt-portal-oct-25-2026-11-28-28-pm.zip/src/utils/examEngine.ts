import type {
  Question,
  QuestionResponse,
  QuestionState,
  SubjectSection,
  SectionScore,
  OptionKey,
  QuestionType,
} from '../types/index.ts';

export interface EvaluationResult {
  score: number;
  maxScore: number;
  correctCount: number;
  incorrectCount: number;
  unattemptedCount: number;
  accuracy: number;
  percentile: number;
  sectionScores: Record<SubjectSection, SectionScore>;
}

export function evaluateTest(
  questions: Question[],
  responses: Record<string, Partial<QuestionResponse>>
): EvaluationResult {
  let totalScore = 0;
  let maxScore = 0;
  let correctCount = 0;
  let incorrectCount = 0;
  let unattemptedCount = 0;

  const defaultSections: SubjectSection[] = [
    'Physics',
    'Chemistry',
    'Mathematics',
    'Biology',
  ];

  const sectionScores: Record<SubjectSection, SectionScore> = {
    Physics: { score: 0, maxScore: 0, correct: 0, incorrect: 0, unattempted: 0 },
    Chemistry: { score: 0, maxScore: 0, correct: 0, incorrect: 0, unattempted: 0 },
    Mathematics: { score: 0, maxScore: 0, correct: 0, incorrect: 0, unattempted: 0 },
    Biology: { score: 0, maxScore: 0, correct: 0, incorrect: 0, unattempted: 0 },
  };

  questions.forEach((q) => {
    const sec = q.section || 'Physics';
    const pos = typeof q.positiveMarks === 'number' ? q.positiveMarks : 4;
    const neg = typeof q.negativeMarks === 'number' ? Math.abs(q.negativeMarks) : 1;

    maxScore += pos;
    if (!sectionScores[sec]) {
      sectionScores[sec] = { score: 0, maxScore: 0, correct: 0, incorrect: 0, unattempted: 0 };
    }
    sectionScores[sec].maxScore += pos;

    const resp = responses[q.id];
    const isConsideredForEvaluation =
      resp &&
      (resp.state === 'answered' || resp.state === 'answered_and_marked') &&
      resp.selectedOption !== undefined &&
      resp.selectedOption !== '';

    if (!isConsideredForEvaluation) {
      unattemptedCount += 1;
      sectionScores[sec].unattempted += 1;
      return;
    }

    const studentAnswer = String(resp.selectedOption).trim().toUpperCase();
    const correctAnswer = String(q.correctAnswer).trim().toUpperCase();

    const isCorrect =
      q.type === 'numerical'
        ? Math.abs(parseFloat(studentAnswer) - parseFloat(correctAnswer)) < 0.01
        : studentAnswer === correctAnswer;

    if (isCorrect) {
      totalScore += pos;
      correctCount += 1;
      sectionScores[sec].score += pos;
      sectionScores[sec].correct += 1;
    } else {
      totalScore -= neg;
      incorrectCount += 1;
      sectionScores[sec].score -= neg;
      sectionScores[sec].incorrect += 1;
    }
  });

  const attemptedTotal = correctCount + incorrectCount;
  const accuracy = attemptedTotal > 0 ? Math.round((correctCount / attemptedTotal) * 100) : 0;

  // Estimated AIR Percentile formula based on historical JEE/NEET score distribution
  let percentile = 50.0;
  if (maxScore > 0) {
    const percentage = (totalScore / maxScore) * 100;
    if (percentage >= 85) percentile = 99.5;
    else if (percentage >= 70) percentile = 97.8;
    else if (percentage >= 55) percentile = 92.5;
    else if (percentage >= 40) percentile = 82.0;
    else if (percentage >= 25) percentile = 65.0;
    else if (percentage >= 10) percentile = 48.0;
    else percentile = Math.max(10.0, Math.round(percentage * 2));
  }

  return {
    score: totalScore,
    maxScore,
    correctCount,
    incorrectCount,
    unattemptedCount,
    accuracy,
    percentile,
    sectionScores,
  };
}

export function countPaletteStates(
  questions: Question[],
  responses: Record<string, Partial<QuestionResponse>>,
  filterSection?: SubjectSection
): Record<QuestionState, number> {
  const counts: Record<QuestionState, number> = {
    not_visited: 0,
    not_answered: 0,
    answered: 0,
    marked_for_review: 0,
    answered_and_marked: 0,
  };

  const filtered = filterSection
    ? questions.filter((q) => q.section === filterSection)
    : questions;

  filtered.forEach((q) => {
    const resp = responses[q.id];
    const state = resp?.state || 'not_visited';
    counts[state] = (counts[state] || 0) + 1;
  });

  return counts;
}

export function parseBatchCsv(csvText: string): {
  questions: Question[];
  errors: string[];
} {
  const questions: Question[] = [];
  const errors: string[] = [];

  const lines = csvText
    .split(/\r?\n/)
    .map((l) => l.trim())
    .filter((l) => l.length > 0);

  if (lines.length < 2) {
    return {
      questions: [],
      errors: ['CSV file is empty or missing data rows.'],
    };
  }

  // Row 0 is header.
  for (let i = 1; i < lines.length; i++) {
    const line = lines[i];
    // Simple CSV parser supporting quotes
    const cells: string[] = [];
    let currentCell = '';
    let insideQuotes = false;

    for (let charIndex = 0; charIndex < line.length; charIndex++) {
      const char = line[charIndex];
      if (char === '"') {
        insideQuotes = !insideQuotes;
      } else if (char === ',' && !insideQuotes) {
        cells.push(currentCell.trim());
        currentCell = '';
      } else {
        currentCell += char;
      }
    }
    cells.push(currentCell.trim());

    if (cells.length < 8) {
      errors.push(`Row ${i + 1}: Insufficient columns (expected at least 8).`);
      continue;
    }

    // Expected format:
    // [0]: Section (Physics/Chemistry/Mathematics/Biology)
    // [1]: Type (mcq/numerical)
    // [2]: Question Text
    // [3]: Image URL (optional)
    // [4]: Option A
    // [5]: Option B
    // [6]: Option C
    // [7]: Option D
    // [8]: Correct Answer (A/B/C/D or number)
    // [9]: Positive Marks (optional, default 4)
    // [10]: Negative Marks (optional, default 1)
    // [11]: Explanation (optional)

    const sectionStr = cells[0] || 'Physics';
    const validSection: SubjectSection = ['Physics', 'Chemistry', 'Mathematics', 'Biology'].includes(
      sectionStr as SubjectSection
    )
      ? (sectionStr as SubjectSection)
      : 'Physics';

    const typeStr = (cells[1] || 'mcq').toLowerCase();
    const type: QuestionType = typeStr === 'numerical' ? 'numerical' : 'mcq';
    const text = cells[2] || `Question ${i}`;
    const imageUrl = cells[3] || undefined;
    const optA = cells[4] || '';
    const optB = cells[5] || '';
    const optC = cells[6] || '';
    const optD = cells[7] || '';
    const correctAnswer = (cells[8] || 'A').toUpperCase();
    const posMarks = parseFloat(cells[9]) || 4;
    const negMarks = parseFloat(cells[10]) || 1;
    const explanation = cells[11] || 'Standard concept solution.';

    const question: Question = {
      id: `q-batch-${Date.now()}-${i}`,
      section: validSection,
      type,
      text,
      imageUrl: imageUrl && imageUrl.startsWith('http') ? imageUrl : undefined,
      options: [
        { key: 'A', text: optA },
        { key: 'B', text: optB },
        { key: 'C', text: optC },
        { key: 'D', text: optD },
      ],
      correctAnswer,
      positiveMarks: posMarks,
      negativeMarks: negMarks,
      explanation,
    };

    questions.push(question);
  }

  return { questions, errors };
}

export function parseBatchJson(jsonText: string): {
  questions: Question[];
  errors: string[];
} {
  const errors: string[] = [];
  try {
    const parsed = JSON.parse(jsonText);
    const rawList = Array.isArray(parsed) ? parsed : parsed.questions;

    if (!Array.isArray(rawList)) {
      return {
        questions: [],
        errors: ['JSON must be an array of questions or contain a "questions" array.'],
      };
    }

    const questions: Question[] = rawList.map((item: any, idx: number) => {
      const id = item.id || `q-json-${Date.now()}-${idx + 1}`;
      const section: SubjectSection = ['Physics', 'Chemistry', 'Mathematics', 'Biology'].includes(
        item.section
      )
        ? item.section
        : 'Physics';
      const type: QuestionType = item.type === 'numerical' ? 'numerical' : 'mcq';
      const text = item.text || `Question ${idx + 1}`;
      const options = Array.isArray(item.options) && item.options.length >= 2
        ? item.options.map((opt: any, optIdx: number) => ({
            key: opt.key || (['A', 'B', 'C', 'D'][optIdx] as OptionKey),
            text: typeof opt === 'string' ? opt : opt.text || '',
            imageUrl: opt.imageUrl,
          }))
        : [
            { key: 'A', text: 'Option A' },
            { key: 'B', text: 'Option B' },
            { key: 'C', text: 'Option C' },
            { key: 'D', text: 'Option D' },
          ];

      return {
        id,
        section,
        type,
        text,
        imageUrl: item.imageUrl,
        options,
        correctAnswer: item.correctAnswer || 'A',
        positiveMarks: item.positiveMarks ?? 4,
        negativeMarks: item.negativeMarks ?? 1,
        explanation: item.explanation || 'Step-by-step solution provided by Argon faculty.',
        explanationImageUrl: item.explanationImageUrl,
      };
    });

    return { questions, errors };
  } catch (err: any) {
    return { questions: [], errors: [`Invalid JSON format: ${err.message}`] };
  }
}

export function getSampleCsvTemplate(): string {
  return `Section,Type,Question,ImageUrl,OptionA,OptionB,OptionC,OptionD,CorrectAnswer,PositiveMarks,NegativeMarks,Explanation
Physics,mcq,"A projectile is launched at 45° with speed 20 m/s. What is maximum height (g=10 m/s²)?",,10 m,15 m,20 m,25 m,A,4,1,"H = (u² sin² 45°)/(2g) = 400 * 0.5 / 20 = 10 m"
Chemistry,mcq,"Which of the following compounds exhibits optical isomerism?",,[Cr(en)3]3+,[Pt(NH3)2Cl2],[Co(NH3)4Cl2]+,[Zn(NH3)4]2+,A,4,1,"Tris-ethylenediamine cobalt/chromium complexes have non-superimposable mirror images."
Mathematics,numerical,"Find the value of integral from 0 to 1 of (3x² + 2x) dx.",,,,,1.0,4,0,"[x³ + x²] from 0 to 1 = 1 + 1 - 0 = 2.0"
Biology,mcq,"During DNA replication, which enzyme joins the Okazaki fragments on lagging strand?",,DNA Polymerase I,DNA Ligase,Primase,Helicase,B,4,1,"DNA Ligase forms phosphodiester bonds to join Okazaki fragments."`;
}

export function getSampleJsonTemplate(): string {
  return JSON.stringify(
    {
      questions: [
        {
          section: 'Physics',
          type: 'mcq',
          text: 'A circular coil of 100 turns has radius 10 cm. Find magnetic field at center if current is 2 A (in microTesla).',
          options: [
            { key: 'A', text: '1256 µT' },
            { key: 'B', text: '628 µT' },
            { key: 'C', text: '314 µT' },
            { key: 'D', text: '157 µT' },
          ],
          correctAnswer: 'A',
          positiveMarks: 4,
          negativeMarks: 1,
          explanation: 'B = (µ₀ * N * I) / (2 * R) = (4π * 10⁻⁷ * 100 * 2) / 0.2 ≈ 1256 µT.',
        },
      ],
    },
    null,
    2
  );
}
