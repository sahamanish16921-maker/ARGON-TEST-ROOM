-- ==============================================================================
-- SUPABASE POSTGRESQL SCHEMA FOR FACULTY & STUDENT LMS / TEST PORTAL
-- ==============================================================================

-- 1. Create Role Enum
CREATE TYPE user_role AS ENUM ('FACULTY', 'STUDENT');

-- 2. Profiles Table (Extends Supabase auth.users)
CREATE TABLE public.profiles (
  id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  email TEXT NOT NULL,
  full_name TEXT NOT NULL,
  role user_role NOT NULL DEFAULT 'STUDENT',
  phone TEXT,
  avatar_url TEXT,
  target_exam TEXT DEFAULT 'JEE Main & Advanced',
  created_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now()),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now())
);

-- Enable RLS on profiles
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;

-- 3. Automatic Profile Creation Trigger on Auth Signup
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER AS $$
BEGIN
  INSERT INTO public.profiles (id, email, full_name, role, phone, target_exam)
  VALUES (
    NEW.id,
    NEW.email,
    COALESCE(NEW.raw_user_meta_data->>'full_name', 'Student Candidate'),
    COALESCE((NEW.raw_user_meta_data->>'role')::user_role, 'STUDENT'::user_role),
    NEW.raw_user_meta_data->>'phone',
    COALESCE(NEW.raw_user_meta_data->>'target_exam', 'JEE Main')
  );
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

CREATE OR REPLACE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- Helper function to check if current user is FACULTY
CREATE OR REPLACE FUNCTION public.is_faculty()
RETURNS BOOLEAN AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.profiles
    WHERE id = auth.uid() AND role = 'FACULTY'
  );
$$ LANGUAGE sql STABLE SECURITY DEFINER;

-- Profiles RLS Policies
CREATE POLICY "Public profiles are viewable by authenticated users"
  ON public.profiles FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Users can update their own profile"
  ON public.profiles FOR UPDATE
  TO authenticated
  USING (auth.uid() = id)
  WITH CHECK (auth.uid() = id);

-- 4. Courses Table
CREATE TABLE public.courses (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  title TEXT NOT NULL,
  description TEXT,
  target_exam TEXT NOT NULL, -- 'JEE Main', 'JEE Advanced', 'NEET', etc.
  faculty_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  is_published BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now()),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now())
);

ALTER TABLE public.courses ENABLE ROW LEVEL SECURITY;

-- Courses RLS Policies
-- Everyone (faculty & students) can view published courses
CREATE POLICY "Courses are viewable by all authenticated users"
  ON public.courses FOR SELECT
  TO authenticated
  USING (is_published = true OR faculty_id = auth.uid());

-- Only faculty can create courses
CREATE POLICY "Faculty can create courses"
  ON public.courses FOR INSERT
  TO authenticated
  WITH CHECK (
    auth.uid() = faculty_id AND public.is_faculty()
  );

-- Faculty can update their own courses
CREATE POLICY "Faculty can update own courses"
  ON public.courses FOR UPDATE
  TO authenticated
  USING (auth.uid() = faculty_id AND public.is_faculty())
  WITH CHECK (auth.uid() = faculty_id AND public.is_faculty());

-- Faculty can delete their own courses
CREATE POLICY "Faculty can delete own courses"
  ON public.courses FOR DELETE
  TO authenticated
  USING (auth.uid() = faculty_id AND public.is_faculty());

-- 5. Assignments and Tests Table
CREATE TABLE public.assignments_tests (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  course_id UUID NOT NULL REFERENCES public.courses(id) ON DELETE CASCADE,
  title TEXT NOT NULL,
  instructions TEXT,
  duration_minutes INTEGER NOT NULL DEFAULT 180,
  total_marks INTEGER NOT NULL DEFAULT 300,
  questions JSONB NOT NULL DEFAULT '[]'::jsonb,
  is_locked BOOLEAN NOT NULL DEFAULT false,
  start_window TIMESTAMPTZ,
  end_window TIMESTAMPTZ,
  created_by UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now()),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now())
);

ALTER TABLE public.assignments_tests ENABLE ROW LEVEL SECURITY;

-- Assignments/Tests RLS Policies
CREATE POLICY "Authenticated users can view tests for published courses"
  ON public.assignments_tests FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM public.courses
      WHERE public.courses.id = assignments_tests.course_id
      AND (public.courses.is_published = true OR public.courses.faculty_id = auth.uid())
    )
  );

CREATE POLICY "Faculty can create tests for their courses"
  ON public.assignments_tests FOR INSERT
  TO authenticated
  WITH CHECK (
    auth.uid() = created_by AND public.is_faculty()
  );

CREATE POLICY "Faculty can update their created tests"
  ON public.assignments_tests FOR UPDATE
  TO authenticated
  USING (auth.uid() = created_by AND public.is_faculty())
  WITH CHECK (auth.uid() = created_by AND public.is_faculty());

CREATE POLICY "Faculty can delete their created tests"
  ON public.assignments_tests FOR DELETE
  TO authenticated
  USING (auth.uid() = created_by AND public.is_faculty());

-- 6. Submissions Table
CREATE TABLE public.submissions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  test_id UUID NOT NULL REFERENCES public.assignments_tests(id) ON DELETE CASCADE,
  student_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  answers JSONB NOT NULL DEFAULT '{}'::jsonb,
  question_states JSONB NOT NULL DEFAULT '{}'::jsonb,
  score NUMERIC(6, 2) NOT NULL DEFAULT 0,
  correct_count INTEGER NOT NULL DEFAULT 0,
  incorrect_count INTEGER NOT NULL DEFAULT 0,
  unanswered_count INTEGER NOT NULL DEFAULT 0,
  time_spent_seconds INTEGER NOT NULL DEFAULT 0,
  submitted_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now()),
  status TEXT NOT NULL DEFAULT 'EVALUATED' -- 'EVALUATED' | 'PENDING'
);

ALTER TABLE public.submissions ENABLE ROW LEVEL SECURITY;

-- Submissions RLS Policies
-- Students can only read their own submissions
-- Faculty can view submissions for tests belonging to courses they created
CREATE POLICY "View submissions policy"
  ON public.submissions FOR SELECT
  TO authenticated
  USING (
    student_id = auth.uid()
    OR EXISTS (
      SELECT 1 FROM public.assignments_tests t
      JOIN public.courses c ON c.id = t.course_id
      WHERE t.id = submissions.test_id
      AND c.faculty_id = auth.uid()
    )
  );

-- Students can insert their own submissions
CREATE POLICY "Students can submit their tests"
  ON public.submissions FOR INSERT
  TO authenticated
  WITH CHECK (
    student_id = auth.uid()
  );

-- Students can update only their own in-progress draft submissions if needed
CREATE POLICY "Students can update their submissions"
  ON public.submissions FOR UPDATE
  TO authenticated
  USING (student_id = auth.uid())
  WITH CHECK (student_id = auth.uid());

-- 7. Realtime Replication Setup
-- Enable Supabase Realtime publication on relevant tables
ALTER PUBLICATION supabase_realtime ADD TABLE public.assignments_tests;
ALTER PUBLICATION supabase_realtime ADD TABLE public.submissions;
ALTER PUBLICATION supabase_realtime ADD TABLE public.courses;
