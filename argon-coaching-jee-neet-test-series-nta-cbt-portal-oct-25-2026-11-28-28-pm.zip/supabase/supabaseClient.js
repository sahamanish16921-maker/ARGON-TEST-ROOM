// ==============================================================================
// SUPABASE CLIENT & AUTH/DATA HELPERS (Modular JavaScript / ES Module)
// ==============================================================================

import { createClient } from '@supabase/supabase-js';

// 1. Initialize Supabase Client
const SUPABASE_URL = process.env.VITE_SUPABASE_URL || 'https://your-project.supabase.co';
const SUPABASE_ANON_KEY = process.env.VITE_SUPABASE_ANON_KEY || 'your-anon-key';

export const supabase = createClient(SUPABASE_URL, SUPABASE_ANON_KEY, {
  auth: {
    persistSession: true,
    autoRefreshToken: true,
    detectSessionInUrl: true,
  },
});

// ==============================================================================
// 2. AUTHENTICATION HELPERS
// ==============================================================================

/**
 * Sign up a new user with Role ('FACULTY' | 'STUDENT')
 */
export async function signUpUser({ email, password, fullName, role = 'STUDENT', phone = '', targetExam = 'JEE Main' }) {
  const { data, error } = await supabase.auth.signUp({
    email,
    password,
    options: {
      data: {
        full_name: fullName,
        role: role.toUpperCase(), // 'FACULTY' or 'STUDENT'
        phone,
        target_exam: targetExam,
      },
    },
  });

  if (error) throw error;
  return data;
}

/**
 * Log in an existing user and fetch their synced profile with role
 */
export async function loginUser({ email, password }) {
  const { data, error } = await supabase.auth.signInWithPassword({
    email,
    password,
  });

  if (error) throw error;

  // Immediately fetch profile from cloud database
  const profile = await fetchCurrentUserProfile(data.user.id);
  return { user: data.user, session: data.session, profile };
}

/**
 * Sign out user and clear local session state
 */
export async function logoutUser() {
  const { error } = await supabase.auth.signOut();
  if (error) throw error;
}

/**
 * Fetch authenticated user's profile
 */
export async function fetchCurrentUserProfile(userId) {
  const { data, error } = await supabase
    .from('profiles')
    .select('*')
    .eq('id', userId)
    .single();

  if (error) throw error;
  return data;
}

// ==============================================================================
// 3. STUDENT DASHBOARD HELPERS
// ==============================================================================

/**
 * Loads everything needed when a Student logs in on ANY device:
 * - Available published courses
 * - Active / upcoming tests
 * - Historical test submissions & scores belonging to this student
 */
export async function fetchStudentDashboardData(studentId) {
  // 1. Fetch available courses
  const coursesPromise = supabase
    .from('courses')
    .select('*, faculty:profiles(full_name, email)')
    .eq('is_published', true)
    .order('created_at', { ascending: false });

  // 2. Fetch accessible tests
  const testsPromise = supabase
    .from('assignments_tests')
    .select('id, title, duration_minutes, total_marks, is_locked, start_window, end_window, course_id, courses(title, target_exam)')
    .order('created_at', { ascending: false });

  // 3. Fetch student's own submissions (RLS strictly enforces only their records)
  const submissionsPromise = supabase
    .from('submissions')
    .select('*, test:assignments_tests(title, duration_minutes, total_marks)')
    .eq('student_id', studentId)
    .order('submitted_at', { ascending: false });

  const [coursesRes, testsRes, submissionsRes] = await Promise.all([
    coursesPromise,
    testsPromise,
    submissionsPromise,
  ]);

  if (coursesRes.error) throw coursesRes.error;
  if (testsRes.error) throw testsRes.error;
  if (submissionsRes.error) throw submissionsRes.error;

  return {
    courses: coursesRes.data || [],
    tests: testsRes.data || [],
    mySubmissions: submissionsRes.data || [],
  };
}

/**
 * Submit test answers from student device to cloud database
 */
export async function submitStudentTest({
  testId,
  studentId,
  answers,
  questionStates,
  score,
  correctCount,
  incorrectCount,
  unansweredCount,
  timeSpentSeconds,
}) {
  const { data, error } = await supabase
    .from('submissions')
    .insert([
      {
        test_id: testId,
        student_id: studentId,
        answers,
        question_states: questionStates,
        score,
        correct_count: correctCount,
        incorrect_count: incorrectCount,
        unanswered_count: unansweredCount,
        time_spent_seconds: timeSpentSeconds,
        submitted_at: new Date().toISOString(),
        status: 'EVALUATED',
      },
    ])
    .select()
    .single();

  if (error) throw error;
  return data;
}

// ==============================================================================
// 4. FACULTY MANAGEMENT HELPERS
// ==============================================================================

/**
 * Loads everything needed when a Faculty member logs in on ANY device:
 * - All courses created by this faculty
 * - All tests authored under those courses
 * - All student submissions across all their tests (enabled via RLS)
 */
export async function fetchFacultyDashboardData(facultyId) {
  // 1. Fetch courses owned by faculty
  const { data: courses, error: coursesError } = await supabase
    .from('courses')
    .select('*')
    .eq('faculty_id', facultyId)
    .order('created_at', { ascending: false });

  if (coursesError) throw coursesError;

  const courseIds = (courses || []).map((c) => c.id);

  if (courseIds.length === 0) {
    return { courses: [], tests: [], submissions: [] };
  }

  // 2. Fetch tests belonging to these courses
  const { data: tests, error: testsError } = await supabase
    .from('assignments_tests')
    .select('*')
    .in('course_id', courseIds)
    .order('created_at', { ascending: false });

  if (testsError) throw testsError;

  const testIds = (tests || []).map((t) => t.id);

  // 3. Fetch submissions across faculty tests (with student profile details)
  let submissions = [];
  if (testIds.length > 0) {
    const { data: subsData, error: subsError } = await supabase
      .from('submissions')
      .select('*, student:profiles(full_name, email, phone, target_exam), test:assignments_tests(title, total_marks)')
      .in('test_id', testIds)
      .order('submitted_at', { ascending: false });

    if (subsError) throw subsError;
    submissions = subsData || [];
  }

  return {
    courses: courses || [],
    tests: tests || [],
    submissions,
  };
}

/**
 * Faculty test creation/publishing
 */
export async function createFacultyTest({ courseId, facultyId, title, durationMinutes, totalMarks, questions }) {
  const { data, error } = await supabase
    .from('assignments_tests')
    .insert([
      {
        course_id: courseId,
        created_by: facultyId,
        title,
        duration_minutes: durationMinutes,
        total_marks: totalMarks,
        questions,
        is_locked: false,
      },
    ])
    .select()
    .single();

  if (error) throw error;
  return data;
}

/**
 * Toggle test lock state (instantly locks for all students in real time)
 */
export async function toggleTestLock(testId, isLocked) {
  const { data, error } = await supabase
    .from('assignments_tests')
    .update({ is_locked: isLocked, updated_at: new Date().toISOString() })
    .eq('id', testId)
    .select()
    .single();

  if (error) throw error;
  return data;
}

// ==============================================================================
// 5. REAL-TIME SUBSCRIPTIONS (Cross-Device Sync)
// ==============================================================================

/**
 * Subscribe to new submissions for faculty (instant updates without reload)
 */
export function subscribeToFacultySubmissions(onNewSubmission) {
  return supabase
    .channel('faculty-submissions-channel')
    .on(
      'postgres_changes',
      { event: 'INSERT', schema: 'public', table: 'submissions' },
      (payload) => {
        onNewSubmission(payload.new);
      }
    )
    .subscribe();
}

/**
 * Subscribe to test lock/unlock changes for students
 */
export function subscribeToTestUpdates(onTestChange) {
  return supabase
    .channel('student-tests-channel')
    .on(
      'postgres_changes',
      { event: 'UPDATE', schema: 'public', table: 'assignments_tests' },
      (payload) => {
        onTestChange(payload.new);
      }
    )
    .subscribe();
}
